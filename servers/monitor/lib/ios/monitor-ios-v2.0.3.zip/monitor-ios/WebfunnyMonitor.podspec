Pod::Spec.new do |s|
  s.name             = 'WebfunnyMonitor'
  s.version          = '2.0.3'
  s.summary          = 'Webfunny 全链路监控 iOS SDK'
  s.description      = <<-DESC
    对接 Webfunny 监控平台的 iOS 原生 SDK，支持崩溃采集、网络请求监控、
    页面加载耗时、FPS/内存采样、gzip 压缩上报、自动重试，
    数据上报到 /wfMonitor/upLogs 接口。
  DESC
  s.homepage         = 'https://github.com/webfunny/webfunny-monitor-ios'
  s.license          = { :type => 'MIT' }
  s.author           = { 'Webfunny' => 'dev@webfunny.com' }
  s.source           = { :git => 'https://github.com/webfunny/webfunny-monitor-ios.git', :tag => s.version.to_s }

  s.ios.deployment_target = '13.0'
  s.swift_version         = '5.9'

  s.source_files = 'Sources/WebfunnyMonitor/**/*.swift'

  s.frameworks = 'UIKit', 'Foundation', 'SystemConfiguration', 'Compression'
end
