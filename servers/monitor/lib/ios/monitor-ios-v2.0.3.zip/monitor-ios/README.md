# Webfunny Monitor iOS SDK v2.0

面向 Webfunny 监控平台的 iOS 原生 SDK，支持崩溃采集、HTTP 请求监控、启动与页面耗时、CUSTOMER_PV、FPS / 内存采样等，数据上报至 `{serverUrl}/wfMonitor/upLogs`。

> **Objective-C 项目**请参阅 [README_OBJC.md](./README_OBJC.md)

---

## 1. 集成 SDK

### 方式一：源码包（本地 SPM）

> 适用于无法通过 Git 仓库集成的场景（内网、安全限制等）。

1. 获取源码包 zip：联系维护方获取 `monitor-ios-v2.0.1.zip`，或自行打包（见下文）
2. 解压到项目同级目录（或任意路径）
3. Xcode 打开你的工程：**File → Add Package Dependencies…**
4. 点击左下角 **Add Local…**
5. 选择解压后的 `monitor-ios` 文件夹
6. 点击 **Add Package**，在 **Add to Target** 中勾选你的 App

> **自行打包**：在 `monitor-ios` 目录下执行 `./package.sh`，生成的 zip 在 `dist/` 目录。

### 方式二：CocoaPods

SDK 内置 `WebfunnyMonitor.podspec`，在 Podfile 中添加：

```ruby
pod 'WebfunnyMonitor', :path => 'path/to/monitor-ios'
```

> 如果 SDK 已发布到远程仓库，可改为 `pod 'WebfunnyMonitor', '~> 2.0.1'`。

然后执行：

```bash
pod install
```

> **重要**：CocoaPods 项目必须通过 `.xcworkspace` 打开。

### 方式三：Swift Package Manager（远程 Git）

1. Xcode 打开你的工程：**File → Add Package Dependencies…**
2. 在右上角输入框粘贴 **Git 仓库地址**：
   `https://github.com/webfunny/webfunny-monitor-ios.git`
3. **Dependency Rule** 建议选择 **Up to Next Major Version** 并绑定已发布的 **Tag**。
4. 添加依赖后，在 **Add to Target** 中勾选你的 App，库产品名为 **WebfunnyMonitor**。

---

## 2. 初始化 SDK

在 `AppDelegate` 的 `didFinishLaunchingWithOptions` 或 SwiftUI App 入口的 `init()` 中初始化，**越早越好**（早于业务侧创建 `URLSession`，以便 HTTP 拦截生效）：

### SwiftUI

```swift
import SwiftUI
import WebfunnyMonitor

@main
struct MyApp: App {
    init() {
        WFMonitor.setup(
            serverUrl:    "https://your-monitor-host.com",
            webMonitorId: "在控制台获取的 webMonitorId"
        )
    }

    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
```

### UIKit（AppDelegate）

```swift
func application(_ application: UIApplication,
                 didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    WFMonitor.setup(
        serverUrl:    "https://your-monitor-host.com",
        webMonitorId: "your_monitor_id"
    )
    return true
}
```

### 验证

运行 App 后，在 Xcode Console 搜索 `WFMonitor`，应能看到上报日志和 HTTP 状态码。

---

## 3. 设置用户信息（登录后调用）

```swift
WFMonitor.setUserId("业务用户唯一标识")

// 可选：自定义参数
WFMonitor.setUserParam(first: "渠道A", second: "实验组1")

// 退出登录时清除
WFMonitor.setUserId("")
```

> 用户信息会持久化到本地，App 重启后自动恢复。

---

## 4. 可选：功能开关与调试日志

```swift
WFMonitor.setup(
    serverUrl:    "https://your-monitor-host.com",
    webMonitorId: "your_id",
    options: WFConfig.Options(
        enableCrash:  true,
        enableHttp:   true,
        enableFps:    true,
        enableMemory: true,
        httpBodyMaxBytes: 8192,
        samplingInterval: 2.0,
        debugLog:     true,  // 控制台打印上报详情，仅调试期建议开启
        gzip:         true,  // 是否启用 gzip 压缩上报（默认 true）
        env:          "pro"  // 环境标识：dev / sit / stag / pro（默认 pro）
    )
)
```

### WFConfig.Options 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enableCrash` | Bool | true | 崩溃采集 |
| `enableHttp` | Bool | true | HTTP 请求拦截 |
| `enableFps` | Bool | true | FPS 采样 |
| `enableMemory` | Bool | true | 内存采样 |
| `samplingInterval` | TimeInterval | 2.0 | FPS/内存采样间隔（秒） |
| `httpBodyMaxBytes` | Int | 8192 | HTTP 请求/响应体截取上限（字节） |
| `debugLog` | Bool | false | SDK 调试日志 |
| `gzip` | Bool | true | gzip 压缩上报（body > 1KB 时启用） |
| `env` | String | "pro" | 环境标识：dev / sit / stag / pro |

---

## 5. 手动上报错误（JS_ERROR）

```swift
do {
    try riskyOperation()
} catch {
    WFMonitor.reportError(error, errorScene: "支付接口调用")
}
```

与 H5 SDK 的 JS_ERROR 协议对齐，移动端原生异常也可通过该方法主动上报。

---

## 6. 手动页面耗时（SwiftUI / 非 UIViewController 场景）

```swift
let tracker = WFMonitor.startPageTrace("HomeView")
// … 页面逻辑 …
tracker.finish()
```

自动页面与 CUSTOMER_PV 依赖对 `UIViewController` 的 swizzle；纯 SwiftUI 结构仍建议对关键页面使用上述手动追踪。

---

## 7. 立即上报队列

在关键节点（如测试、切后台前）可调用：

```swift
WFMonitor.flush()
```

SDK 也会在以下场景自动刷新队列：
- App 进入后台（`didEnterBackground`）
- App 即将失去焦点（`willResignActive`）
- 系统内存警告（`didReceiveMemoryWarning`）

---

## 8. 注意事项

### 8.1 上报地址

实际请求 URL 为：`{serverUrl}/wfMonitor/upLogs`（`serverUrl` 不要带该路径后缀）。

### 8.2 真机与 localhost

模拟器访问本机可用 `http://localhost:端口`；**真机**须使用电脑局域网 IP，例如 `http://192.168.1.10:8023`，并在需要时配置 **App Transport Security**（仅 HTTPS 或例外域名）。

### 8.3 HTTP 采集（`HTTP_LOG`）

- 基于 `URLProtocol` 注册；对 **`WFMonitor.setup` 之后** 创建的 `URLSession` / 默认会话发起的请求更易被采集。
- 若业务在初始化前已创建并复用自定义 `URLSessionConfiguration`，可能无法自动注入，需在配置中自行将拦截类加入 `protocolClasses`（需阅读源码中的 `WFHttpInterceptor`）。
- **WKWebView** 内页面请求默认不经过 `NSURLProtocol`，当前 SDK 不采集 WebView 内资源请求。

### 8.4 崩溃调试（Xcode 运行）

使用 Xcode **Run** 时，调试器会拦截部分 Signal，导致与「脱离调试器」行为不一致。验证崩溃落盘与下次启动补报时，建议：**Build 后从桌面/模拟器主屏幕点击 App 图标启动**，再通过设备日志查看；`NSException` 类异常在调试器下仍较易观察。

### 8.5 隐私与体积

HTTP 日志会携带截断后的请求/响应体与头信息，生产环境请评估合规性，必要时关闭 `enableHttp` 或后续裁剪字段。

---

## 9. 主要上报类型（uploadType）速查

| uploadType | 说明 |
|------------|------|
| `APP_START` | 启动相关性能 |
| `MOBILE_PAGE_LOAD` | 页面加载耗时 |
| `MOBILE_HTTP_LOG` | HTTP 请求 |
| `APP_CRASH` | 崩溃 / 未捕获异常 |
| `CUSTOMER_PV` | 页面 PV（每次 viewDidAppear 自动上报） |
| `JS_ERROR` | 主动上报的业务错误 |

---

## 10. API 参考

| 方法 | 说明 |
|------|------|
| `WFMonitor.setup(serverUrl:webMonitorId:options:)` | 初始化 SDK |
| `WFMonitor.setUserId(_:)` | 设置业务用户 ID（持久化） |
| `WFMonitor.setUserParam(first:second:)` | 设置自定义参数（持久化） |
| `WFMonitor.startPageTrace(_:)` | 手动页面耗时追踪 |
| `WFMonitor.reportError(_ errorScene:)` | 手动上报业务错误 |
| `WFMonitor.flush()` | 立即刷新上报队列 |

---

## 11. v2.0 更新日志

- **数据可靠性**：flush 先落盘后上传，进程被杀不丢数据
- **自动重试**：上报失败自动重试（4s → 16s → 32s，最多 3 次），启动时恢复残留批次
- **独立 DiskManager**：文件级批次管理，5MB FIFO 上限 + 7 天过期清理
- **gzip 压缩**：body > 1KB 时 gzip 压缩上报，节省流量
- **用户信息持久化**：userId / userParam 持久化到本地，App 重启自动恢复
- **内存压力兜底**：`willResignActive` / `didReceiveMemoryWarning` 自动 flush
- **设备信息补齐**：新增 manufacturer / screenWidth / screenHeight / density / language / timezone / carrier / sdkVersion
- **请求签名**：`wf-signature` 请求头防篡改（对标 H5 / Android）
- **环境标识**：新增 `env` 字段，区分 dev / sit / stag / pro
- **服务端配置拉取**：初始化时异步拉取 `initCf` 配置（签名等）

---

## 12. 环境要求

| 项 | 说明 |
|----|------|
| 最低系统 | iOS **13.0** 及以上 |
| 语言 | Swift **5.9** 及以上 |
| 界面框架 | UIKit；SwiftUI 宿主 App 同样支持（需在最早生命周期初始化） |
| Xcode | 15+ |

---

## 13. 目录与产物

- **SPM 库名**：`WebfunnyMonitor`
- **源码路径**：`Sources/WebfunnyMonitor/`
- **对外 API**：`WFMonitor`、`WFConfig`、`WFConfig.Options`
- **SDK 版本**：2.0.1

---

## 14. 问题排查

1. 打开 `debugLog: true`，在 Xcode 控制台查看是否出现 `[WFMonitor]` 前缀的上报日志及 HTTP 状态码。
2. 确认 `webMonitorId`、网络可达、服务端未返回 4xx。
3. 包引用变更后：**File → Packages → Reset Package Caches** 再编译。

如有接入问题，请携带脱敏后的初始化代码与控制台日志联系维护方。
