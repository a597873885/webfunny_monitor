import Foundation

/// 手动页面耗时追踪（适用于 SwiftUI View / 不使用 UIViewController 的场景）
///
/// ```swift
/// struct HomeView: View {
///     @State private var tracker: WFPageTracker?
///
///     var body: some View {
///         content
///             .onAppear { tracker = WFMonitor.startPageTrace("HomeView") }
///             .onDisappear { tracker?.finish() }
///     }
/// }
/// ```
@objc public final class WFPageTracker: NSObject {

    private let pageName: String
    private let config: WFConfig
    private let startMs: Double
    private let memoryBefore: Int
    private var finished = false

    init(pageName: String, config: WFConfig) {
        self.pageName     = pageName
        self.config       = config
        self.startMs      = Date().timeIntervalSince1970 * 1000
        self.memoryBefore = WFMemoryHelper.usedMemoryMB()
        WFSession.shared.currentPage = pageName
        super.init()
    }

    /// 结束追踪（使用默认参数，适用于 ObjC 和 Swift 简单场景）
    @objc public func finish() {
        finish(loadType: "navigation", dataFetchTime: 0, viewBuildTime: 0)
    }

    /// 结束追踪（指定加载类型）
    @objc public func finishWithLoadType(_ loadType: String) {
        finish(loadType: loadType, dataFetchTime: 0, viewBuildTime: 0)
    }

    /// 结束追踪（完整参数）
    @objc public func finishWithLoadType(_ loadType: String, dataFetchTime: Int, viewBuildTime: Int) {
        finish(loadType: loadType, dataFetchTime: dataFetchTime, viewBuildTime: viewBuildTime)
    }

    /// 结束追踪（Swift 完整版本，带默认参数）
    public func finish(
        loadType: String = "navigation",
        dataFetchTime: Int = 0,
        viewBuildTime: Int = 0
    ) {
        guard !finished else { return }
        finished = true

        let duration = Int(Date().timeIntervalSince1970 * 1000 - startMs)
        let log = WFPageLoadLog(
            config:          config,
            pagePath:        pageName,
            loadType:        loadType,
            firstRenderTime: duration,
            dataFetchTime:   dataFetchTime,
            viewBuildTime:   viewBuildTime,
            memoryBefore:    memoryBefore,
            memoryAfter:     WFMemoryHelper.usedMemoryMB(),
            avgFPS:          WFMemoryFpsCollector.shared.lastAvgFps,
            jankCount:       WFMemoryFpsCollector.shared.lastJankCount,
            severeJankCount: WFMemoryFpsCollector.shared.lastSevereJankCount
        )
        WFUploader.shared.enqueue(log.toDict())
    }
}


