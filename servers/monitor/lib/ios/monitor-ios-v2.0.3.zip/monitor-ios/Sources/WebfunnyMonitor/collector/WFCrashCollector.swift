import Foundation
import UIKit

/// iOS 崩溃捕获
///
/// 覆盖两种崩溃类型：
/// 1. NSException（OC 异常，如数组越界、unrecognized selector）
///    → NSSetUncaughtExceptionHandler，iOS 系统内置，所有监控 SDK 均采用
/// 2. Signal 崩溃（SIGSEGV/SIGBUS/SIGABRT 等，如野指针/内存错误）
///    → signal() 注册处理函数
///
/// 风险：纯系统 API，无第三方依赖
final class WFCrashCollector {

    private static var config: WFConfig!
    private static let handledSignals: [Int32] = [
        SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGABRT, SIGTRAP
    ]

    static func install(config: WFConfig) {
        self.config = config
        installExceptionHandler()
        installSignalHandlers()
    }

    // MARK: - NSException Handler

    private static func installExceptionHandler() {
        NSSetUncaughtExceptionHandler { exception in
            print("[WFMonitor-Crash] ⚡ NSException 捕获: \(exception.name.rawValue) - \(exception.reason ?? "")")
            guard let cfg = WFCrashCollector.config else {
                print("[WFMonitor-Crash] ❌ config 为 nil，无法保存崩溃日志")
                return
            }
            let isFg = WFCrashCollector.isInForeground()
            let log  = WFCrashLog(config: cfg, exception: exception, isForeground: isFg)
            WFUploader.shared.saveCrashLogSync(log.toDict())
            print("[WFMonitor-Crash] ✅ NSException 日志已写盘，下次启动补报")
        }
    }

    // MARK: - Signal Handlers

    private static func installSignalHandlers() {
        for sig in handledSignals {
            signal(sig) { sigNum in
                print("[WFMonitor-Crash] ⚡ Signal 捕获: \(sigNum)")
                guard let cfg = WFCrashCollector.config else {
                    print("[WFMonitor-Crash] ❌ config 为 nil")
                    signal(sigNum, SIG_DFL); raise(sigNum); return
                }
                let stack = Thread.callStackSymbols
                let isFg  = WFCrashCollector.isInForeground()
                let log   = WFCrashLog(config: cfg, signal: sigNum, callStack: stack, isForeground: isFg)
                WFUploader.shared.saveCrashLogSync(log.toDict())
                print("[WFMonitor-Crash] ✅ Signal 日志已写盘，下次启动补报")
                signal(sigNum, SIG_DFL)
                raise(sigNum)
            }
        }
    }

    private static func isInForeground() -> Bool {
        if Thread.isMainThread {
            return UIApplication.shared.applicationState == .active
        }
        var result = false
        DispatchQueue.main.sync { result = UIApplication.shared.applicationState == .active }
        return result
    }
}
