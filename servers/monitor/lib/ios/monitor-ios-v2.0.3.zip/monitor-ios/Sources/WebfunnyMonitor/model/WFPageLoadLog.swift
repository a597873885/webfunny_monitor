import Foundation

/// MOBILE_PAGE_LOAD → MobilePerformanceLog
final class WFPageLoadLog: WFBaseLog {

    let pagePath: String
    let loadType: String
    let firstRenderTime: Int
    let onCreateTime: Int
    let dataFetchTime: Int
    let viewBuildTime: Int
    let memoryBefore: Int
    let memoryAfter: Int
    let avgFPS: Int
    let jankCount: Int
    let severeJankCount: Int
    let totalDuration: Int

    init(
        config: WFConfig,
        pagePath: String,
        loadType: String = "navigation",
        firstRenderTime: Int,
        onCreateTime: Int = 0,
        dataFetchTime: Int = 0,
        viewBuildTime: Int = 0,
        memoryBefore: Int = 0,
        memoryAfter: Int = 0,
        avgFPS: Int = 60,
        jankCount: Int = 0,
        severeJankCount: Int = 0
    ) {
        self.pagePath        = pagePath
        self.loadType        = loadType
        self.firstRenderTime = firstRenderTime
        self.onCreateTime    = onCreateTime
        self.dataFetchTime   = dataFetchTime
        self.viewBuildTime   = viewBuildTime
        self.memoryBefore    = memoryBefore
        self.memoryAfter     = memoryAfter
        self.avgFPS          = avgFPS
        self.jankCount       = jankCount
        self.severeJankCount = severeJankCount
        self.totalDuration   = firstRenderTime
        super.init(uploadType: "MOBILE_PAGE_LOAD", config: config)
    }

    override func toDict() -> [String: Any] {
        var d = super.toDict()
        d["pagePath"]        = pagePath
        d["loadType"]        = loadType
        d["firstRenderTime"] = firstRenderTime
        d["onCreateTime"]    = onCreateTime
        d["dataFetchTime"]   = dataFetchTime
        d["viewBuildTime"]   = viewBuildTime
        d["memoryBefore"]    = memoryBefore
        d["memoryAfter"]     = memoryAfter
        d["avgFPS"]          = avgFPS
        d["jankCount"]       = jankCount
        d["severeJankCount"] = severeJankCount
        d["totalDuration"]   = totalDuration
        return d
    }
}
