import Foundation

// MARK: - ObjC 配置对象

/// 监控 SDK 配置选项（ObjC 兼容包装类）
///
/// 对应 Swift 的 `WFConfig.Options`，Objective-C 项目通过设置属性后传给 `WFMonitorBridge.setup`。
@objc public class WFMonitorOptionsConfig: NSObject {
    /// 是否开启崩溃采集（默认 true）
    @objc public var enableCrash: Bool = true
    /// 是否开启 HTTP 请求拦截（默认 true）
    @objc public var enableHttp: Bool = true
    /// 是否开启 FPS 采样（默认 true）
    @objc public var enableFps: Bool = true
    /// 是否开启内存采样（默认 true）
    @objc public var enableMemory: Bool = true
    /// FPS / 内存采样间隔，单位秒（默认 2s）
    @objc public var samplingInterval: TimeInterval = 2.0
    /// HTTP 请求/响应体截取上限，单位字节（默认 8KB）
    @objc public var httpBodyMaxBytes: Int = 8192
    /// 是否打印 SDK 调试日志（默认 false）
    @objc public var debugLog: Bool = false
    /// 是否启用 gzip 压缩上报（默认 true）
    @objc public var gzip: Bool = true
    /// 当前环境：dev / sit / stag / pro（默认 pro）
    @objc public var env: String = "pro"
}

// MARK: - ObjC 桥接层

/// Objective-C 桥接层
///
/// `WFMonitor` 是 Swift `final class`，`WFConfig` 是 Swift `struct`，
/// Objective-C 无法直接调用。本类将全部 API 包装为 `@objc` 类方法，
/// ObjC 项目通过 `#import <WebfunnyMonitor/WebfunnyMonitor-Swift.h>` 即可使用。
@objc public class WFMonitorBridge: NSObject {

    // MARK: - 初始化

    /// 简易初始化（功能开关全部默认开启）
    @objc public static func setup(serverUrl: String, webMonitorId: String) {
        WFMonitor.setup(serverUrl: serverUrl, webMonitorId: webMonitorId)
    }

    /// 完整初始化（自定义功能开关）
    @objc public static func setup(
        serverUrl: String,
        webMonitorId: String,
        options: WFMonitorOptionsConfig
    ) {
        WFMonitor.setup(
            serverUrl: serverUrl,
            webMonitorId: webMonitorId,
            options: WFConfig.Options(
                enableCrash:      options.enableCrash,
                enableHttp:       options.enableHttp,
                enableFps:        options.enableFps,
                enableMemory:     options.enableMemory,
                samplingInterval: options.samplingInterval,
                httpBodyMaxBytes: options.httpBodyMaxBytes,
                debugLog:         options.debugLog,
                gzip:             options.gzip,
                env:              options.env
            )
        )
    }

    // MARK: - 用户信息

    /// 设置业务用户 ID（登录后调用，退出后传空字符串）
    @objc public static func setUserId(_ userId: String) {
        WFMonitor.setUserId(userId)
    }

    /// 设置自定义参数
    @objc public static func setUserParam(first: String, second: String) {
        WFMonitor.setUserParam(first: first, second: second)
    }

    // MARK: - 页面耗时追踪

    /// 手动开始一个页面耗时追踪
    /// - Parameter pageName: 页面名称
    /// - Returns: 追踪器对象，调用 `finish` 结束追踪
    @objc public static func startPageTrace(_ pageName: String) -> WFPageTracker {
        WFMonitor.startPageTrace(pageName)
    }

    // MARK: - 错误上报

    /// 上报业务层 catch 到的异常
    /// - Parameters:
    ///   - error: 被捕获的错误（NSError）
    ///   - errorScene: 错误场景描述（可选），如 "支付接口调用"
    @objc public static func reportError(_ error: NSError, errorScene: String = "") {
        WFMonitor.reportError(error, errorScene: errorScene)
    }

    // MARK: - 队列刷新

    /// 立即刷新上报队列
    @objc public static func flush() {
        WFMonitor.flush()
    }
}
