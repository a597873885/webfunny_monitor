import Foundation
import UIKit

/// 所有日志类型的公共基础字段
class WFBaseLog {

    let uploadType: String
    let webMonitorId: String
    let happenTime: String
    let customerKey: String
    let sessionId: String
    let userId: String
    let simpleUrl: String
    let completeUrl: String
    let projectVersion: String
    let firstUserParam: String
    let secondUserParam: String
    let platform: String
    let os: String
    let osVersion: String
    let deviceName: String
    let deviceBrand: String
    let deviceSize: String
    let appVersion: String
    let networkType: String
    let manufacturer: String
    let screenWidth: Int
    let screenHeight: Int
    let density: Int
    let language: String
    let timezone: String
    let carrier: String
    let sdkVersion: String
    let env: String

    init(uploadType: String, config: WFConfig) {
        self.uploadType    = uploadType
        self.webMonitorId  = config.webMonitorId
        self.happenTime    = String(Int64(Date().timeIntervalSince1970 * 1000))
        self.customerKey   = WFSession.shared.customerKey
        self.sessionId     = WFSession.shared.sessionId
        self.userId        = WFSession.shared.userId
        self.simpleUrl     = WFSession.shared.currentPage
        self.completeUrl   = WFSession.shared.currentPage
        self.firstUserParam  = WFSession.shared.firstUserParam
        self.secondUserParam = WFSession.shared.secondUserParam
        self.platform      = WFDeviceInfo.platform
        self.os            = WFDeviceInfo.os
        self.osVersion     = WFDeviceInfo.osVersion
        self.deviceName    = WFDeviceInfo.deviceName
        self.deviceBrand   = WFDeviceInfo.deviceBrand
        self.deviceSize    = WFDeviceInfo.deviceSize
        self.networkType   = WFDeviceInfo.networkType
        self.manufacturer  = WFDeviceInfo.manufacturer
        self.screenWidth   = WFDeviceInfo.screenWidth
        self.screenHeight  = WFDeviceInfo.screenHeight
        self.density       = WFDeviceInfo.density
        self.language      = WFDeviceInfo.language
        self.timezone      = WFDeviceInfo.timezone
        self.carrier       = WFDeviceInfo.carrier
        self.sdkVersion    = WFDeviceInfo.SDK_VERSION
        self.env           = config.env
        self.projectVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
        self.appVersion    = projectVersion
    }

    /// 子类重写此方法，追加自己的字段
    func toDict() -> [String: Any] {
        return [
            "uploadType":      uploadType,
            "webMonitorId":    webMonitorId,
            "happenTime":      happenTime,
            // 与 Web SDK 对齐：用户相关字符串、URL、版本号单独 base64 编码
            "customerKey":     b64(customerKey),
            "sessionId":       b64(sessionId),
            "userId":          b64(userId),
            "simpleUrl":       b64(simpleUrl),
            "completeUrl":     b64(completeUrl),
            "projectVersion":  b64(projectVersion),
            "firstUserParam":  b64(firstUserParam),
            "secondUserParam": b64(secondUserParam),
            "appVersion":      b64(appVersion),
            // 设备/系统字段不做 base64（服务端按明文存储）
            "platform":        platform,
            "os":              os,
            "osVersion":       osVersion,
            "deviceName":      deviceName,
            "deviceBrand":     deviceBrand,
            "deviceSize":      deviceSize,
            "networkType":     networkType,
            // 新增设备信息字段
            "manufacturer":    manufacturer,
            "screenWidth":     screenWidth,
            "screenHeight":    screenHeight,
            "density":         density,
            "language":        language,
            "timezone":        timezone,
            "carrier":         carrier,
            "sdkVersion":      sdkVersion,
            "env":             env
        ]
    }

    /// 将字符串 UTF-8 编码后做 base64，与 Web SDK 字段编码规则一致
    final func b64(_ str: String) -> String {
        Data(str.utf8).base64EncodedString()
    }
}
