import Foundation
import UIKit

/// UIViewController 页面加载耗时自动采集（Method Swizzling）
///
/// 测量区间：viewDidLoad 开始 → viewDidAppear 结束
/// 同时记录内存快照，供内存增量分析
final class WFPageCollector {

    private static var config: WFConfig!
    private static var pageRecords: [ObjectIdentifier: PageRecord] = [:]
    private static let lock = NSLock()
    fileprivate static var startupNotified = false
    /// 是否已上报过第一个 PV（用于区分 initial 和 navigation）
    fileprivate static var firstPVReported = false

    private struct PageRecord {
        let pageName: String
        let startMs: Double
        let memoryBefore: Int
        /// viewDidLoad 触发时为 true，Tab 切回 / pop 返回时为 false
        let isNewLoad: Bool
    }

    static func install(config: WFConfig) {
        self.config = config
        swizzle()
    }

    private static func swizzle() {
        let cls = UIViewController.self

        swizzlePair(cls,
            original: #selector(UIViewController.viewDidLoad),
            swizzled: #selector(UIViewController.wf_viewDidLoad)
        )
        swizzlePair(cls,
            original: #selector(UIViewController.viewDidAppear(_:)),
            swizzled: #selector(UIViewController.wf_pageViewDidAppear(_:))
        )
        swizzlePair(cls,
            original: #selector(UIViewController.viewDidDisappear(_:)),
            swizzled: #selector(UIViewController.wf_viewDidDisappear(_:))
        )
    }

    private static func swizzlePair(_ cls: AnyClass, original: Selector, swizzled: Selector) {
        guard let originalMethod = class_getInstanceMethod(cls, original) else {
            if config?.debugLog == true { print("[WFMonitor] ❌ swizzle 失败: 未找到原方法 \(original)") }
            return
        }
        guard let swizzledMethod = class_getInstanceMethod(cls, swizzled) else {
            if config?.debugLog == true { print("[WFMonitor] ❌ swizzle 失败: 未找到 swizzled 方法 \(swizzled)") }
            return
        }
        method_exchangeImplementations(originalMethod, swizzledMethod)
        if config?.debugLog == true { print("[WFMonitor] ✅ swizzle 成功: \(original)") }
    }

    static func recordStart(_ vc: UIViewController) {
        let key = ObjectIdentifier(vc)
        let name = String(describing: type(of: vc))
        let record = PageRecord(
            pageName:    name,
            startMs:     Date().timeIntervalSince1970 * 1000,
            memoryBefore: WFMemoryHelper.usedMemoryMB(),
            isNewLoad:   true
        )
        lock.lock()
        pageRecords[key] = record
        lock.unlock()
    }

    /// viewDidAppear 时调用：上报页面耗时（MOBILE_PAGE_LOAD）+ PV（CUSTOMER_PV）
    static func recordAppear(_ vc: UIViewController) {
        let key      = ObjectIdentifier(vc)
        let pageName = String(describing: type(of: vc))

        // ── 取 referrer（当前页面，更新前） ──────────────────
        let referrer = WFSession.shared.currentPage
        WFSession.shared.currentPage = pageName

        lock.lock()
        let record = pageRecords.removeValue(forKey: key)
        lock.unlock()

        guard let cfg = config else { return }

        // ── MOBILE_PAGE_LOAD（仅 viewDidLoad 触发过的新页面）──
        if let record = record, record.isNewLoad {
            let duration = Int(Date().timeIntervalSince1970 * 1000 - record.startMs)
            let pageLog = WFPageLoadLog(
                config:          cfg,
                pagePath:        pageName,
                loadType:        "navigation",
                firstRenderTime: duration,
                memoryBefore:    record.memoryBefore,
                memoryAfter:     WFMemoryHelper.usedMemoryMB(),
                avgFPS:          WFMemoryFpsCollector.shared.lastAvgFps,
                jankCount:       WFMemoryFpsCollector.shared.lastJankCount,
                severeJankCount: WFMemoryFpsCollector.shared.lastSevereJankCount
            )
            WFUploader.shared.enqueue(pageLog.toDict())
        }

        // ── CUSTOMER_PV（每次 viewDidAppear 均上报）──────────
        let loadType: String
        if !firstPVReported {
            loadType = "initial"
            firstPVReported = true
        } else if record?.isNewLoad == true {
            loadType = "navigation"
        } else {
            loadType = "back"
        }

        let pvLog = WFPVLog(
            config:    cfg,
            loadType:  loadType,
            newStatus: WFSession.shared.isNewUser,
            referrer:  referrer
        )
        WFUploader.shared.enqueue(pvLog.toDict())
    }
}

// MARK: - UIViewController extension（Swizzled 方法）

extension UIViewController {
    @objc dynamic func wf_viewDidLoad() {
        wf_viewDidLoad()
        WFPageCollector.recordStart(self)
    }

    @objc dynamic func wf_pageViewDidAppear(_ animated: Bool) {
        wf_pageViewDidAppear(animated)
        // 上报 MOBILE_PAGE_LOAD + CUSTOMER_PV，同时更新 WFSession.currentPage
        WFPageCollector.recordAppear(self)
        // 首个 viewDidAppear → 触发启动耗时上报
        if !WFPageCollector.startupNotified {
            WFPageCollector.startupNotified = true
            NotificationCenter.default.post(
                name: WFStartupCollector.firstVCDidAppearNotification,
                object: self
            )
        }
    }

    @objc dynamic func wf_viewDidDisappear(_ animated: Bool) {
        wf_viewDidDisappear(animated)
    }
}
