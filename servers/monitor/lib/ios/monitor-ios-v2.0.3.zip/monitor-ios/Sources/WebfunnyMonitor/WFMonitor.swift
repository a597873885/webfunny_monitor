import Foundation
import UIKit

/// Webfunny iOS 监控 SDK 唯一对外入口
///
/// ── 接入步骤 ──────────────────────────────────────────────────────
///
/// 1. 在 App 启动最早处初始化（@main / AppDelegate.didFinishLaunching）
///
///    @main
///    struct MyApp: App {
///        init() {
///            WFMonitor.setup(
///                serverUrl:    "https://monitor.example.com",
///                webMonitorId: "your_id"
///            )
///        }
///        var body: some Scene { WindowGroup { ContentView() } }
///    }
///
/// 2. 用户登录后设置 userId
///    WFMonitor.setUserId("user_123")
///
/// 3. 手动追踪页面耗时（SwiftUI / 不使用 UIViewController 时）
///    let tracker = WFMonitor.startPageTrace("HomeView")
///    tracker.finish()
public final class WFMonitor {

    private static var config: WFConfig!

    private init() {}

    /// 初始化 SDK
    ///
    /// - Parameters:
    ///   - serverUrl:    监控服务器地址，如 "https://monitor.example.com"
    ///   - webMonitorId: 项目监控 ID，在 Webfunny 控制台获取
    ///   - options:      功能开关配置，默认全部开启
    ///
    /// 示例：
    /// ```swift
    /// WFMonitor.setup(
    ///     serverUrl:    "https://monitor.example.com",
    ///     webMonitorId: "abc123",
    ///     options: WFConfig.Options(enableCrash: true, enableHttp: true)
    /// )
    /// ```
    public static func setup(
        serverUrl: String,
        webMonitorId: String,
        options: WFConfig.Options = WFConfig.Options()
    ) {
        var cfg = WFConfig(
            serverUrl:    serverUrl,
            webMonitorId: webMonitorId,
            enableCrash:  options.enableCrash,
            enableHttp:   options.enableHttp,
            enableFps:    options.enableFps,
            enableMemory: options.enableMemory,
            debugLog:     options.debugLog,
            gzip:         options.gzip,
            env:          options.env
        )
        cfg.samplingInterval = options.samplingInterval
        cfg.httpBodyMaxBytes = options.httpBodyMaxBytes
        config = cfg

        // 恢复上次保存的用户信息
        WFSession.shared.restoreUser()

        WFUploader.shared.setup(config: cfg)
        WFStartupCollector.markSdkInit()

        if cfg.enableCrash {
            WFCrashCollector.install(config: cfg)
        }

        WFStartupCollector.install(config: cfg)
        WFPageCollector.install(config: cfg)

        if cfg.enableHttp {
            WFHttpInterceptor.install(config: cfg)
        }
        if cfg.enableFps || cfg.enableMemory {
            WFMemoryFpsCollector.shared.start(config: cfg)
        }

        // 进入后台时刷新队列
        NotificationCenter.default.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil,
            queue: nil
        ) { _ in WFUploader.shared.flushNow() }

        // 即将失去焦点时兜底 flush（覆盖 willResignActive 场景）
        NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: nil
        ) { _ in WFUploader.shared.flushNow() }

        // 内存警告时兜底 flush
        NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil,
            queue: nil
        ) { _ in WFUploader.shared.flushNow() }

        // 异步拉取服务端配置（签名等）
        let initQueue = DispatchQueue(label: "com.webfunny.monitor.init", qos: .utility)
        initQueue.async { Self.fetchServerConfig(cfg) }
    }

    /// 设置业务用户 ID（登录后调用，退出后传空字符串）
    public static func setUserId(_ userId: String) {
        WFSession.shared.userId = userId
    }

    /// 设置自定义参数
    public static func setUserParam(first: String = "", second: String = "") {
        WFSession.shared.firstUserParam  = first
        WFSession.shared.secondUserParam = second
    }

    /// 手动开始一个页面耗时追踪（适用于 SwiftUI View / 自定义页面）
    ///
    /// let tracker = WFMonitor.startPageTrace("HomeView")
    /// tracker.finish()
    public static func startPageTrace(_ pageName: String) -> WFPageTracker {
        guard let cfg = config else {
            fatalError("WFMonitor.setup() 尚未调用")
        }
        return WFPageTracker(pageName: pageName, config: cfg)
    }

    /// 立即刷新上报队列
    public static func flush() {
        WFUploader.shared.flushNow()
    }

    /// 上报业务层 catch 到的异常（不会导致崩溃的错误）
    ///
    /// ```swift
    /// do {
    ///     try riskyOperation()
    /// } catch {
    ///     WFMonitor.reportError(error, errorScene: "支付接口调用")
    /// }
    /// ```
    ///
    /// - Parameters:
    ///   - error:      被捕获的错误
    ///   - errorScene: 错误场景描述（可选），如 "加载用户列表"
    public static func reportError(_ error: Error, errorScene: String = "") {
        guard let cfg = config else {
            fatalError("WFMonitor.setup() 尚未调用")
        }
        let log = WFErrorLog(config: cfg, error: error, errorScene: errorScene)
        WFUploader.shared.enqueue(log.toDict())
        if cfg.debugLog {
            print("[WFMonitor] [错误] \(String(describing: type(of: error))): \(error.localizedDescription) → 已入队")
        }
    }

    // MARK: - 内部：拉取服务端配置

    private static func fetchServerConfig(_ cfg: WFConfig) {
        guard let url = URL(string: cfg.initCfUrl) else { return }

        let bodyObj: [String: Any] = ["webMonitorId": cfg.webMonitorId]
        guard let body = try? JSONSerialization.data(withJSONObject: bodyObj) else { return }

        if cfg.debugLog {
            print("[WFMonitor] initCf 请求: \(url.absoluteString)")
        }

        var request = URLRequest(url: url, timeoutInterval: 10)
        request.httpMethod = "POST"
        request.setValue("application/json;charset=UTF-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error {
                if cfg.debugLog { print("[WFMonitor] initCf 请求失败：\(error.localizedDescription)") }
                return
            }
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard let data, (200...299).contains(code) else { return }

            if cfg.debugLog {
                print("[WFMonitor] initCf 响应：状态码=\(code)")
            }
            parseServerConfig(data, cfg: cfg)
        }.resume()
    }

    private static func parseServerConfig(_ data: Data, cfg: WFConfig) {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let dataObj = root["data"] as? [String: Any]
        else { return }

        if let signature = dataObj["signature"] as? String, !signature.isEmpty {
            UserDefaults.standard.set(signature, forKey: "wf_monitor_signature")
            if cfg.debugLog { print("[WFMonitor] initCf 成功，signature 已更新") }
        }
    }
}
