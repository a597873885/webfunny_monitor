import Foundation

/// SDK 初始化配置
///
/// 推荐用法（与文档一致）：
/// ```swift
/// WFMonitor.setup(
///     serverUrl:    "https://monitor.example.com",
///     webMonitorId: "abc123",
///     options: WFConfig.Options(
///         enableCrash:  true,
///         enableHttp:   true,
///         enableFps:    true,
///         enableMemory: true
///     )
/// )
/// ```
public struct WFConfig {

    /// 监控服务器地址，不含路径，如 https://monitor.example.com
    public let serverUrl: String

    /// 项目监控 ID，在 Webfunny 控制台创建项目后获取
    public let webMonitorId: String

    /// 是否开启崩溃采集（默认 true）
    public var enableCrash: Bool = true

    /// 是否开启 HTTP 网络拦截（默认 true）
    public var enableHttp: Bool = true

    /// 是否开启 FPS 采样（默认 true）
    public var enableFps: Bool = true

    /// 是否开启内存采样（默认 true）
    public var enableMemory: Bool = true

    /// FPS / 内存采样间隔，单位秒（默认 2s）
    public var samplingInterval: TimeInterval = 2.0

    /// 队列最大条数，超出后立即上报（默认 20）
    public var maxQueueSize: Int = 20

    /// 定时刷新间隔，单位秒（默认 10s）
    public var flushInterval: TimeInterval = 10.0

    /// Debug 模式下是否打印 SDK 日志
    public var debugLog: Bool = false

    /// HTTP 请求/响应体截取上限，单位字节（默认 8KB)
    public var httpBodyMaxBytes: Int = 8192

    /// 是否启用 gzip 压缩上报（默认 true）
    public var gzip: Bool = true

    /// 当前环境：dev / sit / stag / pro（默认 pro）
    public var env: String = "pro"

    /// 完整上报地址
    internal var uploadUrl: String { "\(serverUrl)/wfMonitor/upLogs" }

    /// 服务端配置拉取地址
    internal var initCfUrl: String { "\(serverUrl)/wfMonitor/initCf" }

    public init(
        serverUrl: String,
        webMonitorId: String,
        enableCrash: Bool = true,
        enableHttp: Bool = true,
        enableFps: Bool = true,
        enableMemory: Bool = true,
        debugLog: Bool = false,
        gzip: Bool = true,
        env: String = "pro"
    ) {
        self.serverUrl    = serverUrl
        self.webMonitorId = webMonitorId
        self.enableCrash  = enableCrash
        self.enableHttp   = enableHttp
        self.enableFps    = enableFps
        self.enableMemory = enableMemory
        self.debugLog     = debugLog
        self.gzip         = gzip
        self.env          = env
    }
}

// MARK: - WFConfig.Options
//
// 独立的功能开关结构体，与 WFMonitor.setup(serverUrl:webMonitorId:options:) 配合使用，
// 让接入代码更语义化，serverUrl / webMonitorId 不会出现在 Options 里造成混淆。
extension WFConfig {
    public struct Options {
        public var enableCrash:  Bool
        public var enableHttp:   Bool
        public var enableFps:    Bool
        public var enableMemory: Bool
        public var samplingInterval: TimeInterval
        public var httpBodyMaxBytes: Int
        public var debugLog:     Bool
        public var gzip:         Bool
        public var env:          String

        public init(
            enableCrash:  Bool = true,
            enableHttp:   Bool = true,
            enableFps:    Bool = true,
            enableMemory: Bool = true,
            samplingInterval: TimeInterval = 2.0,
            httpBodyMaxBytes: Int = 8192,
            debugLog:     Bool = false,
            gzip:         Bool = true,
            env:          String = "pro"
        ) {
            self.enableCrash      = enableCrash
            self.enableHttp       = enableHttp
            self.enableFps        = enableFps
            self.enableMemory     = enableMemory
            self.samplingInterval = samplingInterval
            self.httpBodyMaxBytes = httpBodyMaxBytes
            self.debugLog         = debugLog
            self.gzip             = gzip
            self.env              = env
        }
    }
}
