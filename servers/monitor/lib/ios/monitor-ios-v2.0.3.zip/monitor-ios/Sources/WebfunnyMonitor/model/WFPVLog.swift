import Foundation

/// CUSTOMER_PV（页面 PV）→ MobilePerformanceLog
///
/// 与 H5 SDK pageView.js 的 getPageViewInfo 字段对齐：
///   - pageKey    : 本次 PV 的唯一标识（UUID）
///   - loadType   : initial / navigation / back
///   - newStatus  : 1=新用户（首次安装）/ 0=回访
///   - referrer   : 上一个页面名称（base64），首页为空
///   - monitorIp / country / province / city : 服务端填充，客户端上报空字符串
///
/// 浏览器专属字段（browserName / browserVersion）移动端不适用，省略。
final class WFPVLog: WFBaseLog {

    let pageKey:   String
    let loadType:  String
    let newStatus: Int
    let referrer:  String
    let monitorIp: String
    let country:   String
    let province:  String
    let city:      String

    init(
        config:    WFConfig,
        loadType:  String,
        newStatus: Int,
        referrer:  String
    ) {
        self.pageKey   = UUID().uuidString.replacingOccurrences(of: "-", with: "")
        self.loadType  = loadType
        self.newStatus = newStatus
        self.referrer  = referrer
        self.monitorIp = ""
        self.country   = ""
        self.province  = ""
        self.city      = ""
        super.init(uploadType: "CUSTOMER_PV", config: config)
    }

    override func toDict() -> [String: Any] {
        var d = super.toDict()
        d["pageKey"]   = pageKey
        d["loadType"]  = loadType
        d["newStatus"] = newStatus
        d["referrer"]  = b64(referrer)
        d["monitorIp"] = monitorIp
        d["country"]   = country
        d["province"]  = province
        d["city"]      = city
        return d
    }
}
