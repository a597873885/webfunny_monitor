import Foundation

/// HTTP_LOG → 与 H5 SDK 字段对齐
final class WFHttpLog: WFBaseLog {

    let method: String
    let httpUrl: String       // 完整请求 URL
    let simpleHttpUrl: String // 去掉 query 的简洁 URL
    let loadTime: Int
    let dnsTime: Int
    let tcpTime: Int
    let sslTime: Int
    let ttfbTime: Int
    let downloadTime: Int
    let status: Int
    let requestSize: Int64
    let responseSize: Int64
    let isTimeout: Int
    let statusText: String
    let statusResult: String
    let traceId: String
    let totalDuration: Int
    let headerText: String    // 请求头（b64）
    let requestText: String   // 请求体（b64）
    let responseText: String  // 响应体（b64）
    let segment: String

    init(
        config: WFConfig,
        method: String,
        httpUrl: String,
        loadTime: Int,
        status: Int,
        requestSize: Int64 = 0,
        responseSize: Int64 = 0,
        dnsTime: Int = 0,
        tcpTime: Int = 0,
        sslTime: Int = 0,
        ttfbTime: Int = 0,
        downloadTime: Int = 0,
        isTimeout: Int = 0,
        statusText: String = "",
        traceId: String = "",
        headerText: String = "",
        requestText: String = "",
        responseText: String = "",
        segment: String = ""
    ) {
        self.method        = method
        self.httpUrl       = httpUrl
        self.simpleHttpUrl = URL(string: httpUrl).map { "\($0.scheme ?? "")://\($0.host ?? "")\($0.path)" } ?? httpUrl
        self.loadTime      = loadTime
        self.dnsTime       = dnsTime
        self.tcpTime       = tcpTime
        self.sslTime       = sslTime
        self.ttfbTime      = ttfbTime
        self.downloadTime  = downloadTime
        self.status        = status
        self.requestSize   = requestSize
        self.responseSize  = responseSize
        self.isTimeout     = isTimeout
        self.statusText    = statusText
        self.statusResult  = (200...299).contains(status) ? "response" : "request"
        self.traceId       = traceId
        self.totalDuration = loadTime
        self.headerText    = headerText
        self.requestText   = requestText
        self.responseText  = responseText
        self.segment       = segment
        super.init(uploadType: "HTTP_LOG", config: config)
    }

    override func toDict() -> [String: Any] {
        var d = super.toDict()
        // 覆盖 WFBaseLog 的页面 simpleUrl / completeUrl，改为本次 HTTP 请求的 URL（与 H5 保持一致）
        d["simpleUrl"]     = b64(simpleHttpUrl)
        d["httpUrl"]       = b64(httpUrl)
        d["method"]        = method
        d["loadTime"]      = loadTime
        d["dnsTime"]       = dnsTime
        d["tcpTime"]       = tcpTime
        d["sslTime"]       = sslTime
        d["ttfbTime"]      = ttfbTime
        d["downloadTime"]  = downloadTime
        d["status"]        = status
        d["requestSize"]   = requestSize
        d["responseSize"]  = responseSize
        d["isTimeout"]     = isTimeout
        d["statusText"]    = statusText
        d["statusResult"]  = statusResult
        d["traceId"]       = traceId
        d["totalDuration"] = totalDuration
        d["headerText"]    = b64(headerText)
        d["requestText"]   = b64(requestText)
        d["responseText"]  = b64(responseText)
        d["segment"]       = segment
        return d
    }
}
