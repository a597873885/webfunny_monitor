import Foundation
import Compression

// MARK: - Data+gzip 扩展（使用 Compression.framework，零额外依赖）

private extension Data {

    /// 使用 COMPRESSION_ZLIB 压缩并包装为 gzip 格式
    func gzipCompressed() -> Data? {
        guard !isEmpty else { return nil }

        // 1. 压缩（COMPRESSION_ZLIB 产出 raw deflate）
        guard let deflateBody = self.compress() else { return nil }

        // 2. 组装 gzip 帧
        var gzip = Data()
        gzip.append(contentsOf: [0x1f, 0x8b, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff])
        gzip.append(deflateBody)
        var crc = self.crc32Value()
        Swift.withUnsafeBytes(of: &crc) { gzip.append(contentsOf: $0) }
        var isize = UInt32(count & 0xffffffff)
        Swift.withUnsafeBytes(of: &isize) { gzip.append(contentsOf: $0) }
        return gzip
    }

    /// 压缩为 raw deflate（不包装 zlib/gzip 帧）
    private func compress() -> Data? {
        let dstCapacity = count + 512
        let dst = UnsafeMutablePointer<UInt8>.allocate(capacity: dstCapacity)
        defer { dst.deallocate() }

        let written = withUnsafeBytes { src -> Int in
            guard let srcBase = src.baseAddress else { return 0 }
            return compression_encode_buffer(
                dst, dstCapacity,
                srcBase.assumingMemoryBound(to: UInt8.self), count,
                nil, COMPRESSION_ZLIB
            )
        }
        guard written > 0 else { return nil }
        return Data(bytes: dst, count: written)
    }

    /// 标准 CRC32（多项式 0xEDB88320）
    private func crc32Value() -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in self {
            let idx = Int((crc ^ UInt32(byte)) & 0xff)
            crc = (crc >> 8) ^ Self.crc32Table[idx]
        }
        return crc ^ 0xffffffff
    }

    private static let crc32Table: [UInt32] = {
        var table = [UInt32](repeating: 0, count: 256)
        for i in 0..<256 {
            var c = UInt32(i)
            for _ in 0..<8 {
                c = (c >> 1) ^ ((c & 1) * 0xedb88320)
            }
            table[i] = c
        }
        return table
    }()
}

/// 批量队列上报核心
///
/// 策略：
///   1. 日志先入内存队列
///   2. 满 maxQueueSize 条，或定时器到期触发批量上报
///   3. flush 时先持久化到磁盘（进程被杀也不丢），再网络上报
///   4. body > 1KB 时 gzip 压缩
///   5. 上报失败进入重试（4s → 16s → 32s，最多 3 次）
///   6. 启动时扫描残留文件并恢复重试
///   7. 所有 I/O 操作在后台队列执行
final class WFUploader {

    static let shared = WFUploader()
    private init() {}

    private let maxRetry = 3
    private let gzipThreshold = 1024  // 1 KB

    private var config: WFConfig!
    private var queue: [[String: Any]] = []
    private let lock = NSLock()
    private var timer: Timer?
    private let workQueue = DispatchQueue(label: "com.webfunny.monitor.uploader", qos: .utility)
    private let retryQueue = DispatchQueue(label: "com.webfunny.monitor.retry", qos: .utility)

    /// 签名存储 key
    private let signatureKey = "wf_monitor_signature"

    func setup(config: WFConfig) {
        self.config = config
        startTimer()
        // 启动恢复：扫描残留批次文件并重试
        workQueue.async { self.recoverPendingBatches() }
        // 启动清理
        workQueue.async { WFDiskManager.cleanExpired() }
        workQueue.async { WFDiskManager.enforceDiskLimit() }
    }

    /// 加入队列
    func enqueue(_ log: [String: Any]) {
        lock.lock()
        queue.append(log)
        let shouldFlush = queue.count >= config.maxQueueSize
        lock.unlock()
        if shouldFlush {
            workQueue.async { self.flush() }
        }
    }

    /// 立即刷新（App 进入后台时调用）
    func flushNow() {
        workQueue.async { self.flush() }
    }

    // MARK: - Private

    private func startTimer() {
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(
                withTimeInterval: self.config.flushInterval,
                repeats: true
            ) { [weak self] _ in
                self?.workQueue.async { self?.flush() }
            }
        }
    }

    private func flush() {
        lock.lock()
        guard !queue.isEmpty else { lock.unlock(); return }
        let batch = queue
        queue.removeAll()
        lock.unlock()

        // ① 先持久化到磁盘（进程被杀也不丢）
        let fileURL = WFDiskManager.saveBatch(batch)

        // ② 网络上报（成功后删磁盘文件，失败由重试机制兜底）
        if config.debugLog {
            print("[WFMonitor] ⬆️ 开始上报 \(batch.count) 条 → \(config.uploadUrl)")
        }
        upload(batch, fileURL: fileURL)
    }

    /// 上报一批日志，失败时启动重试
    private func upload(_ logs: [[String: Any]], fileURL: URL?, retryCount: Int = 0) {
        guard let url = URL(string: config.uploadUrl) else {
            if config.debugLog { print("[WFMonitor] ❌ 无效的上报 URL: \(config.uploadUrl)") }
            return
        }
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: logs)
            var body = jsonData
            var useGzip = false

            // gzip 压缩（body > 1KB 且 config.gzip 为 true 时启用）
            if config.gzip, body.count > gzipThreshold, let compressed = body.gzipCompressed() {
                body = compressed
                useGzip = true
            }

            // 注入请求签名（防篡改）
            let signature = WFSignature.generate(
                storedSignature: UserDefaults.standard.string(forKey: signatureKey) ?? "",
                webMonitorId: config.webMonitorId
            )

            if config.debugLog {
                print("[WFMonitor] ⬆️ 上报 \(logs.count) 条, gzip=\(useGzip), 大小=\(body.count) bytes")
                print("[WFMonitor]    Body 前 300 字符: \(String(data: jsonData, encoding: .utf8)?.prefix(300) ?? "")")
            }

            var request = URLRequest(url: url, timeoutInterval: 10)
            request.httpMethod = "POST"
            request.setValue("application/json;charset=UTF-8", forHTTPHeaderField: "Content-Type")
            if useGzip {
                request.setValue("gzip", forHTTPHeaderField: "Content-Encoding")
            }
            if !signature.isEmpty {
                request.setValue(signature, forHTTPHeaderField: "wf-signature")
            }
            request.httpBody = body

            URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
                guard let self else { return }

                if let error = error {
                    if self.config.debugLog {
                        print("[WFMonitor] ❌ 上报网络错误: \(error.localizedDescription)")
                    }
                    if let fileURL { self.scheduleRetry(fileURL, currentRetry: retryCount) }
                    return
                }

                let code = (response as? HTTPURLResponse)?.statusCode ?? 0
                let respStr = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""

                if self.config.debugLog {
                    if (200...299).contains(code) {
                        print("[WFMonitor] ✅ 上报成功 \(logs.count) 条，HTTP \(code)")
                    } else {
                        print("[WFMonitor] ❌ 上报失败，HTTP \(code)")
                        print("[WFMonitor]    响应体: \(respStr.prefix(200))")
                    }
                }

                if (200...299).contains(code) {
                    // 成功：删除磁盘文件
                    if let fileURL { WFDiskManager.deleteBatch(fileURL) }
                } else {
                    if let fileURL { self.scheduleRetry(fileURL, currentRetry: retryCount) }
                }
            }.resume()
        } catch {
            if config.debugLog { print("[WFMonitor] ❌ JSON 序列化失败：\(error)") }
        }
    }

    // MARK: - 重试机制

    /// 调度重试：4s → 16s → 32s，最多 3 次
    private func scheduleRetry(_ fileURL: URL, currentRetry: Int) {
        guard currentRetry < maxRetry else {
            print("[WFMonitor] 重试已达上限 \(maxRetry) 次，删除文件: \(fileURL.lastPathComponent)")
            WFDiskManager.deleteBatch(fileURL)
            return
        }

        let delay: TimeInterval = switch currentRetry {
            case 0: 4
            case 1: 16
            default: 32
        }

        if config.debugLog {
            print("[WFMonitor] 计划第 \(currentRetry + 1) 次重试（\(Int(delay))s 后）: \(fileURL.lastPathComponent)")
        }

        retryQueue.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self else { return }
            guard let newURL = WFDiskManager.renameForRetry(fileURL) else {
                print("[WFMonitor] rename 失败，删除文件: \(fileURL.lastPathComponent)")
                WFDiskManager.deleteBatch(fileURL)
                return
            }
            self.retryUpload(newURL, retryCount: currentRetry + 1)
        }
    }

    private func retryUpload(_ fileURL: URL, retryCount: Int) {
        guard let data = try? Data(contentsOf: fileURL),
              let logs = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]]
        else {
            scheduleRetry(fileURL, currentRetry: retryCount)
            return
        }
        if config.debugLog {
            print("[WFMonitor] 第 \(retryCount) 次重试上传: \(fileURL.lastPathComponent)（\(logs.count) 条）")
        }
        upload(logs, fileURL: fileURL, retryCount: retryCount)
    }

    // MARK: - 启动恢复

    private func recoverPendingBatches() {
        // 先恢复旧版崩溃文件（CrashCollector 同步写入 UserDefaults 的 wf_retry_queue）
        recoverLegacyCrashLogs()

        let files = WFDiskManager.loadAllBatches()
        guard !files.isEmpty else {
            if config.debugLog { print("[WFMonitor] 🔍 无待恢复批次文件") }
            return
        }

        if config.debugLog { print("[WFMonitor] 🔄 发现 \(files.count) 个待恢复批次文件") }

        for file in files {
            let retry = WFDiskManager.parseRetry(file)
            if retry >= maxRetry {
                if config.debugLog { print("[WFMonitor] 文件已超最大重试次数，删除: \(file.lastPathComponent)") }
                WFDiskManager.deleteBatch(file)
                continue
            }
            // 超过 2 分钟的老文件，直接重试；否则按正常调度
            let fileAge = Date().timeIntervalSince1970 - (file.lastModifiedDate?.timeIntervalSince1970 ?? 0)
            if fileAge > 120 {
                if config.debugLog { print("[WFMonitor] 老文件（\(Int(fileAge))s），跳过等待直接重试: \(file.lastPathComponent)") }
                retryUpload(file, retryCount: retry)
            } else {
                scheduleRetry(file, currentRetry: retry)
            }
        }
    }

    /// 恢复旧版崩溃日志（之前用 UserDefaults 存储的 wf_retry_queue）
    private func recoverLegacyCrashLogs() {
        let legacyKey = "wf_retry_queue"
        guard let str = UserDefaults.standard.string(forKey: legacyKey),
              let data = str.data(using: .utf8),
              let logs = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]],
              !logs.isEmpty
        else { return }

        if config.debugLog { print("[WFMonitor] 🔄 发现旧版崩溃日志 \(logs.count) 条，开始恢复") }

        // 转存到 DiskManager 并上传
        let batchFile = WFDiskManager.saveBatch(logs)
        upload(logs, fileURL: batchFile)

        // 清除旧版存储
        UserDefaults.standard.removeObject(forKey: legacyKey)
    }

    // MARK: - 崩溃同步写盘

    /// 崩溃时调用：同步写入磁盘文件，进程退出后数据不丢失
    /// 不走网络，下次冷启动由 recoverPendingBatches 统一补报
    func saveCrashLogSync(_ log: [String: Any]) {
        print("[WFMonitor-Crash] 📝 saveCrashLogSync 开始写盘...")
        let fileURL = WFDiskManager.saveBatch([log])
        if fileURL != nil {
            print("[WFMonitor-Crash] ✅ 写盘成功，下次启动补报")
        } else {
            print("[WFMonitor-Crash] ❌ 写盘失败")
        }
    }
}

private extension URL {
    var lastModifiedDate: Date? {
        (try? resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
    }
}

