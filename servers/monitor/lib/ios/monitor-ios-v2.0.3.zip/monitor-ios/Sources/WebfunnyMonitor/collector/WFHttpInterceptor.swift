import Foundation

/// NSURLProtocol 网络拦截
///
/// 原理：注册自定义 NSURLProtocol，系统所有 NSURLSession/NSURLConnection 请求均经过
/// 风险：iOS 系统级 API，FLEX/Charles 抓包原理相同，稳定可靠
///
/// 接入：WFMonitor.setup() 内部自动调用，无需手动操作
///
/// 注意：WKWebView 的请求默认不经过 NSURLProtocol，需额外处理（本 SDK 暂不支持）
final class WFHttpInterceptor: URLProtocol {

    private static var config: WFConfig!
    private static let handledKey = "wf_handled"
    private var startMs: Double = 0
    private var traceId: String = ""
    private var wf_task: URLSessionDataTask?
    private var responseData = Data()

    static func install(config: WFConfig) {
        self.config = config
        URLProtocol.registerClass(WFHttpInterceptor.self)
    }

    // MARK: - URLProtocol

    override class func canInit(with request: URLRequest) -> Bool {
        // 防止无限递归：已经处理过的请求不再拦截
        if URLProtocol.property(forKey: handledKey, in: request) != nil { return false }
        guard let url = request.url?.absoluteString else { return false }
        // 不拦截监控自身的上报请求，避免循环
        return !url.contains("/wfMonitor/upLogs")
    }

    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }

    override func startLoading() {
        traceId = UUID().uuidString.replacingOccurrences(of: "-", with: "")
        startMs = Date().timeIntervalSince1970 * 1000

        guard let mutableRequest = (request as NSURLRequest).mutableCopy() as? NSMutableURLRequest else { return }
        URLProtocol.setProperty(true, forKey: Self.handledKey, in: mutableRequest)
        mutableRequest.addValue(traceId, forHTTPHeaderField: "wf-trace-id")

        let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        wf_task = session.dataTask(with: mutableRequest as URLRequest)
        wf_task?.resume()
    }

    override func stopLoading() {
        wf_task?.cancel()
    }
}

// MARK: - URLSessionDataDelegate

extension WFHttpInterceptor: URLSessionDataDelegate {

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
                    didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        client?.urlProtocol(self, didLoad: data)
        responseData.append(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        defer { client?.urlProtocolDidFinishLoading(self) }

        guard let cfg = Self.config else { return }
        let duration   = Int(Date().timeIntervalSince1970 * 1000 - startMs)
        let url        = request.url?.absoluteString ?? ""
        let method     = request.httpMethod ?? "GET"
        let status     = (task.response as? HTTPURLResponse)?.statusCode ?? 0
        let reqSize    = Int64(request.httpBody?.count ?? 0)
        let respSize   = Int64(responseData.count)
        let isTimeout  = (error as? URLError)?.code == .timedOut ? 1 : 0

        // 请求头序列化
        let headerText = (request.allHTTPHeaderFields ?? [:])
            .map { "\($0.key): \($0.value)" }
            .sorted()
            .joined(separator: "\n")

        // 请求体（截断至配置上限）
        let maxBytes = cfg.httpBodyMaxBytes
        let requestText: String
        if let body = request.httpBody, !body.isEmpty {
            requestText = String(data: body, encoding: .utf8)
                .map { String($0.prefix(maxBytes)) } ?? "(binary)"
        } else {
            requestText = ""
        }

        // 响应体（截断至配置上限）
        let responseText = responseData.isEmpty ? "" :
            (String(data: responseData, encoding: .utf8).map { String($0.prefix(maxBytes)) } ?? "(binary)")

        let log = WFHttpLog(
            config:       cfg,
            method:       method,
            httpUrl:      url,
            loadTime:     duration,
            status:       status,
            requestSize:  reqSize,
            responseSize: respSize,
            isTimeout:    isTimeout,
            statusText:   (task.response as? HTTPURLResponse).map { HTTPURLResponse.localizedString(forStatusCode: $0.statusCode) } ?? "",
            traceId:      traceId,
            headerText:   headerText,
            requestText:  requestText,
            responseText: responseText
        )
        WFUploader.shared.enqueue(log.toDict())

        if let error = error {
            client?.urlProtocol(self, didFailWithError: error)
        }
    }
}
