import Foundation

/// APP_START → MobilePerformanceLog
final class WFStartupLog: WFBaseLog {

    let startType: String
    let processStartTime: Int
    let applicationInitTime: Int
    let splashScreenTime: Int
    let mainPageCreateTime: Int
    let firstFrameRenderTime: Int
    let totalDuration: Int

    init(
        config: WFConfig,
        startType: String,
        processStartTime: Int,
        applicationInitTime: Int,
        splashScreenTime: Int,
        mainPageCreateTime: Int,
        firstFrameRenderTime: Int
    ) {
        self.startType            = startType
        self.processStartTime     = processStartTime
        self.applicationInitTime  = applicationInitTime
        self.splashScreenTime     = splashScreenTime
        self.mainPageCreateTime   = mainPageCreateTime
        self.firstFrameRenderTime = firstFrameRenderTime
        self.totalDuration        = processStartTime + applicationInitTime + firstFrameRenderTime
        super.init(uploadType: "APP_START", config: config)
    }

    override func toDict() -> [String: Any] {
        var d = super.toDict()
        d["startType"]            = startType
        d["processStartTime"]     = processStartTime
        d["applicationInitTime"]  = applicationInitTime
        d["splashScreenTime"]     = splashScreenTime
        d["mainPageCreateTime"]   = mainPageCreateTime
        d["firstFrameRenderTime"] = firstFrameRenderTime
        d["totalDuration"]        = totalDuration
        return d
    }
}
