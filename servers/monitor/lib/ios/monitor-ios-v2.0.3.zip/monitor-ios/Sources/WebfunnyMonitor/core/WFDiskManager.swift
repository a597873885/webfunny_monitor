import Foundation

/// 磁盘批次持久化管理（对标 Android WFDiskManager / iOS WFEventDiskManager）
///
/// - 一个批次一个文件，文件名包含重试计数
/// - 5 MB FIFO 上限 + 7 天过期清理
enum WFDiskManager {

    private static let batchDirName = "wf_monitor"
    private static let maxDiskSize: Int64 = 5 * 1024 * 1024  // 5 MB
    private static let expireSeconds: TimeInterval = 7 * 24 * 3600  // 7 天

    // MARK: - 目录

    private static func batchDir() -> URL? {
        guard let caches = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first
        else { return nil }
        let dir = caches.appendingPathComponent(batchDirName)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    // MARK: - 保存

    /// 保存一批日志到磁盘文件
    /// - Returns: 文件 URL，失败返回 nil
    static func saveBatch(_ logs: [[String: Any]]) -> URL? {
        guard let dir = batchDir() else { return nil }
        guard let data = try? JSONSerialization.data(withJSONObject: logs) else { return nil }

        let ts = Int64(Date().timeIntervalSince1970 * 1000)
        let uuid = UUID().uuidString.prefix(8)
        let fileName = "wf_monitor_batch_0_\(ts)_\(uuid).json"
        let fileURL = dir.appendingPathComponent(fileName)

        do {
            try data.write(to: fileURL, options: .atomic)
        } catch {
            print("[WFDiskManager] 写入批次文件失败: \(error.localizedDescription)")
            return nil
        }

        // 写入后检查磁盘上限
        enforceDiskLimit()
        return fileURL
    }

    // MARK: - 加载

    /// 加载所有待处理的批次文件（按时间排序）
    static func loadAllBatches() -> [URL] {
        guard let dir = batchDir() else { return [] }
        guard let files = try? FileManager.default.contentsOfDirectory(
            at: dir,
            includingPropertiesForKeys: [.contentModificationDateKey],
            options: .skipsHiddenFiles
        ) else { return [] }

        return files
            .filter { $0.lastPathComponent.hasPrefix("wf_monitor_batch_") }
            .sorted { url1, url2 in
                let d1 = (try? url1.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? Date.distantPast
                let d2 = (try? url2.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? Date.distantPast
                return d1 < d2
            }
    }

    // MARK: - 删除

    /// 上报成功后删除批次文件
    static func deleteBatch(_ fileURL: URL) {
        try? FileManager.default.removeItem(at: fileURL)
    }

    // MARK: - 重试

    /// 从文件名解析重试次数
    /// 文件名格式：wf_monitor_batch_{retry}_{timestamp}_{uuid}.json
    static func parseRetry(_ fileURL: URL) -> Int {
        let name = fileURL.lastPathComponent
        let parts = name.components(separatedBy: "_")
        // parts: ["wf", "monitor", "batch", "{retry}", "{ts}", "{uuid}.json"]
        guard parts.count >= 5 else { return 0 }
        return Int(parts[3]) ?? 0
    }

    /// 重命名文件以更新重试次数
    /// - Returns: 新文件 URL，失败返回 nil
    static func renameForRetry(_ fileURL: URL) -> URL? {
        let name = fileURL.lastPathComponent
        let parts = name.components(separatedBy: "_")
        guard parts.count >= 5 else { return nil }

        let oldRetry = Int(parts[3]) ?? 0
        let newRetry = oldRetry + 1

        var newParts = parts
        newParts[3] = "\(newRetry)"
        let newName = newParts.joined(separator: "_")

        guard let dir = batchDir() else { return nil }
        let newURL = dir.appendingPathComponent(newName)

        do {
            try FileManager.default.moveItem(at: fileURL, to: newURL)
            return newURL
        } catch {
            print("[WFDiskManager] 重命名失败: \(error.localizedDescription)")
            return nil
        }
    }

    // MARK: - 磁盘保护

    /// 过期清理：删除 7 天前的文件
    static func cleanExpired() {
        let files = loadAllBatches()
        let now = Date()
        for file in files {
            guard let attrs = try? FileManager.default.attributesOfItem(atPath: file.path),
                  let modDate = attrs[.modificationDate] as? Date
            else { continue }
            if now.timeIntervalSince(modDate) > expireSeconds {
                deleteBatch(file)
                print("[WFDiskManager] 过期文件已删除: \(file.lastPathComponent)")
            }
        }
    }

    /// 磁盘上限检查：超过 5 MB 时 FIFO 删除最旧文件
    static func enforceDiskLimit() {
        let files = loadAllBatches()
        var totalSize: Int64 = 0
        for file in files {
            totalSize += (try? FileManager.default.attributesOfItem(atPath: file.path)[.size] as? Int64) ?? 0
        }

        var filesToDelete = files
        while totalSize > maxDiskSize, let oldest = filesToDelete.first {
            let size = (try? FileManager.default.attributesOfItem(atPath: oldest.path)[.size] as? Int64) ?? 0
            deleteBatch(oldest)
            totalSize -= size
            filesToDelete.removeFirst()
            print("[WFDiskManager] FIFO 淘汰: \(oldest.lastPathComponent)")
        }
    }
}

