import Foundation
import UIKit

/// 内存 + FPS 周期采样
///
/// FPS 原理：CADisplayLink 每帧回调，统计帧间隔
///   - 帧间隔 > 16ms 计为卡顿（< 60fps）
///   - 帧间隔 > 700ms 计为严重卡顿
///
/// 内存原理：mach_task_basic_info，iOS 系统级 API，精确到字节
final class WFMemoryFpsCollector {

    static let shared = WFMemoryFpsCollector()
    private init() {}

    private(set) var lastAvgFps: Int = 60
    private(set) var lastJankCount: Int = 0
    private(set) var lastSevereJankCount: Int = 0

    private var displayLink: CADisplayLink?
    private var frameCount: Int = 0
    private var lastFrameTime: CFTimeInterval = 0
    private var jankCount: Int = 0
    private var severeJankCount: Int = 0
    private var samplingTimer: Timer?

    private let JANK_THRESHOLD: CFTimeInterval = 0.016         // 16ms
    private let SEVERE_JANK_THRESHOLD: CFTimeInterval = 0.700  // 700ms

    func start(config: WFConfig) {
        startDisplayLink()
        startSamplingTimer(interval: config.samplingInterval)
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
        samplingTimer?.invalidate()
        samplingTimer = nil
    }

    // MARK: - FPS via CADisplayLink

    private func startDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: #selector(onFrame(_:)))
        displayLink?.add(to: .main, forMode: .common)
    }

    @objc private func onFrame(_ link: CADisplayLink) {
        guard lastFrameTime != 0 else {
            lastFrameTime = link.timestamp
            return
        }
        let diff = link.timestamp - lastFrameTime
        lastFrameTime = link.timestamp
        frameCount += 1

        if diff > SEVERE_JANK_THRESHOLD { severeJankCount += 1 }
        else if diff > JANK_THRESHOLD   { jankCount += 1 }
    }

    // MARK: - 定期快照

    private func startSamplingTimer(interval: TimeInterval) {
        samplingTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            self?.snapshot()
        }
    }

    private func snapshot() {
        lastAvgFps          = min(60, max(0, frameCount))
        lastJankCount       = jankCount
        lastSevereJankCount = severeJankCount
        frameCount          = 0
        jankCount           = 0
        severeJankCount     = 0
    }
}

// MARK: - 内存工具

enum WFMemoryHelper {
    /// 当前 App 使用内存，单位 MB
    static func usedMemoryMB() -> Int {
        var info = mach_task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size) / 4
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: 1) {
                task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
            }
        }
        return result == KERN_SUCCESS ? Int(info.resident_size / 1024 / 1024) : 0
    }
}
