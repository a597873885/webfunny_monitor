import Foundation
import UIKit

/// 应用启动耗时采集
///
/// 关键时间点：
///   processLaunchTime  ← sysctl 读取进程实际创建时间（内核级，精准）
///   sdkInitTime        ← WFMonitor.setup() 调用时刻
///   firstVCAppearTime  ← 第一个 viewDidAppear 时刻（视为首帧完成）
///
/// 通知由 WFPageCollector 的 wf_pageViewDidAppear swizzle 统一发出，
/// 避免对同一个 viewDidAppear 进行二次 swizzle 导致实现链断裂。
///
/// 参考：MetricKit（iOS 14+）提供类似数据，但仅次日上报；此处实时采集
final class WFStartupCollector {

    /// WFPageCollector 在首个 viewDidAppear 触发后 post 此通知
    static let firstVCDidAppearNotification = Notification.Name("wf_first_vc_did_appear")

    private static var config: WFConfig!
    private static var sdkInitTime: Date = Date()
    private static var processStartTime: Date = Date()
    private static var firstVCReported = false

    static func markSdkInit() {
        sdkInitTime = Date()
        processStartTime = processLaunchDate()
    }

    static func install(config: WFConfig) {
        self.config = config
        observeFirstViewController()
    }

    // MARK: - 监听第一个 ViewController 出现（通知由 WFPageCollector 发出）

    private static func observeFirstViewController() {
        NotificationCenter.default.addObserver(
            forName: firstVCDidAppearNotification,
            object: nil,
            queue: .main
        ) { _ in
            guard !firstVCReported else { return }
            firstVCReported = true
            reportStartup()
        }
    }

    private static func reportStartup() {
        guard let cfg = config else { return }
        let now = Date()

        let processCreateMs  = Int(sdkInitTime.timeIntervalSince(processStartTime) * 1000)
        let sdkToFirstVC     = Int(now.timeIntervalSince(sdkInitTime) * 1000)
        let totalMs          = Int(now.timeIntervalSince(processStartTime) * 1000)

        let log = WFStartupLog(
            config:               cfg,
            startType:            "cold",
            processStartTime:     max(0, processCreateMs),
            applicationInitTime:  0,
            splashScreenTime:     0,
            mainPageCreateTime:   0,
            firstFrameRenderTime: max(0, sdkToFirstVC)
        )
        WFUploader.shared.enqueue(log.toDict())

        if cfg.debugLog {
            print("[WFMonitor] 启动上报: process→sdkInit=\(processCreateMs)ms, sdkInit→firstVC=\(sdkToFirstVC)ms, total=\(totalMs)ms")
        }
    }

    /// 使用 sysctl 获取进程创建的绝对时间（内核级，精准）
    private static func processLaunchDate() -> Date {
        var info = kinfo_proc()
        var size = MemoryLayout<kinfo_proc>.stride
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        sysctl(&mib, 4, &info, &size, nil, 0)
        let tv = info.kp_proc.p_un.__p_starttime
        let seconds = Double(tv.tv_sec) + Double(tv.tv_usec) / 1_000_000
        return Date(timeIntervalSince1970: seconds)
    }
}
