import Foundation

/// APP_CRASH → MobileErrorLog
final class WFCrashLog: WFBaseLog {

    let errorType: String
    let simpleErrorMessage: String
    let errorMessage: String
    let errorStack: String
    let crashReason: String
    let crashThread: String
    let isForeground: Int
    let crashMemory: Int
    let crashCpuUsage: String

    init(config: WFConfig, exception: NSException, isForeground: Bool) {
        self.errorType = exception.name.rawValue
        let msg = exception.reason ?? exception.name.rawValue
        self.simpleErrorMessage = String(msg.prefix(200))
        self.errorMessage = msg
        self.errorStack = exception.callStackSymbols.joined(separator: "\n")
        self.crashReason = msg
        self.crashThread = Thread.current.name ?? "main"
        self.isForeground = isForeground ? 1 : 0
        self.crashMemory = WFMemoryHelper.usedMemoryMB()
        self.crashCpuUsage = ""
        super.init(uploadType: "APP_CRASH", config: config)
    }

    /// Signal 崩溃（如 SIGSEGV）
    init(config: WFConfig, signal: Int32, callStack: [String], isForeground: Bool) {
        self.errorType = "Signal_\(signal)"
        let msg = "Signal \(signal) 崩溃"
        self.simpleErrorMessage = msg
        self.errorMessage = msg
        self.errorStack = callStack.joined(separator: "\n")
        self.crashReason = msg
        self.crashThread = Thread.current.name ?? "main"
        self.isForeground = isForeground ? 1 : 0
        self.crashMemory = WFMemoryHelper.usedMemoryMB()
        self.crashCpuUsage = ""
        super.init(uploadType: "APP_CRASH", config: config)
    }

    override func toDict() -> [String: Any] {
        var d = super.toDict()
        d["errorType"]          = errorType
        d["simpleErrorMessage"] = b64(simpleErrorMessage)
        d["errorMessage"]       = b64(errorMessage)
        d["errorStack"]         = b64(errorStack)
        d["crashReason"]        = b64(crashReason)
        d["crashThread"]        = crashThread
        d["isForeground"]       = isForeground
        d["crashMemory"]        = crashMemory
        d["crashCpuUsage"]      = crashCpuUsage
        d["infoType"]           = "on_error"
        return d
    }
}
