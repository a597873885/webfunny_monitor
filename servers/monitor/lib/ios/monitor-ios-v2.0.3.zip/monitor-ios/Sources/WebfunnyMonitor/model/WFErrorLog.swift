import Foundation

/// JS_ERROR → MobileErrorLog（业务层 catch 到的异常）
///
/// 数据结构对齐 H5 SDK jsError.js：
///   - simpleErrorMessage: base64("ErrorType: 短消息(≤80字)")
///   - errorMessage:       base64("ErrorType: 完整消息")
///   - errorStack:         base64(堆栈)
///   - pageKey:            UUID（对标 H5）
///   - monitorIp/country/province/city: 服务端填充，上报空字符串
class WFErrorLog: WFBaseLog {

    private let rawType: String
    private let rawMsg: String
    private let rawStack: String

    let simpleErrorMessage: String
    let errorMessage: String
    let errorStack: String
    let pageKey: String
    let errorPage: String
    let errorScene: String
    let monitorIp: String = ""
    let country: String = ""
    let province: String = ""
    let city: String = ""

    init(config: WFConfig, error: Error, errorScene: String = "") {
        let nsErr = error as NSError
        self.rawType = String(describing: type(of: error))
        self.rawMsg = nsErr.localizedDescription
        self.rawStack = nsErr.userInfo[NSLocalizedFailureReasonErrorKey] as? String
            ?? Thread.callStackSymbols.joined(separator: "\n")

        // Swift 要求 super.init 前不能调用 self 方法，用局部函数替代
        func b64(_ str: String) -> String {
            Data(str.utf8).base64EncodedString()
        }

        // 对齐 H5：simpleErrorMessage = base64("Type: 消息前80字")
        let shortMsg = "\(rawType): \(String(rawMsg.prefix(80)))"
        self.simpleErrorMessage = b64(shortMsg)

        // 对齐 H5：errorMessage = base64("Type: 完整消息，≤1000字")
        let fullMsg = "\(rawType): \(String(rawMsg.prefix(999)))"
        self.errorMessage = b64(fullMsg)

        // 对齐 H5：errorStack = base64(堆栈，≤3000字)
        self.errorStack = b64(String(rawStack.prefix(2999)))

        self.pageKey = UUID().uuidString.replacingOccurrences(of: "-", with: "")
        self.errorPage = WFSession.shared.currentPage.isEmpty
            ? "unknown" : WFSession.shared.currentPage
        self.errorScene = errorScene

        super.init(uploadType: "JS_ERROR", config: config)
    }

    override func toDict() -> [String: Any] {
        var dict = super.toDict()
        dict["pageKey"]            = pageKey
        dict["simpleErrorMessage"] = simpleErrorMessage
        dict["errorMessage"]       = errorMessage
        dict["errorStack"]         = errorStack
        dict["errorPage"]          = errorPage
        dict["errorScene"]         = errorScene
        dict["monitorIp"]          = monitorIp
        dict["country"]            = country
        dict["province"]           = province
        dict["city"]               = city
        dict["infoType"]           = "on_error"
        return dict
    }
}
