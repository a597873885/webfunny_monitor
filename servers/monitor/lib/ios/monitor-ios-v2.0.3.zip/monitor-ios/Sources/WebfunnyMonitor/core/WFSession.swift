import Foundation
import Security

/// 会话与设备指纹管理
///
/// - customerKey：设备唯一指纹，首次生成后存入 Keychain（跨重装持久化）
///                若 Keychain 不可用则降级到 UserDefaults
/// - sessionId：每次冷启动重新生成
/// - userId / userParam：业务层热设置
final class WFSession {

    static let shared = WFSession()
    private init() {}

    private let keychainService = "com.webfunny.monitor"
    private let keychainAccount = "wf_customer_key"
    private let udFallbackKey   = "wf_customer_key_ud"
    private let userInfoKey     = "wf_monitor_user_info"
    /// 恢复用户信息时禁用持久化，避免重复写盘
    private var isRestoring = false

    /// 1 = 新用户（本次安装首次运行，Keychain / UserDefaults 均无 customerKey）
    /// 0 = 回访用户
    /// 在 customerKey lazy 初始化时确定，整个 Session 内保持不变
    private(set) var isNewUser: Int = 0

    /// 设备唯一指纹（跨重装持久化）
    private(set) lazy var customerKey: String = {
        if let saved = readFromKeychain() { return saved }
        if let saved = UserDefaults.standard.string(forKey: udFallbackKey) {
            saveToKeychain(saved)
            return saved
        }
        // Keychain 和 UserDefaults 都没有 → 新用户
        isNewUser = 1
        let newKey = UUID().uuidString
        saveToKeychain(newKey)
        UserDefaults.standard.set(newKey, forKey: udFallbackKey)
        return newKey
    }()

    /// 会话 ID（冷启动重新生成）
    let sessionId: String = UUID().uuidString

    /// 业务用户 ID（持久化）
    var userId: String = "" {
        didSet { saveUserInfo() }
    }

    /// 自定义参数 1（持久化）
    var firstUserParam: String = "" {
        didSet { saveUserInfo() }
    }

    /// 自定义参数 2（持久化）
    var secondUserParam: String = "" {
        didSet { saveUserInfo() }
    }

    /// 当前页面名称
    var currentPage: String = ""

    // MARK: - 用户信息持久化

    /// 持久化用户信息到 UserDefaults
    private func saveUserInfo() {
        guard !isRestoring else { return }
        let dict: [String: String] = [
            "userId": userId,
            "firstUserParam": firstUserParam,
            "secondUserParam": secondUserParam
        ]
        if let data = try? JSONSerialization.data(withJSONObject: dict),
           let str = String(data: data, encoding: .utf8) {
            UserDefaults.standard.set(str, forKey: userInfoKey)
        }
    }

    /// App 重启后恢复用户信息
    func restoreUser() {
        guard let str = UserDefaults.standard.string(forKey: userInfoKey),
              let data = str.data(using: .utf8),
              let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String]
        else { return }
        isRestoring = true
        defer { isRestoring = false }
        userId = dict["userId"] ?? ""
        firstUserParam = dict["firstUserParam"] ?? ""
        secondUserParam = dict["secondUserParam"] ?? ""
    }

    // MARK: - Keychain helpers

    private func readFromKeychain() -> String? {
        let query: [CFString: Any] = [
            kSecClass:            kSecClassGenericPassword,
            kSecAttrService:      keychainService,
            kSecAttrAccount:      keychainAccount,
            kSecReturnData:       true,
            kSecMatchLimit:       kSecMatchLimitOne,
            kSecAttrAccessible:   kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess,
              let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else { return nil }
        return value
    }

    private func saveToKeychain(_ value: String) {
        guard let data = value.data(using: .utf8) else { return }
        let query: [CFString: Any] = [
            kSecClass:          kSecClassGenericPassword,
            kSecAttrService:    keychainService,
            kSecAttrAccount:    keychainAccount,
            kSecValueData:      data,
            kSecAttrAccessible: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }
}
