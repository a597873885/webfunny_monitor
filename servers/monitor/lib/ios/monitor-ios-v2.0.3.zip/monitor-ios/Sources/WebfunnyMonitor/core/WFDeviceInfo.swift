import Foundation
import UIKit
import SystemConfiguration

/// 设备信息采集（系统 API，零风险）
///
/// 对应 ClickHouse 字段：platform / os / osVersion / deviceName /
///                        deviceBrand / deviceSize / networkType
struct WFDeviceInfo {

    static let SDK_VERSION: String = "2.0.3"

    static let platform: String = "ios"

    static var os: String { "iOS \(UIDevice.current.systemVersion)" }

    static var osVersion: String { UIDevice.current.systemVersion }

    /// 设备型号，如 iPhone15,2（identifier）
    static var deviceName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
    }

    static let deviceBrand: String = "Apple"

    /// 制造商（iOS 固定为 Apple）
    static let manufacturer: String = "Apple"

    static var deviceSize: String {
        let screen = UIScreen.main.bounds
        let scale  = UIScreen.main.scale
        let w = Int(screen.width * scale)
        let h = Int(screen.height * scale)
        return "\(w)x\(h)"
    }

    /// 屏幕宽度（px）
    static var screenWidth: Int {
        Int(UIScreen.main.bounds.width * UIScreen.main.scale)
    }

    /// 屏幕高度（px）
    static var screenHeight: Int {
        Int(UIScreen.main.bounds.height * UIScreen.main.scale)
    }

    /// 屏幕密度（dpi，近似 scale * 163）
    static var density: Int {
        Int(UIScreen.main.scale * 163)
    }

    /// 系统语言（如 zh、en）
    static var language: String {
        Locale.current.languageCode ?? ""
    }

    /// 时区（如 Asia/Shanghai）
    static var timezone: String {
        TimeZone.current.identifier
    }

    /// 运营商名称（iOS 16+ CTCarrier 已废弃，返回空字符串）
    static let carrier: String = ""

    /// 获取当前网络类型：wifi / 4g / 5g / unknown
    static var networkType: String {
        guard let reachability = SCNetworkReachabilityCreateWithName(nil, "www.apple.com") else {
            return "unknown"
        }
        var flags = SCNetworkReachabilityFlags()
        SCNetworkReachabilityGetFlags(reachability, &flags)

        if flags.contains(.reachable) == false { return "unknown" }
        if flags.contains(.isWWAN) { return "4g" }
        return "wifi"
    }
}
