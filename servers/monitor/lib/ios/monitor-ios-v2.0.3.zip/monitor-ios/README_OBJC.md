# Webfunny Monitor iOS SDK — Objective-C 接入指南

Webfunny 监控 SDK iOS 版的 Objective-C 接入文档。

> SDK 核心使用 Swift 编写（class + struct），ObjC 无法直接调用。
> SDK 内置 `WFMonitorBridge` 桥接层，将全部 API 包装为 `@objc` 类和方法，ObjC 项目直接使用即可，无需自己写桥接文件。

---

## 1. 集成 SDK

### CocoaPods

SDK 内置 `WebfunnyMonitor.podspec`，在 Podfile 中添加：

```ruby
pod 'WebfunnyMonitor', :path => 'path/to/monitor-ios'
```

> 如果 SDK 已发布到远程仓库，可改为 `pod 'WebfunnyMonitor', '~> 2.0.1'`。

然后执行：

```bash
pod install
```

### 注意事项

1. **必须通过 `.xcworkspace` 打开项目**，不能直接打开 `.xcodeproj`，否则会报 `No such module 'WebfunnyMonitor'`
2. Podfile 中需要 `use_frameworks!`（动态框架模式）
3. 如遇 Xcode 15+ 的 rsync 权限错误，在 Podfile 的 `post_install` 中添加：
   ```ruby
   post_install do |installer|
     installer.pods_project.targets.each do |target|
       target.build_configurations.each do |config|
         target.build_settings(config.name)['ENABLE_USER_SCRIPT_SANDBOXING'] = 'NO'
       end
     end
   end
   ```

### 源码包（本地 SPM）

1. 解压源码包 zip 到项目同级目录
2. Xcode 打开你的工程：**File → Add Package Dependencies…**
3. 点击左下角 **Add Local…**
4. 选择解压后的 `monitor-ios` 文件夹
5. 点击 **Add Package**，在 **Add to Target** 中勾选你的 App

---

## 2. 导入头文件

在需要调用监控的 `.m` 文件中导入：

```objc
#import <WebfunnyMonitor/WebfunnyMonitor-Swift.h>
```

> 这一个头文件包含 `WFMonitorBridge`、`WFMonitorOptionsConfig` 和 `WFPageTracker`。
>
> **说明**：`WebfunnyMonitor-Swift.h` 不是 SDK 源码中的物理文件，而是 Xcode 编译时自动生成的 ObjC 头文件。
> 只要项目通过 CocoaPods / SPM 集成了 WebfunnyMonitor 并完成一次编译，该文件就会自动生成，`#import` 即可正常使用，无需手动查找。
> 如果 Xcode 编辑器中该行显示红色，通常是因为没有用 `.xcworkspace` 打开项目，或尚未编译过一次。

---

## 3. 初始化 SDK

在 `AppDelegate` 的 `application:didFinishLaunchingWithOptions:` 中初始化，**越早越好**（早于业务侧创建网络请求，以便 HTTP 拦截生效）：

### 简易初始化（功能开关全部默认开启）

```objc
#import <WebfunnyMonitor/WebfunnyMonitor-Swift.h>

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [WFMonitorBridge setupWithServerUrl:@"https://your-monitor-host.com"
                           webMonitorId:@"your_monitor_id"];
    return YES;
}
```

### 完整初始化（自定义功能开关）

```objc
WFMonitorOptionsConfig *options = [WFMonitorOptionsConfig new];
options.enableCrash  = YES;
options.enableHttp   = YES;
options.enableFps    = YES;
options.enableMemory = YES;
options.samplingInterval   = 2.0;
options.httpBodyMaxBytes   = 8192;
options.debugLog    = YES;   // 开发阶段开启，上线改为 NO
options.gzip        = YES;   // gzip 压缩上报
options.env         = @"pro"; // dev / sit / stag / pro

[WFMonitorBridge setupWithServerUrl:@"https://your-monitor-host.com"
                       webMonitorId:@"your_monitor_id"
                            options:options];
```

### 验证

运行 App 后，在 Xcode Console 搜索 `WFMonitor`，应能看到上报日志和 HTTP 状态码。

---

## 4. 设置用户信息（登录后调用）

```objc
[WFMonitorBridge setUserId:@"业务用户唯一标识"];

// 可选：自定义参数
[WFMonitorBridge setUserParamWithFirst:@"渠道A" second:@"实验组1"];

// 退出登录时清除
[WFMonitorBridge setUserId:@""];
```

> 用户信息会持久化到本地，App 重启后自动恢复。

---

## 5. 手动上报错误（JS_ERROR）

```objc
@catch (NSError *error) {
    [WFMonitorBridge reportError:error errorScene:@"支付接口调用"];
}
```

与 H5 SDK 的 JS_ERROR 协议对齐，移动端原生异常也可通过该方法主动上报。

---

## 6. 手动页面耗时追踪

适用于非 `UIViewController` 场景（SwiftUI、自定义页面等）：

```objc
WFPageTracker *tracker = [WFMonitorBridge startPageTrace:@"HomeView"];
// … 页面逻辑 …
[tracker finish];  // 使用默认参数结束追踪
```

如果需要指定加载类型和子阶段耗时：

```objc
WFPageTracker *tracker = [WFMonitorBridge startPageTrace:@"OrderDetailPage"];
// … 页面逻辑 …
[tracker finishWithLoadType:@"navigation"
              dataFetchTime:120
              viewBuildTime:80];
```

> 自动页面与 CUSTOMER_PV 依赖对 `UIViewController` 的 swizzle；纯代码布局页面请使用上述手动追踪。

---

## 7. 立即上报队列

```objc
[WFMonitorBridge flush];
```

SDK 也会在以下场景自动刷新队列：
- App 进入后台（`didEnterBackground`）
- App 即将失去焦点（`willResignActive`）
- 系统内存警告（`didReceiveMemoryWarning`）

---

## 8. 注意事项

### 8.1 上报地址

实际请求 URL 为：`{serverUrl}/wfMonitor/upLogs`（`serverUrl` 不要带该路径后缀）。

### 8.2 真机与 localhost

模拟器访问本机可用 `http://localhost:端口`；**真机**须使用电脑局域网 IP，例如 `http://192.168.1.10:8023`，并在需要时配置 **App Transport Security**（仅 HTTPS 或例外域名）。

### 8.3 HTTP 采集（`HTTP_LOG`）

- 基于 `URLProtocol` 注册；对 **`WFMonitorBridge setup` 之后** 创建的 `URLSession` / 默认会话发起的请求更易被采集。
- 若业务在初始化前已创建并复用自定义 `URLSessionConfiguration`，可能无法自动注入。
- **WKWebView** 内页面请求默认不经过 `NSURLProtocol`，当前 SDK 不采集 WebView 内资源请求。

### 8.4 崩溃调试

使用 Xcode **Run** 时，调试器会拦截部分 Signal。验证崩溃落盘与下次启动补报时，建议：**Build 后从桌面/模拟器主屏幕点击 App 图标启动**。

---

## 9. 主要上报类型（uploadType）速查

| uploadType | 说明 |
|------------|------|
| `APP_START` | 启动相关性能 |
| `MOBILE_PAGE_LOAD` | 页面加载耗时 |
| `MOBILE_HTTP_LOG` | HTTP 请求 |
| `APP_CRASH` | 崩溃 / 未捕获异常 |
| `CUSTOMER_PV` | 页面 PV（每次 viewDidAppear 自动上报） |
| `JS_ERROR` | 主动上报的业务错误 |

---

## 10. 配置类参考

### WFMonitorOptionsConfig

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enableCrash` | BOOL | YES | 崩溃采集 |
| `enableHttp` | BOOL | YES | HTTP 请求拦截 |
| `enableFps` | BOOL | YES | FPS 采样 |
| `enableMemory` | BOOL | YES | 内存采样 |
| `samplingInterval` | NSTimeInterval | 2.0 | FPS/内存采样间隔（秒） |
| `httpBodyMaxBytes` | Int | 8192 | HTTP 请求/响应体截取上限（字节） |
| `debugLog` | BOOL | NO | SDK 调试日志 |
| `gzip` | BOOL | YES | gzip 压缩上报（body > 1KB 时启用） |
| `env` | NSString * | @"pro" | 环境标识：dev / sit / stag / pro |

---

## 11. API 参考

| 方法 | 说明 |
|------|------|
| `[WFMonitorBridge setupWithServerUrl:webMonitorId:]` | 简易初始化 |
| `[WFMonitorBridge setupWithServerUrl:webMonitorId:options:]` | 完整初始化 |
| `[WFMonitorBridge setUserId:]` | 设置业务用户 ID（持久化） |
| `[WFMonitorBridge setUserParamWithFirst:second:]` | 设置自定义参数（持久化） |
| `[WFMonitorBridge startPageTrace:]` | 手动页面耗时追踪 |
| `[WFMonitorBridge reportError:errorScene:]` | 手动上报业务错误 |
| `[WFMonitorBridge flush]` | 立即刷新上报队列 |
| `[tracker finish]` | 结束页面追踪（默认参数） |
| `[tracker finishWithLoadType:]` | 结束页面追踪（指定加载类型） |
| `[tracker finishWithLoadType:dataFetchTime:viewBuildTime:]` | 结束页面追踪（完整参数） |

---

## 12. 环境要求

| 项 | 说明 |
|----|------|
| 最低系统 | iOS **13.0** 及以上 |
| Xcode | 15+ |
| CocoaPods | 1.10+（CocoaPods 集成方式） |
