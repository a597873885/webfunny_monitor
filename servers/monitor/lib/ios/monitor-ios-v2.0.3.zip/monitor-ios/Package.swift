// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "WebfunnyMonitor",
    platforms: [
        .iOS(.v13)
    ],
    products: [
        .library(
            name: "WebfunnyMonitor",
            targets: ["WebfunnyMonitor"]
        )
    ],
    targets: [
        .target(
            name: "WebfunnyMonitor",
            path: "Sources/WebfunnyMonitor",
            linkerSettings: [
                // SystemConfiguration.framework 用于网络类型判断
                .linkedFramework("SystemConfiguration"),
                // Compression.framework 用于 gzip 压缩上报
                .linkedFramework("Compression")
            ]
        )
    ]
)
