# Webfunny Monitor HarmonyOS SDK v2.0

Webfunny 监控 SDK 鸿蒙版，零第三方依赖，基于 ArkTS。

> v2.0 新增：数据落盘持久化、退避重试、启动恢复、用户信息持久化、退后台自动上报、请求签名防篡改、服务端配置拉取。详见 [版本历史](#12-版本历史)。

---

## 1. 下载 SDK

下载 [monitor-harmonyos-v2.0.1.zip]()（请联系技术支持获取最新下载地址），将 `monitor-harmonyos` 文件夹解压到与你的项目同级目录下。

> 目录结构示意：
> ```
> harmonyos/
> ├── YourProject/                ← 你的项目
> │   ├── entry/                   ← 你的 App 模块
> │   ├── build-profile.json5
> │   └── oh-package.json5
> └── monitor-harmonyos/          ← 下载的 SDK 模块（与项目同级）
> ```

### 添加模块引用

1. 在项目根目录的 `build-profile.json5` 中添加模块：

```json5
{
  "modules": [
    // ... 你的 entry 模块
    {
      "name": "monitor-harmonyos",
      "srcPath": "../monitor-harmonyos",
      "targets": [{ "name": "default", "applyToProducts": ["default"] }]
    }
  ]
}
```

> `srcPath` 相对于项目根目录，`../monitor-harmonyos` 表示 SDK 与项目同级。

2. 在 App 模块（entry）的 `oh-package.json5` 中添加依赖：

```json5
{
  "dependencies": {
    "monitor-harmonyos": "file:../../monitor-harmonyos"
  }
}
```

> `file:` 路径相对于 `oh-package.json5` 所在的 entry 目录，`../../monitor-harmonyos` 表示从 entry 上一层到项目根目录，再上一层到 SDK 所在位置。

3. 点击 DevEco Studio 顶部的 **Sync Now**。

---

## 2. 初始化 SDK

在 `EntryAbility.ets` 的 `onCreate` 中初始化：

```typescript
import { WebfunnyMonitor } from 'monitor-harmonyos';
import { AbilityConstant, UIAbility, Want } from '@kit.AbilityKit';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    // 初始化监控 SDK（尽早调用）
    WebfunnyMonitor.builder()
      .setMonitorId('your_monitor_id')                        // 项目ID（必填）
      .setUploadUrl('https://your-server.com/server/monitor')  // 上报地址（必填）
      .setProjectVersion('1.0.0')                              // 应用版本
      .setEnv('pro')                                           // 环境: pro/test/dev
      .setDebug(true)                                          // 调试模式
      .enablePageView(true)                                    // 页面监控
      .enableHttpLog(true)                                     // 网络监控
      .enableJsError(true)                                     // 错误监控
      .enableCrash(true)                                       // 崩溃监控
      .enableBehavior(true)                                    // 行为监控
      .setSamplingRate(100)                                    // 采样率 0-100
      .setBatchSize(10)                                        // 批量上报大小
      .setBatchInterval(5000)                                  // 批量上报间隔(ms)
      .build(this.context);

    // 标记进程启动（启动性能监控起点）
    WebfunnyMonitor.getInstance().markProcessStart();
  }

  onForeground(): void {
    WebfunnyMonitor.getInstance().markHotStart();
  }

  onBackground(): void {
    WebfunnyMonitor.getInstance().markBackground();
    // v2.0：SDK 自动在退后台时 flush 缓存数据，无需手动调用 flush()
  }
}
```

> **monitorId 从哪来？** 登录 Webfunny 控制台 → 监控分析 → 创建项目 → 获取项目 ID。

### 验证

运行 App 后，在 Log 中搜索 `WebfunnyMonitor`，`debug: true` 时可见初始化日志和监控数据上报。

---

## 3. 设置用户信息

```typescript
import { WebfunnyMonitor } from 'monitor-harmonyos';

WebfunnyMonitor.getInstance().initUser('user_123', 'VIP', '张三');
```

> v2.0 新增：用户信息自动持久化到 Preferences，App 重启后自动恢复，无需重新调用 `initUser`。

---

## 4. 启动性能监控

在应用启动关键节点调用标记方法，SDK 自动计算各阶段耗时并上报：

```typescript
// EntryAbility.onCreate 最开始
WebfunnyMonitor.getInstance().markProcessStart();
WebfunnyMonitor.getInstance().markApplicationInitStart();
// ... Application 初始化逻辑
WebfunnyMonitor.getInstance().markApplicationInitEnd();

// 闪屏页
WebfunnyMonitor.getInstance().markSplashScreenStart();
// ... 闪屏展示
WebfunnyMonitor.getInstance().markSplashScreenEnd();

// 主页面
WebfunnyMonitor.getInstance().markMainPageCreateStart();
// ... 主页面创建
WebfunnyMonitor.getInstance().markMainPageCreateEnd();
```

> **必须**：在首页面的 `aboutToAppear` 中调用 `markFirstFrameRender()`，这是启动监控的终点，不调用则不会上报启动数据。

```typescript
// 首页面（如 Index.ets）
@Entry
@Component
struct Index {
  aboutToAppear(): void {
    // 首帧渲染完成 = 启动监控终点，触发数据上报
    WebfunnyMonitor.getInstance().markFirstFrameRender();
  }

  build() { ... }
}
```

### 热启动

```typescript
// onForeground 中调用
WebfunnyMonitor.getInstance().markHotStart();
// ... 前台恢复完成
WebfunnyMonitor.getInstance().markHotStartEnd();
```

---

## 5. 手动上报

### 页面访问 (PV)

```typescript
WebfunnyMonitor.getInstance().trackPageView('/pages/home');
// 不传参数则自动获取当前页面路径
WebfunnyMonitor.getInstance().trackPageView();
```

### 错误上报

```typescript
try {
  // your code
} catch (error) {
  WebfunnyMonitor.getInstance().reportError(error);
}
```

### 网络请求日志

```typescript
WebfunnyMonitor.getInstance().reportHttpLog({
  url: 'https://api.example.com/data',
  method: 'GET',
  status: 200,
  statusResult: 'success',
  loadTime: 150,
  requestText: '',
  responseText: '{"code": 0}'
});
```

### 自定义行为

```typescript
WebfunnyMonitor.getInstance().trackBehavior('button_click', {
  buttonId: 'submit_btn',
  pageName: 'login'
});
```

### 立即上报

```typescript
WebfunnyMonitor.getInstance().flush();
```

> v2.0：SDK 退后台时自动 flush，上报失败自动退避重试（4s → 16s → 32s，最多 3 次），数据先落盘后上传，进程被杀也不丢失。

---

## 6. 自动监控能力

SDK 初始化后自动开启以下监控（可通过 Builder 开关控制）：

| 监控类型 | 说明 | 开关方法 |
|---------|------|---------|
| 崩溃监控 (Crash) | 自动捕获 JS 崩溃和 Native 崩溃 | `enableCrash(true/false)` |
| ANR 监控 | 检测主线程卡顿（默认 5s 阈值） | 始终开启 |
| 页面监控 (PV) | 手动调用 `trackPageView` 上报 | `enablePageView(true/false)` |
| 错误监控 (JS Error) | 手动调用 `reportError` 上报 | `enableJsError(true/false)` |
| 网络监控 (HTTP) | 手动调用 `reportHttpLog` 上报 | `enableHttpLog(true/false)` |
| 行为监控 (Behavior) | 手动调用 `trackBehavior` 上报 | `enableBehavior(true/false)` |

---

## 7. WebfunnyMonitorBuilder 参数说明

| 方法 | 参数 | 默认值 | 说明 |
|------|------|--------|------|
| `setMonitorId(id)` | string | **必填** | 项目 ID |
| `setUploadUrl(url)` | string | **必填** | 上报服务地址 |
| `setProjectVersion(v)` | string | `'1.0.0'` | 应用版本号 |
| `setEnv(env)` | string | `'pro'` | 环境：pro / test / dev |
| `setDebug(debug)` | boolean | `false` | 是否打印调试日志 |
| `enablePageView(enable)` | boolean | `true` | 页面监控开关 |
| `enableHttpLog(enable)` | boolean | `true` | 网络监控开关 |
| `enableJsError(enable)` | boolean | `true` | 错误监控开关 |
| `enableCrash(enable)` | boolean | `true` | 崩溃监控开关 |
| `enableBehavior(enable)` | boolean | `true` | 行为监控开关 |
| `setSamplingRate(rate)` | number | `100` | 采样率 0-100 |
| `setSamplingCycle(days)` | number | `3` | 采样周期（天） |
| `setBatchSize(size)` | number | `10` | 批量上报大小 |
| `setBatchInterval(ms)` | number | `5000` | 批量上报间隔（毫秒） |
| `setSetting(setting)` | MonitorSetting | 默认值 | SDK 行为配置 |
| `build(context)` | Context | - | 构建并初始化 SDK |

### MonitorSetting

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `debugLog` | boolean | `false` | 是否打印 SDK 调试日志 |
| `gzip` | boolean | `false` | 是否启用 gzip 压缩（鸿蒙暂不支持，预留） |
| `httpBodyMaxBytes` | number | `8192` | HTTP body 最大截取字节数 |

---

## 8. API 参考

### WebfunnyMonitor

| 方法 | 说明 |
|------|------|
| `WebfunnyMonitor.builder()` | 创建 Builder |
| `getInstance()` | 获取单例实例 |
| `initUser(userId, userTag?, nickname?)` | 设置用户信息 |
| `markProcessStart()` | 标记进程启动 |
| `markApplicationInitStart()` / `markApplicationInitEnd()` | 标记 Application 初始化 |
| `markSplashScreenStart()` / `markSplashScreenEnd()` | 标记闪屏页 |
| `markMainPageCreateStart()` / `markMainPageCreateEnd()` | 标记主页面创建 |
| `markFirstFrameRender()` | 标记首帧渲染完成（触发启动数据上报） |
| `markBackground()` | 标记进入后台 |
| `markHotStart()` / `markHotStartEnd()` | 标记热启动 |
| `markWarmStart()` | 标记温启动 |
| `trackPageView(pagePath?)` | 记录页面访问 |
| `reportError(error, extra?, infoType?)` | 上报错误 |
| `reportHttpLog(data)` | 上报网络请求日志 |
| `trackBehavior(type, params?)` | 记录自定义行为 |
| `reportCrash(error, extra?)` | 手动上报崩溃 |
| `reportANR(blockTime, extra?)` | 手动上报 ANR |
| `flush()` | 立即上报缓存数据 |
| `getCustomerKey()` | 获取用户唯一标识 |
| `setForegroundState(isForeground)` | 设置前后台状态 |

---

## 9. 权限说明

SDK 需要以下权限：

```json5
{
  "requestPermissions": [
    {
      "name": "ohos.permission.INTERNET"  // 网络访问
    },
    {
      "name": "ohos.permission.GET_NETWORK_INFO"  // 获取网络信息
    }
  ]
}
```

---

## 10. 环境要求

- HarmonyOS API 9+
- Stage 模型
- DevEco Studio 4.0+

---

## 11. 打包

```bash
# 自动递增 patch 版本号并打包
./package.sh

# 指定版本号打包
./package.sh 2.0.0
```

打包产物输出到 `dist/` 目录，文件名格式：`monitor-harmonyos-v{版本号}.zip`。

---

## 12. 版本历史

### v2.0.1 — 数据可靠性增强

- **flush 先落盘后上传**：数据先持久化到磁盘再上传，进程被杀也不丢
- **退避重试机制**：上报失败自动重试（4s → 16s → 32s，最多 3 次）
- **启动恢复**：SDK 初始化时扫描残留批次文件，逐个重试
- **独立 DiskManager**：文件级批次管理，5MB FIFO 上限 + 7 天过期清理
- **用户信息持久化**：userId/userTag/nickname 持久化到 Preferences，App 重启自动恢复
- **退后台自动 flush**：监听 applicationStateChange，退后台时自动上报缓存数据
- **请求签名防篡改**：上报请求注入 wf-signature 头，防止中间人篡改
- **服务端配置拉取**：初始化时异步拉取 `/wfMonitor/initCf`，获取签名等配置
- **丰富设备信息字段**：新增 manufacturer/screenWidth/screenHeight/density/language/timezone/carrier/sdkVersion
- **结构化配置**：新增 MonitorSetting 子配置类（debugLog/gzip/httpBodyMaxBytes）

### v1.0.0 — 初始版本

- 基础监控功能
- 页面、网络、错误、崩溃、ANR 监控
- 批量上报和离线缓存
