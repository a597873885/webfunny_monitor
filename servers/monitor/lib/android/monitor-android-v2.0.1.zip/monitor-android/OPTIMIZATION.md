# Webfunny Monitor Android SDK 优化方案

> 参照 `event-android` 已落地的优秀实践，对监控 SDK 进行全面对齐升级。
>
> 优化项按**影响优先级**排列，前 4 项为数据可靠性核心，建议优先实施。

---

## 优化项总览

| # | 优化项 | 影响维度 | 改动文件数 | 优先级 |
|---|--------|---------|:---------:|:------:|
| 1 | flush 先落盘后上传 | 数据可靠性 | 2 | P0 |
| 2 | 退避重试机制 | 数据可靠性 | 1 | P0 |
| 3 | 独立 DiskManager | 数据可靠性 | 新建 1 + 改 1 | P0 |
| 4 | gzip 压缩上报 | 网络性能 | 1 | P1 |
| 5 | 用户信息持久化 | 用户体验 | 1 | P1 |
| 6 | ComponentCallbacks2 兜底 flush | 数据可靠性 | 1 | P1 |
| 7 | 丰富设备信息字段 | 数据完整性 | 2 | P2 |
| 8 | 请求签名防篡改 | 数据安全 | 新建 1 + 改 1 | P2 |
| 9 | 结构化配置 | 代码质量 | 1 | P2 |
| 10 | 环境标识 | 多环境支持 | 1 | P2 |
| 11 | 服务端配置拉取 | 动态配置 | 1 | P3 |

---

## 1. flush 先落盘后上传（P0）

### 问题

当前 `WFUploader.flush()` 先清空内存队列再上传，进程在上传过程中被杀则数据全丢。

### 现状代码（WFUploader.kt）

```kotlin
private fun flush() {
    if (queue.isEmpty()) return
    val batch = queue.toList()
    queue.clear()          // ← 先清空
    upload(batch)           // ← 再上传，进程被杀则丢
}
```

### 目标实现

```kotlin
private fun flush() {
    if (queue.isEmpty()) return
    val batch = queue.toList()
    queue.clear()

    // ① 先持久化到磁盘（进程被杀也不丢）
    val file = WFDiskManager.saveBatch(batch)

    // ② 再网络上报（成功后删磁盘文件，失败由重试机制兜底）
    upload(batch, file)
}
```

### 涉及文件

- `WFUploader.kt` — 修改 `flush()` 和 `upload()` 方法签名，传入 batchFile
- `WFDiskManager.kt` — 新建，提供 `saveBatch()` 接口（见优化项 3）

---

## 2. 退避重试机制（P0）

### 问题

上报失败后只会落盘，下次 App 启动时才重试一次，会话内无重试。

### 目标实现

参照 event-android 的 `WFEventUploader.scheduleRetry()`：

```kotlin
private const val MAX_RETRY = 3

private val retryExecutor = Executors.newScheduledThreadPool(1)

/** 上报一批日志，失败时启动重试 */
private fun upload(logs: List<Map<String, Any?>>, batchFile: File, retryCount: Int = 0) {
    try {
        // ... HTTP 上传逻辑 ...

        if (code in 200..299) {
            // 成功：删除磁盘文件
            WFDiskManager.deleteBatch(batchFile)
        } else {
            scheduleRetry(batchFile, retryCount)
        }
    } catch (e: Exception) {
        scheduleRetry(batchFile, retryCount)
    }
}

/** 调度重试：4s → 16s → 32s，最多 3 次 */
private fun scheduleRetry(file: File, currentRetry: Int) {
    if (currentRetry >= MAX_RETRY) {
        Log.w(TAG, "重试已达上限 ${MAX_RETRY} 次，删除文件: ${file.name}")
        WFDiskManager.deleteBatch(file)
        return
    }

    val delay = when (currentRetry) {
        0 -> 4_000L
        1 -> 16_000L
        else -> 32_000L
    }

    retryExecutor.schedule({
        val newFile = WFDiskManager.renameForRetry(file)
        if (newFile != null) {
            retryUpload(newFile, currentRetry + 1)
        }
    }, delay, TimeUnit.MILLISECONDS)
}

/** 重试上传 */
private fun retryUpload(file: File, retryCount: Int) {
    val logs = WFDiskManager.loadBatch(file)
    if (logs.isNotEmpty()) {
        upload(logs, file, retryCount)
    }
}
```

### 启动恢复

```kotlin
fun init(context: Context, cfg: WFConfig) {
    // ... 初始化 ...
    // 启动恢复：扫描残留批次文件，逐个重试
    executor.execute { recoverPendingBatches() }
}

private fun recoverPendingBatches() {
    val files = WFDiskManager.loadAllBatches()
    for (file in files) {
        val retry = WFDiskManager.parseRetry(file)
        if (retry >= MAX_RETRY) {
            WFDiskManager.deleteBatch(file)
            continue
        }
        // 超过 2 分钟的老文件，直接重试；否则按正常调度
        val fileAge = System.currentTimeMillis() - file.lastModified()
        if (fileAge > 120_000) {
            retryUpload(file, retry)
        } else {
            scheduleRetry(file, retry)
        }
    }
}
```

### 涉及文件

- `WFUploader.kt` — 新增 `retryExecutor`、`scheduleRetry()`、`retryUpload()`、`recoverPendingBatches()`

---

## 3. 独立 DiskManager（P0）

### 问题

当前落盘逻辑散写在 WFUploader 里，单文件存储，无 FIFO、无过期清理、50 条硬上限丢数据。

### 目标实现

新建 `WFDiskManager.kt`，完全参照 event-android 的 `WFEventDiskManager`：

```kotlin
object WFDiskManager {

    private const val BATCH_DIR = "wf_monitor"
    private const val BATCH_PREFIX = "wf_monitor_batch_"
    private const val MAX_DISK_BYTES = 5L * 1024 * 1024   // 5 MB
    private const val EXPIRE_DAYS = 7L
    private const val EXPIRE_MS = EXPIRE_DAYS * 24 * 60 * 60 * 1000L

    private lateinit var batchDir: File

    fun init(context: Context) {
        batchDir = File(context.cacheDir, BATCH_DIR)
        if (!batchDir.exists()) batchDir.mkdirs()
    }

    /** 保存一批日志到独立文件，文件名: wf_monitor_batch_{retry}_{timestamp}_{uuid}.json */
    fun saveBatch(logs: List<Map<String, Any?>>): File {
        val retry = 0
        val ts = System.currentTimeMillis()
        val uuid = UUID.randomUUID().toString().take(8)
        val file = File(batchDir, "${BATCH_PREFIX}${retry}_${ts}_${uuid}.json")
        val arr = JSONArray()
        logs.forEach { arr.put(JSONObject(it)) }
        file.writeText(arr.toString())
        enforceDiskLimit()
        return file
    }

    /** 从文件读取一批日志 */
    fun loadBatch(file: File): List<Map<String, Any?>> {
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                obj.keys().asSequence().associateWith { key -> obj.get(key) }
            }
        } catch (e: Exception) { emptyList() }
    }

    /** 扫描所有批次文件，按时间戳排序 */
    fun loadAllBatches(): List<File> {
        return batchDir.listFiles()
            ?.filter { it.name.startsWith(BATCH_PREFIX) && it.name.endsWith(".json") }
            ?.sortedBy { parseTimestamp(it.name) }
            ?: emptyList()
    }

    fun deleteBatch(file: File): Boolean = file.delete()

    /** 重试时 rename，retry + 1 */
    fun renameForRetry(file: File): File? {
        val name = file.name.removeSuffix(".json").removePrefix(BATCH_PREFIX)
        val parts = name.split("_", limit = 3)
        if (parts.size < 3) return null
        val oldRetry = parts[0].toIntOrNull() ?: return null
        val newName = "${BATCH_PREFIX}${oldRetry + 1}_${parts[1]}_${parts[2]}.json"
        val newFile = File(batchDir, newName)
        return if (file.renameTo(newFile)) newFile else null
    }

    fun parseRetry(file: File): Int {
        val name = file.name.removeSuffix(".json").removePrefix(BATCH_PREFIX)
        return name.split("_", limit = 3).getOrNull(0)?.toIntOrNull() ?: 0
    }

    /** 磁盘上限检查：总大小 > 5MB 时 FIFO 淘汰最旧文件 */
    fun enforceDiskLimit() {
        val files = loadAllBatches()
        var totalSize = files.sumOf { it.length() }
        for (file in files) {
            if (totalSize <= MAX_DISK_BYTES) break
            val size = file.length()
            file.delete()
            totalSize -= size
        }
    }

    /** 清理过期文件（> 7 天） */
    fun cleanExpired() {
        val now = System.currentTimeMillis()
        loadAllBatches().forEach { file ->
            if (now - file.lastModified() > EXPIRE_MS) {
                file.delete()
            }
        }
    }

    private fun parseTimestamp(name: String): Long {
        val parts = name.removeSuffix(".json").removePrefix(BATCH_PREFIX).split("_", limit = 3)
        return parts.getOrNull(1)?.toLongOrNull() ?: 0L
    }
}
```

### 涉及文件

- `WFDiskManager.kt` — 新建
- `WFUploader.kt` — 删除原有 `saveToDisk()` / `retryFile()`，改为调用 WFDiskManager

---

## 4. gzip 压缩上报（P1）

### 问题

上报数据为明文 JSON，移动网络下浪费流量。

### 目标实现

在 `WFUploader.upload()` 中增加 gzip 压缩，参照 event-android：

```kotlin
private const val GZIP_THRESHOLD = 1024  // 1 KB

private fun upload(logs: List<Map<String, Any?>>, batchFile: File, retryCount: Int = 0) {
    try {
        val jsonArray = JSONArray()
        logs.forEach { jsonArray.put(JSONObject(it)) }
        var bodyBytes = jsonArray.toString().toByteArray(Charsets.UTF_8)
        var useGzip = false

        // gzip 压缩（body > 1KB 时启用）
        if (bodyBytes.size > GZIP_THRESHOLD) {
            val bos = ByteArrayOutputStream()
            GZIPOutputStream(bos).use { it.write(bodyBytes) }
            bodyBytes = bos.toByteArray()
            useGzip = true
        }

        val conn = (URL(config.uploadUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json;charset=UTF-8")
            if (useGzip) setRequestProperty("Content-Encoding", "gzip")
            doOutput = true
            connectTimeout = 10_000
            readTimeout = 10_000
        }
        conn.outputStream.use { it.write(bodyBytes) }
        // ...
    }
}
```

### 配置开关

在 `WFConfig` 中增加 gzip 开关（默认 true）：

```kotlin
/** 是否启用 gzip 压缩上报（默认 true） */
val gzip: Boolean = true
```

### 涉及文件

- `WFUploader.kt` — upload 方法增加压缩逻辑
- `WFConfig.kt` — 新增 `gzip` 参数

---

## 5. 用户信息持久化（P1）

### 问题

`setUserId()` / `setUserParam()` 只存内存，App 重启后丢失。

### 目标实现

参照 event-android，将用户信息持久化到 SharedPreferences：

```kotlin
// WFSession.kt

private const val KEY_USER_INFO = "wf_monitor_user_info"

fun setUserId(userId: String) {
    this.userId = userId
    saveUserInfo()
}

fun setUserParam(first: String = "", second: String = "") {
    firstUserParam = first
    secondUserParam = second
    saveUserInfo()
}

/** 持久化用户信息 */
private fun saveUserInfo() {
    val json = JSONObject().apply {
        put("userId", userId)
        put("firstUserParam", firstUserParam)
        put("secondUserParam", secondUserParam)
    }
    prefs.edit().putString(KEY_USER_INFO, json.toString()).apply()
}

/** App 重启后恢复用户信息 */
private fun restoreUser() {
    val str = prefs.getString(KEY_USER_INFO, null) ?: return
    try {
        val json = JSONObject(str)
        userId = json.optString("userId")
        firstUserParam = json.optString("firstUserParam")
        secondUserParam = json.optString("secondUserParam")
    } catch (e: Exception) { /* 静默 */ }
}
```

在 `init()` 中调用 `restoreUser()`：

```kotlin
fun init(context: Context) {
    // ...
    restoreUser()  // 恢复上次保存的用户信息
}
```

### 涉及文件

- `WFSession.kt` — 新增 `saveUserInfo()` / `restoreUser()`，修改 `setUserId()` / `setUserParam()`

---

## 6. ComponentCallbacks2 兜底 flush（P1）

### 问题

仅靠 `onActivityStopped(count==0)` 检测退后台，边界场景可能漏触发。

### 目标实现

参照 event-android 的 `WFAppTracker.install()`，在 `WFMonitor.init()` 中增加 `ComponentCallbacks2`：

```kotlin
// WFMonitor.kt init() 中

application.registerComponentCallbacks(object : android.content.ComponentCallbacks2 {
    override fun onTrimMemory(level: Int) {
        if (level == android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            WFUploader.flushNow()
        }
    }
    override fun onLowMemory() {
        WFUploader.flushNow()
    }
    override fun onConfigurationChanged(config: android.content.res.Configuration) {}
})
```

### 涉及文件

- `WFMonitor.kt` — init() 中新增 ComponentCallbacks2 注册

---

## 7. 丰富设备信息字段（P2）

### 问题

监控 SDK 每条日志只携带 6 个设备字段，埋点 SDK 有 16 个。

### 目标实现

在 `WFDeviceInfo` 和 `BaseLog` 中补齐字段：

```kotlin
// WFDeviceInfo.kt 新增

val manufacturer: String = Build.MANUFACTURER

val screenWidth: Int = 0   // init() 中赋值
val screenHeight: Int = 0  // init() 中赋值
val density: Int = 0       // init() 中赋值

val language: String = Locale.getDefault().language
val timezone: String = TimeZone.getDefault().id

val carrier: String = ""   // init() 中赋值

const val SDK_VERSION = "2.0.1"

fun init(context: Context) {
    val dm = context.resources.displayMetrics
    _deviceSize = "${dm.widthPixels}x${dm.heightPixels}"
    screenWidth = dm.widthPixels
    screenHeight = dm.heightPixels
    density = dm.densityDpi
    carrier = getCarrierName(context)
}

private fun getCarrierName(context: Context): String {
    return try {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE)
            as? TelephonyManager ?: return ""
        tm.networkOperatorName ?: ""
    } catch (e: Exception) { "" }
}
```

```kotlin
// BaseLog.kt toMap() 中增加

"manufacturer" to WFDeviceInfo.manufacturer,
"screenWidth" to WFDeviceInfo.screenWidth,
"screenHeight" to WFDeviceInfo.screenHeight,
"density" to WFDeviceInfo.density,
"language" to WFDeviceInfo.language,
"timezone" to WFDeviceInfo.timezone,
"carrier" to WFDeviceInfo.carrier,
"sdkVersion" to WFDeviceInfo.SDK_VERSION,
```

### 涉及文件

- `WFDeviceInfo.kt` — 新增字段和初始化
- `BaseLog.kt` — toMap 增加字段

---

## 8. 请求签名防篡改（P2）

### 问题

上报请求无签名，可被中间人篡改。

### 目标实现

参照 event-android 的 `WFSignature.kt`，新建签名工具：

```kotlin
// WFSignature.kt（新建）

object WFSignature {

    /** 对服务端下发的 signature 做字符位置置换，还原密钥 */
    private fun decrypt(originSignature: String): String {
        if (originSignature.length < 32) return ""
        return try {
            val arr = originSignature.toCharArray()
            fun swap(i: Int, j: Int) { val t = arr[i]; arr[i] = arr[j]; arr[j] = t }
            swap(2, 21); swap(5, 18); swap(9, 15)
            swap(12, 31); swap(16, 28); swap(20, 25)
            arr.reversed().joinToString("")
        } catch (e: Exception) { "" }
    }

    /** 简单哈希 */
    private fun simpleHash(str: String): Int {
        var hash = 0
        for (ch in str) {
            hash = (hash shl 5) - hash + ch.code
            hash = hash or 0
        }
        return hash
    }

    /** 生成请求签名 */
    fun generate(storedSignature: String, webMonitorId: String): String {
        if (storedSignature.isBlank()) return ""
        return try {
            val secret = decrypt(storedSignature)
            val str = "$secret:$webMonitorId"
            simpleHash(str).toString(16)
        } catch (e: Exception) { "" }
    }
}
```

在 `WFUploader.upload()` 中注入签名头：

```kotlin
val signature = WFSignature.generate(storedSignature, config.webMonitorId)
if (signature.isNotBlank()) {
    conn.setRequestProperty("wf-signature", signature)
}
```

签名来源需要服务端配合下发（见优化项 12），存储在 SharedPreferences 中。

### 涉及文件

- `WFSignature.kt` — 新建
- `WFUploader.kt` — upload 方法增加签名头注入

---

## 9. 结构化配置（P2）

### 问题

`WFConfig` 是扁平的 13 个字段，功能分组不清晰。

### 目标实现

参照 event-android 的嵌套配置设计，将 WFConfig 拆分为子配置：

```kotlin
data class WFConfig(
    val serverUrl: String,
    val webMonitorId: String,
    val enableCrash: Boolean = true,
    val enableAnr: Boolean = true,
    val enableHttp: Boolean = true,
    val enableFps: Boolean = true,
    val enableMemory: Boolean = true,
    val samplingIntervalSec: Long = 2L,
    val setting: WFSetting = WFSetting()
)

/** SDK 行为设置 */
data class WFSetting(
    val maxQueueSize: Int = 20,
    val flushIntervalMs: Long = 10_000L,
    val anrThresholdMs: Long = 5_000L,
    val debugLog: Boolean = false,
    val gzip: Boolean = true,
    val httpBodyMaxBytes: Int = 8192
)
```

> **注意**：此改动是破坏性 API 变更，需要同步更新 README 中的示例代码和 WFConfig 参数说明表格。现有接入方需要修改初始化代码。

### 涉及文件

- `WFConfig.kt` — 拆分为 WFConfig + WFSetting
- `README.md` — 更新 WFConfig 参数说明
- 所有引用 `config.maxQueueSize` 等字段的代码 — 改为 `config.setting.maxQueueSize`

---

## 10. 环境标识（P2）

### 问题

无环境概念，无法区分 dev/sit/stag/pro。

### 目标实现

在 `WFConfig` 中增加 `env` 字段：

```kotlin
data class WFConfig(
    // ...
    /** 当前环境：dev / sit / stag / pro（默认 pro） */
    val env: String = "pro",
    // ...
)
```

在 `BaseLog` 中上报环境信息：

```kotlin
// BaseLog.kt
val env: String = config.env

// toMap() 中
"env" to env,
```

### 涉及文件

- `WFConfig.kt` — 新增 env 字段
- `BaseLog.kt` — toMap 增加 env

---

## 11. 服务端配置拉取（P3）

### 问题

所有配置写死在客户端，无法服务端动态下发。

### 目标实现

参照 event-android 的 `fetchInitCf()`，在 SDK 初始化时异步拉取服务端配置：

```kotlin
// WFMonitor.kt

private val initExecutor = Executors.newSingleThreadExecutor()

fun init(application: Application, config: WFConfig) {
    // ... 本地初始化 ...
    // 异步拉取服务端配置（签名等）
    initExecutor.execute { fetchServerConfig(application, config) }
}

private fun fetchServerConfig(context: Context, config: WFConfig) {
    try {
        val url = "${config.serverUrl}/wfMonitor/initCf"
        val body = JSONObject().apply {
            put("webMonitorId", config.webMonitorId)
        }.toString().toByteArray(Charsets.UTF_8)

        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json;charset=UTF-8")
            doOutput = true
            connectTimeout = 10_000
            readTimeout = 10_000
        }
        conn.outputStream.use { it.write(body) }

        val code = conn.responseCode
        if (code in 200..299) {
            val resp = conn.inputStream.bufferedReader().readText()
            parseServerConfig(context, resp)
        }
        conn.disconnect()
    } catch (e: Exception) {
        if (config.debugLog) Log.e("WFMonitor", "initCf 失败: ${e.message}")
    }
}

private fun parseServerConfig(context: Context, response: String) {
    try {
        val root = JSONObject(response)
        val data = root.optJSONObject("data") ?: return
        val signature = data.optString("signature")
        if (signature.isNotBlank()) {
            // 存储签名，供后续上报请求使用
            val prefs = context.getSharedPreferences("wf_monitor_session", Context.MODE_PRIVATE)
            prefs.edit().putString("wf_signature", signature).apply()
        }
    } catch (e: Exception) { /* 静默 */ }
}
```

> **前提**：需要监控服务端实现 `/wfMonitor/initCf` 接口，下发 signature 等配置。

### 涉及文件

- `WFMonitor.kt` — 新增 `fetchServerConfig()` / `parseServerConfig()`

---

## 实施建议

### 阶段一：数据可靠性（P0，优化项 1-3）

这是最核心的改进，涉及 3 个文件改动 + 1 个新建文件：
- 新建 `WFDiskManager.kt`
- 重构 `WFUploader.kt`（先落盘、退避重试、启动恢复）
- `WFMonitor.kt` 中 init 调用 WFDiskManager.init()

### 阶段二：性能与准确性（P1，优化项 4-6）

- `WFUploader.kt` 增加 gzip
- `WFConfig.kt` 增加 gzip 开关
- `WFSession.kt` 用户信息持久化
- `WFMonitor.kt` 增加 ComponentCallbacks2

### 阶段三：数据完整性与安全（P2，优化项 7-10）

- `WFDeviceInfo.kt` 补齐设备字段
- `BaseLog.kt` toMap 补齐字段
- 新建 `WFSignature.kt`
- `WFConfig.kt` 结构化改造 + env 字段

### 阶段四：动态配置（P3，优化项 11）

- `WFMonitor.kt` 新增 initCf 拉取
- 需要服务端配合实现接口
