package com.webfunny.monitor.core

import android.content.Context
import android.util.Log
import com.webfunny.monitor.model.BaseLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPOutputStream

/**
 * 批量队列上报核心
 *
 * 策略：
 *   1. 日志先入内存队列
 *   2. 满 maxQueueSize 条，或定时器到期（flushIntervalMs），触发批量上报
 *   3. flush 时先持久化到磁盘（进程被杀也不丢），再网络上报
 *   4. 上报失败进入重试（4s → 16s → 32s，最多 3 次）
 *   5. 启动时扫描残留文件并恢复重试
 *   6. body > 1KB 时 gzip 压缩
 *   7. 所有操作在独立线程池执行，不阻塞主线程
 */
object WFUploader {

    private const val TAG = "WFUploader"
    private const val MAX_RETRY = 3
    private const val GZIP_THRESHOLD = 1024  // 1 KB

    private lateinit var config: WFConfig
    private lateinit var appContext: Context

    private val queue = CopyOnWriteArrayList<Map<String, Any?>>()
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val retryExecutor: ScheduledExecutorService = Executors.newScheduledThreadPool(1)

    fun init(context: Context, cfg: WFConfig) {
        appContext = context.applicationContext
        config = cfg

        WFDiskManager.init(appContext)

        // 定时刷新
        executor.scheduleWithFixedDelay(
            { flush() },
            cfg.flushIntervalMs,
            cfg.flushIntervalMs,
            TimeUnit.MILLISECONDS
        )

        // 启动恢复：扫描残留批次文件并重试
        executor.execute { recoverPendingBatches() }
        // 启动清理
        executor.execute { WFDiskManager.cleanExpired() }
        executor.execute { WFDiskManager.enforceDiskLimit() }
    }

    /** 加入队列，超出阈值立即触发上报 */
    fun enqueue(log: Map<String, Any?>) {
        queue.add(log)
        if (config.debugLog) {
            val type = log["uploadType"] ?: "?"
            Log.d(TAG, "[入队] $type → 队列 ${queue.size}/${config.maxQueueSize}")
        }
        if (queue.size >= config.maxQueueSize) {
            executor.execute { flush() }
        }
    }

    /** 将 BaseLog 对象转 Map 后入队 */
    fun enqueue(log: BaseLog) {
        enqueue(log.toMap())
    }

    /** 立即刷新队列（App 退到后台时调用） */
    fun flushNow() {
        executor.execute { flush() }
    }

    // ─── 内部实现 ────────────────────────────────────────────────

    @Synchronized
    private fun flush() {
        if (queue.isEmpty()) return
        val batch = queue.toList()
        queue.clear()

        // ① 先持久化到磁盘（进程被杀也不丢）
        val file = WFDiskManager.saveBatch(batch)

        // ② 再网络上报（成功后删磁盘文件，失败由重试机制兜底）
        if (config.debugLog) Log.d(TAG, "[刷新] 开始上报 ${batch.size} 条 → ${config.uploadUrl}")
        upload(batch, file)
    }

    /**
     * 上报一批日志，失败时启动重试
     * @param logs    日志列表
     * @param batchFile 对应的磁盘文件（成功后删除，失败由重试机制处理）
     * @param retryCount 当前重试次数（首次为 0）
     */
    private fun upload(logs: List<Map<String, Any?>>, batchFile: File, retryCount: Int = 0) {
        try {
            val jsonArray = JSONArray()
            logs.forEach { jsonArray.put(JSONObject(it)) }
            var bodyBytes = jsonArray.toString().toByteArray(Charsets.UTF_8)
            var useGzip = false

            // gzip 压缩（body > 1KB 且 config.gzip 为 true 时启用）
            if (config.gzip && bodyBytes.size > GZIP_THRESHOLD) {
                val bos = ByteArrayOutputStream()
                GZIPOutputStream(bos).use { it.write(bodyBytes) }
                bodyBytes = bos.toByteArray()
                useGzip = true
            }

            if (config.debugLog) {
                val types = logs.map { it["uploadType"] ?: "?" }.distinct()
                Log.d(TAG, "[上报] ${logs.size} 条, 类型=$types, gzip=$useGzip, 大小=${bodyBytes.size} bytes, URL=${config.uploadUrl}")
                val preview = if (jsonArray.toString().length > 2000) jsonArray.toString().take(2000) + "..." else jsonArray.toString()
                Log.d(TAG, "[上报] Body:\n$preview")
            }

            val conn = (URL(config.uploadUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json;charset=UTF-8")
                if (useGzip) setRequestProperty("Content-Encoding", "gzip")
                // 注入请求签名（防篡改）
                val signature = WFSignature.generate(
                    storedSignature = appContext
                        .getSharedPreferences("wf_monitor_session", Context.MODE_PRIVATE)
                        .getString("wf_signature", "") ?: "",
                    webMonitorId = config.webMonitorId
                )
                if (signature.isNotBlank()) {
                    setRequestProperty("wf-signature", signature)
                }
                doOutput = true
                connectTimeout = 10_000
                readTimeout = 10_000
            }
            conn.outputStream.use { it.write(bodyBytes) }
            val code = conn.responseCode
            val respBody = try {
                if (code in 200..299) conn.inputStream.bufferedReader().readText()
                else conn.errorStream?.bufferedReader()?.readText() ?: ""
            } catch (e: Exception) {
                try { conn.errorStream.bufferedReader().readText() } catch (_: Exception) { "" }
            }
            conn.disconnect()

            if (config.debugLog) {
                Log.d(TAG, "[上报] 状态码=$code 条数=${logs.size}")
                if (respBody.isNotEmpty()) Log.d(TAG, "[上报] 响应: $respBody")
            }

            if (code in 200..299) {
                // 成功：删除磁盘文件
                WFDiskManager.deleteBatch(batchFile)
            } else {
                if (config.debugLog) Log.w(TAG, "[上报] 服务器返回非 2xx（$code），进入重试")
                scheduleRetry(batchFile, retryCount)
            }
        } catch (e: Exception) {
            if (config.debugLog) Log.e(TAG, "上报失败：${e.message}")
            scheduleRetry(batchFile, retryCount)
        }
    }

    // ─── 重试机制 ────────────────────────────────────────────────

    /** 调度重试：4s → 16s → 32s，最多 3 次 */
    private fun scheduleRetry(file: File, currentRetry: Int) {
        if (currentRetry >= MAX_RETRY) {
            Log.w(TAG, "重试已达上限 ${MAX_RETRY} 次，删除文件: ${file.name}")
            WFDiskManager.deleteBatch(file)
            return
        }

        val delay = when (currentRetry) {
            0 -> 4_000L
            1 -> 16_000L
            else -> 32_000L
        }

        if (config.debugLog) Log.d(TAG, "计划第 ${currentRetry + 1} 次重试（${delay}ms 后）: ${file.name}")

        retryExecutor.schedule({
            val newFile = WFDiskManager.renameForRetry(file)
            if (newFile != null) {
                retryUpload(newFile, currentRetry + 1)
            } else {
                Log.e(TAG, "rename 失败，删除文件: ${file.name}")
                WFDiskManager.deleteBatch(file)
            }
        }, delay, TimeUnit.MILLISECONDS)
    }

    /** 重试上传 */
    private fun retryUpload(file: File, retryCount: Int) {
        val logs = WFDiskManager.loadBatch(file)
        if (logs.isEmpty()) {
            WFDiskManager.deleteBatch(file)
            return
        }
        if (config.debugLog) Log.d(TAG, "第 $retryCount 次重试上传: ${file.name}（${logs.size} 条）")
        // 复用 upload 逻辑（成功会 delete，失败会 scheduleRetry）
        upload(logs, file, retryCount)
    }

    /** 启动时恢复残留批次 */
    private fun recoverPendingBatches() {
        // 先恢复旧版崩溃文件（CrashCollector 同步写入的 wf_crash_log.json）
        recoverLegacyCrashFile()

        val files = WFDiskManager.loadAllBatches()
        if (files.isEmpty()) return

        if (config.debugLog) Log.d(TAG, "发现 ${files.size} 个待恢复批次文件")

        for (file in files) {
            val retry = WFDiskManager.parseRetry(file)
            if (retry >= MAX_RETRY) {
                if (config.debugLog) Log.d(TAG, "文件已超最大重试次数，删除: ${file.name}")
                WFDiskManager.deleteBatch(file)
                continue
            }
            // 超过 2 分钟的老文件，直接重试；否则按正常调度
            val fileAge = System.currentTimeMillis() - file.lastModified()
            if (fileAge > 120_000) {
                if (config.debugLog) Log.d(TAG, "老文件（${fileAge}ms），跳过等待直接重试: ${file.name}")
                retryUpload(file, retry)
            } else {
                scheduleRetry(file, retry)
            }
        }
    }

    /** 恢复旧版崩溃文件 wf_crash_log.json（CrashCollector 同步写入） */
    private fun recoverLegacyCrashFile() {
        try {
            val file = File(appContext.cacheDir, "wf_crash_log.json")
            if (!file.exists()) return
            val content = file.readText()
            val arr = JSONArray(content)
            if (arr.length() == 0) {
                file.delete()
                return
            }
            val logs = (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                obj.keys().asSequence().associateWith { key -> obj.get(key) }
            }
            if (config.debugLog) Log.d(TAG, "发现旧版崩溃文件 ${logs.size} 条，开始恢复")
            // 转存到 DiskManager 并上传（upload 内部处理成功删除/失败重试）
            val batchFile = WFDiskManager.saveBatch(logs)
            upload(logs, batchFile)
            // upload 成功会删除 batchFile，检查它是否还在
            if (!batchFile.exists()) {
                file.delete()
                if (config.debugLog) Log.d(TAG, "旧版崩溃文件恢复成功，已删除")
            }
        } catch (e: Exception) {
            if (config.debugLog) Log.e(TAG, "旧版崩溃文件恢复失败: ${e.message}")
        }
    }
}

