package com.webfunny.monitor.core

/**
 * 请求签名工具
 *
 * 复刻 H5 SDK 的 signature.js 逻辑：
 *   1. decryptSignature：对服务端下发的 signature 做字符位置置换（还原密钥）
 *   2. simpleHash：对 "{secret}:{webMonitorId}" 做简单哈希，生成请求头 wf-signature 的值
 *
 * 使用方式（SDK 内部调用，外部无需感知）：
 *   val sig = WFSignature.generate(storedSignature, webMonitorId)
 *   request.header("wf-signature", sig)
 */
object WFSignature {

    /**
     * 对服务端下发的原始 signature 做字符位置置换，还原出密钥
     */
    private fun decrypt(originSignature: String): String {
        if (originSignature.length < 32) return ""
        return try {
            val arr = originSignature.toCharArray()
            fun swap(i: Int, j: Int) { val t = arr[i]; arr[i] = arr[j]; arr[j] = t }
            swap(2, 21)
            swap(5, 18)
            swap(9, 15)
            swap(12, 31)
            swap(16, 28)
            swap(20, 25)
            arr.reversed().joinToString("")
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * 简单哈希
     */
    private fun simpleHash(str: String): Int {
        var hash = 0
        for (ch in str) {
            hash = (hash shl 5) - hash + ch.code
            hash = hash or 0
        }
        return hash
    }

    /**
     * 生成请求签名
     * @param storedSignature 从服务端 initCf 接口获取并本地存储的原始 signature
     * @param webMonitorId 当前项目监控 ID
     * @return 最终签名字符串，填入请求头 wf-signature；若签名为空则返回空字符串
     */
    fun generate(storedSignature: String, webMonitorId: String): String {
        if (storedSignature.isBlank()) return ""
        return try {
            val secret = decrypt(storedSignature)
            val str = "$secret:$webMonitorId"
            simpleHash(str).toString(16)
        } catch (e: Exception) {
            ""
        }
    }
}
