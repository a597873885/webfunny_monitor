package com.webfunny.event.core

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Base64
import android.util.Log
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * 会话状态管理
 *
 * 对应 H5 SDK 中以下功能的合并实现：
 *   - getCustomerKey()       → customerKey 设备指纹（持久化）
 *   - getAccessInfo()        → newStatus 新老用户判断
 *   - recordAccessTimes()    → accessTimes 访问次数统计
 *   - initUser()             → userId / nickname / userType / userTag / userDes
 *   - currentPage            → 当前页面路径（由 WFHeartBeatCollector 维护）
 */
object WFEventSession {

    private const val DAY_FORMAT = "yyyyMMdd"

    private lateinit var ctx: Context

    // ── customerKey：UUID + 时间后缀，持久化（本地存在则复用，不存在则重新生成） ──
    var customerKey: String = ""
        private set

    // ── deviceKey：神策方案（ANDROID_ID → 硬件 Hash → UUID），用于 weDeviceId ──
    var deviceKey: String = ""
        private set

    // ── sessionId：会话 ID（纯内存，冷启动/热启动时生成） ──
    var sessionId: String = ""
        private set

    // ── 通用属性（运行时可变，持久化） ──────────────────
    var commonInfo: String = ""
        private set

    // ── 用户信息（热更新，对应 H5 initUser） ──────────────────
    var userId: String   = ""
    var nickname: String = ""
    var userType: String = ""
    var userTag: String  = ""
    var userDes: String  = ""

    // ── 当前页面（由 WFHeartBeatCollector 实时维护） ──────────
    var currentPage: String = ""

    // ── 新老用户（对应 H5 getAccessInfo().newStatus） ─────────
    /** 1=今日新用户，2=老用户 */
    var newStatus: Int = 1
        private set

    fun init(context: Context) {
        ctx = context.applicationContext
        initCustomerKey()
        // 必须在 initDeviceKey() 之前执行，因为 deviceKey 的硬件 Hash 依赖 KEY_FIRST_INSTALL
        initAccessInfo()
        initDeviceKey()
        initCommonInfo()
        initSessionId()
    }

    // ─── 会话 ID ────────────────────────────────────────────

    /** 生成新 sessionId（冷启动时由 init() 调用，热启动时由 WFAppTracker 调用） */
    fun renewSessionId() {
        sessionId = UUID.randomUUID().toString()
    }

    private fun initSessionId() {
        renewSessionId()
    }

    // ─── 用户信息 ────────────────────────────────────────────

    /** 对应 H5 WebfunnyEvents.initUser()，登录后调用 */
    fun setUser(
        userId: String   = "",
        nickname: String = "",
        userType: String = "",
        userTag: String  = "",
        des: String      = ""
    ) {
        this.userId   = userId
        this.nickname = nickname
        this.userType = userType
        this.userTag  = userTag
        this.userDes  = des

        // 持久化用户信息（对应 H5 setWfCookie('wfEventUserInfo', ...)）
        val json = JSONObject().apply {
            put("userId",   userId)
            put("nickname", nickname)
            put("userType", userType)
            put("userTag",  userTag)
            put("des",      des)
        }
        WFEventStorage.putString(ctx, WFEventStorage.KEY_USER_INFO, json.toString())
    }

    /** 从持久化恢复用户信息（App 重启后调用） */
    fun restoreUser() {
        val str = WFEventStorage.getString(ctx, WFEventStorage.KEY_USER_INFO)
        if (str.isBlank()) return
        try {
            val json = JSONObject(str)
            userId   = json.optString("userId")
            nickname = json.optString("nickname")
            userType = json.optString("userType")
            userTag  = json.optString("userTag")
            userDes  = json.optString("des")
        } catch (e: Exception) { /* 静默 */ }
    }

    // ─── 通用属性 ──────────────────────────────────────────

    /** 设置通用属性（持久化到本地，上报时自动附加到 weCommonInfo） */
    fun setCommonInfo(params: Map<String, Any>) {
        if (params.isEmpty()) {
            commonInfo = ""
            WFEventStorage.remove(ctx, WFEventStorage.KEY_COMMON_INFO)
            return
        }
        try {
            val jsonStr = JSONObject(params).toString()
            commonInfo = Base64.encodeToString(jsonStr.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            WFEventStorage.putString(ctx, WFEventStorage.KEY_COMMON_INFO, commonInfo)
        } catch (e: Exception) { /* 静默 */ }
    }

    private fun initCommonInfo() {
        commonInfo = WFEventStorage.getString(ctx, WFEventStorage.KEY_COMMON_INFO)
    }

    // ─── 内部初始化 ──────────────────────────────────────────

    /** customerKey：UUID + 时间后缀，保存在本地，存在则复用 */
    private fun initCustomerKey() {
        val saved = WFEventStorage.getString(ctx, WFEventStorage.KEY_CUSTOMER_KEY)
        if (saved.isNotBlank()) {
            customerKey = saved
            return
        }
        // 首次生成：UUID（随机数版本）+ 时间后缀
        val uuid = generateUuidWithTimestamp()
        customerKey = uuid
        WFEventStorage.putString(ctx, WFEventStorage.KEY_CUSTOMER_KEY, customerKey)
    }

    /** deviceKey：神策方案（ANDROID_ID → 硬件 Hash → UUID） */
    private fun initDeviceKey() {
        val saved = WFEventStorage.getString(ctx, WFEventStorage.KEY_DEVICE_KEY)
        if (saved.isNotBlank()) {
            deviceKey = saved
            return
        }

        // 优先级 1: ANDROID_ID
        val androidId = getAndroidId(ctx)
        if (androidId.isNotBlank()) {
            deviceKey = "aid_$androidId"
            WFEventStorage.putString(ctx, WFEventStorage.KEY_DEVICE_KEY, deviceKey)
            return
        }

        // 优先级 2: 硬件特征 Hash
        val hwHash = getHardwareHash(ctx)
        if (hwHash.isNotBlank()) {
            deviceKey = "hw_$hwHash"
            WFEventStorage.putString(ctx, WFEventStorage.KEY_DEVICE_KEY, deviceKey)
            return
        }

        // 优先级 3: UUID 最终兜底
        val uuid = generateUuidWithTimestamp()
        deviceKey = "uuid_$uuid"
        WFEventStorage.putString(ctx, WFEventStorage.KEY_DEVICE_KEY, deviceKey)
    }

    /** 生成 UUID + 时间后缀，对标 H5 getUuid() */
    private fun generateUuidWithTimestamp(): String {
        val ts = SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(Date())
        val chars = "0123456789abcdef"
        val sections = intArrayOf(8, 4, 4, 4, 12)
        val sb = StringBuilder()
        for ((i, len) in sections.withIndex()) {
            for (j in 0 until len) {
                if (i == 2 && j == 0) {
                    // 第 3 节首字符固定为 '4'
                    sb.append('4')
                } else if (i == 3 && j == 0) {
                    // 第 4 节首字符固定为 8/b/a 之一
                    val r = (Math.random() * 4).toInt()
                    sb.append("89ab"[r])
                } else {
                    sb.append(chars[(Math.random() * 16).toInt()])
                }
            }
            if (i < sections.size - 1) sb.append('-')
        }
        sb.append('-').append(ts)
        return sb.toString()
    }

    /** 获取 ANDROID_ID，过滤无效值 */
    private fun getAndroidId(context: Context): String {
        return try {
            val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            if (id.isNullOrBlank()) return ""
            if (id == "9774d56d682e549c" || id == "0000000000000000") return ""
            id
        } catch (e: Exception) { "" }
    }

    /** 硬件特征 Hash */
    private fun getHardwareHash(context: Context): String {
        return try {
            val firstInstall = WFEventStorage.getString(context, WFEventStorage.KEY_FIRST_INSTALL)
            val raw = "${Build.MANUFACTURER}|${Build.MODEL}|${Build.HARDWARE}|${Build.BOARD}|${Build.PRODUCT}|$firstInstall"
            val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
            digest.take(16).joinToString("") { "%02x".format(it) }
        } catch (e: Exception) { "" }
    }

    /**
     * 初始化新老用户 + 访问次数
     * 对应 H5 的 getAccessInfo() + recordAccessTimes()
     */
    private fun initAccessInfo() {
        val today = today()

        // 首次安装日期（永久存储，用于新老用户判断）
        val firstInstall = WFEventStorage.getString(ctx, WFEventStorage.KEY_FIRST_INSTALL)
        if (firstInstall.isBlank()) {
            WFEventStorage.putString(ctx, WFEventStorage.KEY_FIRST_INSTALL, today)
        }
        val installDate = WFEventStorage.getString(ctx, WFEventStorage.KEY_FIRST_INSTALL)

        // 新老用户：首次安装当天为新用户（1），之后为老用户（2）
        // 对应 H5：dateStr === currentDate ? 1 : 2
        newStatus = if (installDate == today) 1 else 2

        // 访问次数（按天去重，每天只计一次）
        val lastAccessDate = WFEventStorage.getString(ctx, WFEventStorage.KEY_LAST_ACCESS_DATE)
        if (lastAccessDate != today) {
            val times = WFEventStorage.getInt(ctx, WFEventStorage.KEY_ACCESS_TIMES, 0)
            WFEventStorage.putInt(ctx, WFEventStorage.KEY_ACCESS_TIMES, times + 1)
            WFEventStorage.putString(ctx, WFEventStorage.KEY_LAST_ACCESS_DATE, today)
        }
    }

    private fun today(): String =
        SimpleDateFormat(DAY_FORMAT, Locale.getDefault()).format(Date())
}
