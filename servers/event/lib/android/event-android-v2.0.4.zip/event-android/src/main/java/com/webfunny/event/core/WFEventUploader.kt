package com.webfunny.event.core

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPOutputStream

/**
 * 埋点数据批量上报核心 v2.0
 *
 * - flush 先持久化再清空内存队列，最后网络上报
 * - body > 1KB 时 gzip 压缩
 * - 上报失败进入重试（4s → 16s → 32s，最多 3 次）
 * - 启动时扫描残留文件并恢复重试
 */
object WFEventUploader {

    private const val TAG = "WFEventUploader"
    private const val MAX_RETRY = 3
    private const val GZIP_THRESHOLD = 1024  // 1 KB

    private lateinit var config: WFEventConfig
    private lateinit var appContext: Context

    private val queue = CopyOnWriteArrayList<Map<String, Any>>()
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val retryExecutor: ScheduledExecutorService = Executors.newScheduledThreadPool(1)

    fun init(context: Context, cfg: WFEventConfig) {
        appContext = context.applicationContext
        config = cfg

        WFEventDiskManager.init(appContext)

        executor.scheduleWithFixedDelay(
            { flush() },
            cfg.flushIntervalMs,
            cfg.flushIntervalMs,
            TimeUnit.MILLISECONDS
        )

        // 启动恢复：扫描残留文件并重试
        executor.execute { recoverPendingBatches() }
        // 启动清理
        executor.execute { WFEventDiskManager.cleanExpired() }
        executor.execute { WFEventDiskManager.enforceDiskLimit() }
    }

    /** 加入内存队列 */
    fun enqueue(log: Map<String, Any>) {
        queue.add(log)
        if (queue.size >= config.maxQueueSize) {
            executor.execute { flush() }
        }
    }

    /** 立即刷新 */
    fun flushNow() {
        executor.execute { flush() }
    }

    // ─── 内部实现 ────────────────────────────────────────────────

    @Synchronized
    private fun flush() {
        if (queue.isEmpty()) return
        val batch = queue.toList()
        queue.clear()

        // 1. 先持久化到磁盘
        val file = WFEventDiskManager.saveBatch(batch)

        // 2. 网络上报
        upload(batch, file)
    }

    /** 上报一批日志，失败时启动重试 */
    private fun upload(logs: List<Map<String, Any>>, batchFile: File, retryCount: Int = 0) {
        try {
            val jsonArray = JSONArray()
            logs.forEach { jsonArray.put(JSONObject(it)) }
            var bodyBytes = jsonArray.toString().toByteArray(Charsets.UTF_8)
            var useGzip = false

            // gzip 压缩（> 1KB 且 config.setting.gzip 为 true 时启用）
            if (config.setting.gzip && bodyBytes.size > GZIP_THRESHOLD) {
                val bos = ByteArrayOutputStream()
                GZIPOutputStream(bos).use { it.write(bodyBytes) }
                bodyBytes = bos.toByteArray()
                useGzip = true
            }

            val signature = WFSignature.generate(
                storedSignature = WFEventStorage.getString(appContext, WFEventStorage.KEY_SIGNATURE),
                projectId       = config.projectId
            )

            if (config.setting.debugLog) {
                Log.d(TAG, "┌─────────── WFEvent 上报请求 ───────────────")
                Log.d(TAG, "│ URL     : ${config.uploadUrl}")
                Log.d(TAG, "│ 条数    : ${logs.size}")
                Log.d(TAG, "│ gzip    : $useGzip")
                Log.d(TAG, "│ 大小    : ${bodyBytes.size} bytes")
                Log.d(TAG, "│ Body    : ${jsonArray.toString()}")
                Log.d(TAG, "└────────────────────────────────────────────")
            }

            val conn = (URL(config.uploadUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json;charset=UTF-8")
                if (useGzip) setRequestProperty("Content-Encoding", "gzip")
                if (signature.isNotBlank()) setRequestProperty("wf-signature", signature)
                doOutput = true
                connectTimeout = 10_000
                readTimeout    = 10_000
            }
            conn.outputStream.use { it.write(bodyBytes) }
            val code = conn.responseCode
            val responseBody = try {
                if (code in 200..299) conn.inputStream.bufferedReader().readText()
                else conn.errorStream?.bufferedReader()?.readText() ?: ""
            } catch (e: Exception) { "" }
            conn.disconnect()

            if (config.setting.debugLog) {
                Log.d(TAG, "◆ 上报响应：状态码=$code")
            }

            if (code in 200..299) {
                // 成功：删除磁盘文件
                WFEventDiskManager.deleteBatch(batchFile)
            } else {
                Log.w(TAG, "上报失败（状态码=$code），进入重试: $responseBody")
                scheduleRetry(batchFile, retryCount)
            }
        } catch (e: Exception) {
            Log.e(TAG, "上报异常：${e.message}")
            scheduleRetry(batchFile, retryCount)
        }
    }

    // ─── 重试机制 ────────────────────────────────────────────────

    /** 调度重试：4s → 16s → 32s，最多 3 次 */
    private fun scheduleRetry(file: File, currentRetry: Int) {
        if (currentRetry >= MAX_RETRY) {
            Log.w(TAG, "重试已达上限 ${MAX_RETRY} 次，删除文件: ${file.name}")
            WFEventDiskManager.deleteBatch(file)
            return
        }

        val delay = when (currentRetry) {
            0 -> 4_000L
            1 -> 16_000L
            else -> 32_000L
        }

            if (config.setting.debugLog) Log.d(TAG, "计划第 ${currentRetry + 1} 次重试（${delay}ms 后）: ${file.name}")

        retryExecutor.schedule({
            val newFile = WFEventDiskManager.renameForRetry(file)
            if (newFile != null) {
                retryUpload(newFile, currentRetry + 1)
            } else {
                Log.e(TAG, "rename 失败，删除文件: ${file.name}")
                WFEventDiskManager.deleteBatch(file)
            }
        }, delay, TimeUnit.MILLISECONDS)
    }

    /** 重试上传 */
    private fun retryUpload(file: File, retryCount: Int) {
        try {
            val content = file.readText()
            val arr = JSONArray(content)
            val logs = (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                obj.keys().asSequence().associateWith { key -> obj.get(key) }
            }

            if (config.setting.debugLog) Log.d(TAG, "第 $retryCount 次重试上传: ${file.name}（${logs.size} 条）")

            // 复用 upload 逻辑（成功会 delete，失败会 scheduleRetry）
            upload(logs, file, retryCount)
        } catch (e: Exception) {
            Log.e(TAG, "重试上传异常: ${e.message}")
            scheduleRetry(file, retryCount)
        }
    }

    /** 启动时恢复残留批次 */
    private fun recoverPendingBatches() {
        val files = WFEventDiskManager.loadAllBatches()
        if (files.isEmpty()) return

        if (config.setting.debugLog) Log.d(TAG, "发现 ${files.size} 个待恢复批次文件")

        for (file in files) {
            val retry = WFEventDiskManager.parseRetry(file)
            if (retry >= MAX_RETRY) {
                if (config.setting.debugLog) Log.d(TAG, "文件已超最大重试次数，删除: ${file.name}")
                WFEventDiskManager.deleteBatch(file)
                continue
            }
            // 老文件跳过前面几次等待，直接用最大间隔
            val fileAge = System.currentTimeMillis() - file.lastModified()
            if (fileAge > 120_000) {
                // 超过 2 分钟的老文件，直接按最终重试次数处理
                if (config.setting.debugLog) Log.d(TAG, "老文件（${fileAge}ms），跳过等待直接重试: ${file.name}")
                retryUpload(file, retry)
            } else {
                scheduleRetry(file, retry)
            }
        }
    }
}

