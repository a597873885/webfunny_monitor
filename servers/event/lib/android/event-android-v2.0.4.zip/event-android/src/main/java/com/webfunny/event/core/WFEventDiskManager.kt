package com.webfunny.event.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * 埋点数据磁盘持久化管理
 *
 * 一个批次一个文件，文件名含重试次数：
 *   wf_event_batch_{retry}_{timestamp}_{uuid}.json
 *
 * 磁盘上限 5MB（FIFO），过期 7 天自动清理。
 */
object WFEventDiskManager {

    private const val BATCH_DIR = "wf_event"
    private const val BATCH_PREFIX = "wf_event_batch_"
    private const val MAX_DISK_BYTES = 5L * 1024 * 1024   // 5 MB
    private const val EXPIRE_DAYS = 7L
    private const val EXPIRE_MS = EXPIRE_DAYS * 24 * 60 * 60 * 1000L

    private lateinit var batchDir: File

    fun init(context: Context) {
        batchDir = File(context.cacheDir, BATCH_DIR)
        if (!batchDir.exists()) batchDir.mkdirs()
    }

    /** 保存一批日志到文件，retry=0 */
    fun saveBatch(logs: List<Map<String, Any>>): File {
        val retry = 0
        val ts = System.currentTimeMillis()
        val uuid = UUID.randomUUID().toString().take(8)
        val file = File(batchDir, "${BATCH_PREFIX}${retry}_${ts}_${uuid}.json")
        val arr = JSONArray()
        logs.forEach { arr.put(JSONObject(it)) }
        file.writeText(arr.toString())
        enforceDiskLimit()
        return file
    }

    /** 扫描所有批次文件，按文件名（时间戳）排序 */
    fun loadAllBatches(): List<File> {
        return batchDir.listFiles()
            ?.filter { it.name.startsWith(BATCH_PREFIX) && it.name.endsWith(".json") }
            ?.sortedBy { parseTimestamp(it.name) }
            ?: emptyList()
    }

    /** 上报成功后删除 */
    fun deleteBatch(file: File): Boolean = file.delete()

    /** 重试时 rename 文件，retry +1 */
    fun renameForRetry(file: File): File? {
        val name = file.name
        val parts = name.removeSuffix(".json").removePrefix(BATCH_PREFIX).split("_", limit = 3)
        if (parts.size < 3) return null
        val oldRetry = parts[0].toIntOrNull() ?: return null
        val ts = parts[1]
        val uuid = parts[2]
        val newName = "${BATCH_PREFIX}${oldRetry + 1}_${ts}_${uuid}.json"
        val newFile = File(batchDir, newName)
        return if (file.renameTo(newFile)) newFile else null
    }

    /** 从文件名解析已重试次数 */
    fun parseRetry(file: File): Int {
        val name = file.name.removeSuffix(".json").removePrefix(BATCH_PREFIX)
        val parts = name.split("_", limit = 3)
        return parts.getOrNull(0)?.toIntOrNull() ?: 0
    }

    /** 磁盘上限检查：总大小 > 5MB 时 FIFO 淘汰最旧文件 */
    fun enforceDiskLimit() {
        val files = loadAllBatches()
        var totalSize = files.sumOf { it.length() }
        for (file in files) {
            if (totalSize <= MAX_DISK_BYTES) break
            val size = file.length()
            file.delete()
            totalSize -= size
        }
    }

    /** 清理过期文件（> 7 天） */
    fun cleanExpired() {
        val now = System.currentTimeMillis()
        loadAllBatches().forEach { file ->
            if (now - file.lastModified() > EXPIRE_MS) {
                file.delete()
            }
        }
    }

    private fun parseTimestamp(name: String): Long {
        val parts = name.removeSuffix(".json").removePrefix(BATCH_PREFIX).split("_", limit = 3)
        return parts.getOrNull(1)?.toLongOrNull() ?: 0L
    }
}
