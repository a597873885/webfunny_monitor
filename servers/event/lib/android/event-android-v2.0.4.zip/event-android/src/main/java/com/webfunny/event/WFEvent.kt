package com.webfunny.event

import android.app.Application
import android.util.Log
import com.webfunny.event.collector.WFAppClickCollector
import com.webfunny.event.collector.WFAppTracker
import com.webfunny.event.core.WFEventConfig
import com.webfunny.event.core.WFEventSession
import com.webfunny.event.core.WFEventStorage
import com.webfunny.event.core.WFEventUploader
import com.webfunny.event.model.WFEventLog
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Webfunny 埋点 SDK 唯一对外入口
 *
 * ── 接入步骤 ──────────────────────────────────────────────────────
 *
 * 1. Application.onCreate() 中初始化（风格与 H5 SDK 完全对齐）：
 *
 *    class MyApp : Application() {
 *        override fun onCreate() {
 *            super.onCreate()
 *            WFEvent.initEvent(
 *                this,
 *                WFEventConfig(
 *                    uploadDomain = "https://your-server.com/",
 *                    projectId      = "event_20250312_153829902",
 *                    env            = "pro",
 *                    projectVersion = "1.0.0",
 *                    initPoints     = WFInitPoints(heatBeat=9, mouseStop=10, click=11, browsing=13),
 *                    setting        = WFSetting(
 *                        heartBeat = WFHeartBeatSetting(enable=true, gap=15)
 *                    )
 *                )
 *            )
 *        }
 *    }
 *
 * 2. 用户登录后设置用户信息：
 *    WFEvent.setUser(userId = "user_123", nickname = "张三")
 *
 * 3. 上报埋点事件：
 *    WFEvent.track(
 *        pointId = "456",
 *        params  = mapOf("behaviorType" to "点击", "buttonName" to "立即购买")
 *    )
 */
object WFEvent {

    private const val TAG = "WFEvent"
    private lateinit var config: WFEventConfig
    private lateinit var application: Application
    private val initExecutor = Executors.newSingleThreadExecutor()

    // ── 手动页面采集状态 ────────────────────────────────────
    private var manualPageTitle: String = ""
    private var manualPagePath: String = ""
    private var manualReferPage: String = ""
    private var manualPageEnterMs: Long = 0L

    /**
     * 初始化 SDK v2.0
     *
     * 内部流程：
     *   1. 初始化 Session（customerKey / 新老用户 / 访问次数）
     *   2. 启动上报队列定时器
     *   3. 启动全埋点采集器（WFAppTracker + WFAppClickCollector）
     *   4. 异步拉取服务端 initCf
     */
    fun initEvent(application: Application, config: WFEventConfig) {
        this.config = config
        this.application = application

        WFEventSession.init(application)
        WFEventSession.restoreUser()

        WFEventUploader.init(application, config)

        // 全埋点采集器
        if (config.setting.heartBeat.enable ||
            config.autoTrack.appStart || config.autoTrack.appEnd ||
            config.autoTrack.appPageEnter || config.autoTrack.appPageLeave ||
            config.autoTrack.appHeartBeat) {
            WFAppTracker(application, config).install()
        }
        if (config.autoTrack.appClick) {
            WFAppClickCollector(application, config).install()
        }

        initExecutor.execute { fetchInitCf(application, config) }
    }

    /**
     * 设置用户信息（登录后调用）
     * 对应 H5 的 WebfunnyEvents.initUser()
     */
    fun setUser(
        userId: String   = "",
        nickname: String = "",
        userType: String = "",
        userTag: String  = "",
        des: String      = ""
    ) {
        WFEventSession.setUser(userId, nickname, userType, userTag, des)
    }

    /**
     * 设置通用属性（持久化到本地，上报时自动附加到 weCommonInfo）
     * 对应 H5 / iOS setCommonInfo()
     *
     * @param params 键值对，传空 Map 清空通用属性
     */
    fun setCommonInfo(params: Map<String, Any>) {
        WFEventSession.setCommonInfo(params)
    }

    /**
     * 上报埋点事件（核心方法）
     * 对应 H5 的 _webfunnyEvent(pointId).trackEvent(params)
     *
     * @param pointId 埋点点位 ID（在 Webfunny 事件分析控制台配置）
     * @param params  业务参数，所有字符串值会自动 base64 编码后上报
     * @param upNow   是否立即上报（默认 false，加入队列等待批量上报）
     */
    fun track(
        pointId: String,
        params: Map<String, Any> = emptyMap(),
        upNow: Boolean = false
    ) {
        if (!::config.isInitialized) {
            Log.w(TAG, "WFEvent.initEvent() 尚未调用，track() 被忽略")
            return
        }
        try {
            val log = WFEventLog(config, pointId, params, "custom", application)
            WFEventUploader.enqueue(log.toMap())
            if (upNow) WFEventUploader.flushNow()
        } catch (e: Exception) {
            if (config.setting.debugLog) Log.e(TAG, "track error: ${e.message}")
        }
    }

    /**
     * 上报埋点事件（按环境选点位 ID）
     * 对应 H5 的 window.webfunnyEvent({ pro: 747, dev: "xxx" }).trackEvent(params, { upNow })
     *
     * 用法示例：
     *   WFEvent.track(
     *       pointIds = mapOf("pro" to "747", "dev" to "xxx"),
     *       params   = mapOf("anNiuMingCheng" to "立即购买"),
     *       upNow    = false
     *   )
     *
     * @param pointIds 各环境对应的点位 ID，key 与 WFEventConfig.env 一致（如 "pro"/"dev"/"sit"/"stag"）
     * @param params   业务参数
     * @param upNow    是否立即上报
     */
    fun track(
        pointIds: Map<String, Any>,
        params: Map<String, Any> = emptyMap(),
        upNow: Boolean = false
    ) {
        if (!::config.isInitialized) {
            Log.w(TAG, "WFEvent.initEvent() 尚未调用，track() 被忽略")
            return
        }
        // 按当前 env 取对应点位 ID，找不到则依次 fallback：pro → 第一个值
        val resolved = pointIds[config.env]
            ?: pointIds["pro"]
            ?: pointIds.values.firstOrNull()
        if (resolved == null) {
            Log.w(TAG, "track() pointIds 中找不到匹配环境 '${config.env}' 的点位 ID，已跳过")
            return
        }
        track(pointId = resolved.toString(), params = params, upNow = upNow)
    }

    /** 立即刷新上报队列（App 进入后台时可主动调用） */
    fun flush() {
        WFEventUploader.flushNow()
    }

    // ─── 手动页面采集 ────────────────────────────────────────────

    /**
     * 手动上报页面浏览事件（进入）
     *
     * 适用于全埋点无法覆盖的场景：Fragment、Tab 切换、Compose 等。
     * 调用后会自动记录进入时间戳，配合 [trackPageLeave] 自动计算停留时长。
     *
     * @param pageTitle 页面名称（必填）
     * @param pagePath  页面路径（选填，默认同 pageTitle）
     * @param params    附加业务参数
     */
    fun trackPageView(
        pageTitle: String,
        pagePath: String = pageTitle,
        params: Map<String, Any> = emptyMap()
    ) {
        if (!::config.isInitialized) {
            Log.w(TAG, "WFEvent.initEvent() 尚未调用，trackPageView() 被忽略")
            return
        }

        val enterPointId = config.appPoints.appPageEnter
        if (enterPointId == 0) {
            Log.w(TAG, "appPageEnter 点位 ID 未配置，trackPageView() 被忽略")
            return
        }

        try {
            val allParams = mutableMapOf<String, Any>(
                "appPageTitle" to pageTitle,
                "appPagePath" to pagePath,
                "appReferPage" to manualReferPage
            )
            allParams.putAll(params)

            val log = WFEventLog(config, enterPointId.toString(), allParams, "appPageEnter", application)
            WFEventUploader.enqueue(log.toMap())

            // 更新手动页面状态
            manualReferPage = pageTitle
            manualPageTitle = pageTitle
            manualPagePath = pagePath
            manualPageEnterMs = System.currentTimeMillis()
            WFEventSession.currentPage = pageTitle

            if (config.setting.debugLog) {
                Log.d(TAG, "trackPageView: title=$pageTitle path=$pagePath refer=$manualReferPage")
            }
        } catch (e: Exception) {
            if (config.setting.debugLog) Log.e(TAG, "trackPageView error: ${e.message}")
        }
    }

    /**
     * 手动上报页面浏览事件（离开）
     *
     * 与 [trackPageView] 配对使用。不传 stayDuration 时自动计算（基于上次 trackPageView 的时间）。
     *
     * @param pageTitle     页面名称（选填，默认取上次 trackPageView 的值）
     * @param pagePath      页面路径（选填，默认取上次 trackPageView 的值）
     * @param stayDuration  停留时长（毫秒，选填，不传则自动计算）
     * @param params        附加业务参数
     */
    fun trackPageLeave(
        pageTitle: String = manualPageTitle,
        pagePath: String = manualPagePath,
        stayDuration: Long = -1L,
        params: Map<String, Any> = emptyMap()
    ) {
        if (!::config.isInitialized) {
            Log.w(TAG, "WFEvent.initEvent() 尚未调用，trackPageLeave() 被忽略")
            return
        }

        val leavePointId = config.appPoints.appPageLeave
        if (leavePointId == 0) {
            Log.w(TAG, "appPageLeave 点位 ID 未配置，trackPageLeave() 被忽略")
            return
        }

        try {
            // 自动计算停留时长
            val duration = if (stayDuration >= 0) stayDuration
                          else if (manualPageEnterMs > 0) System.currentTimeMillis() - manualPageEnterMs
                          else 0L

            val allParams = mutableMapOf<String, Any>(
                "appPageTitle" to pageTitle,
                "appPagePath" to pagePath,
                "appStayDuration" to duration
            )
            allParams.putAll(params)

            val log = WFEventLog(config, leavePointId.toString(), allParams, "appPageLeave", application)
            WFEventUploader.enqueue(log.toMap())

            if (config.setting.debugLog) {
                Log.d(TAG, "trackPageLeave: title=$pageTitle path=$pagePath duration=${duration}ms")
            }
        } catch (e: Exception) {
            if (config.setting.debugLog) Log.e(TAG, "trackPageLeave error: ${e.message}")
        }
    }

    // ─── 内部：拉取服务端初始化配置 ─────────────────────────────

    private fun fetchInitCf(application: android.content.Context, cfg: WFEventConfig) {
        try {
            val bodyStr = JSONObject().apply {
                put("projectId", cfg.projectId)
                put("userId",    WFEventSession.userId)
                put("nickname",  WFEventSession.nickname)
            }.toString()
            val body = bodyStr.toByteArray(Charsets.UTF_8)

            if (config.setting.debugLog) {
                Log.d(TAG, "┌─────────── WFEvent initCf 请求 ────────────")
                Log.d(TAG, "│ URL  : ${cfg.initCfUrl}")
                Log.d(TAG, "│ Body : $bodyStr")
                Log.d(TAG, "└────────────────────────────────────────────")
            }

            val conn = (URL(cfg.initCfUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json;charset=UTF-8")
                doOutput = true
                connectTimeout = 10_000
                readTimeout    = 10_000
            }
            conn.outputStream.use { it.write(body) }

            val code = conn.responseCode
            val responseBody = try {
                if (code in 200..299) conn.inputStream.bufferedReader().readText()
                else conn.errorStream?.bufferedReader()?.readText() ?: ""
            } catch (e: Exception) { "" }
            conn.disconnect()

            if (config.setting.debugLog) Log.d(TAG, "◆ initCf 响应：状态码=$code  body=$responseBody")

            if (code in 200..299) {
                parseInitCfResponse(application, responseBody)
            }
        } catch (e: Exception) {
            Log.e(TAG, "initCf 请求失败：${e.message}")
        }
    }

    private fun parseInitCfResponse(context: android.content.Context, responseText: String) {
        try {
            val root = JSONObject(responseText)
            val data = root.optJSONObject("data") ?: return

            val signature = data.optString("signature")
            if (signature.isNotBlank()) {
                WFEventStorage.putString(context, WFEventStorage.KEY_SIGNATURE, signature)
                if (config.setting.debugLog) Log.d(TAG, "initCf 成功，signature 已更新")
            }

            val initPoints = data.optJSONObject("initPoints")
            if (initPoints != null) {
                WFEventStorage.putString(context, WFEventStorage.KEY_INIT_POINTS, initPoints.toString())
            }
        } catch (e: Exception) {
            if (config.setting.debugLog) Log.e(TAG, "initCf 响应解析失败：${e.message}")
        }
    }
}
