package com.webfunny.event.collector

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.accessibility.AccessibilityEvent
import com.webfunny.event.core.WFEventConfig
import com.webfunny.event.core.WFEventUploader
import com.webfunny.event.model.WFEventLog

/**
 * App 点击自动采集器（最小代价方案）
 *
 * 通过 AccessibilityDelegate 挂载到 DecorView，拦截 TYPE_VIEW_CLICKED 事件。
 * 零运行时开销（仅点击时触发），代码量 < 50 行。
 */
class WFAppClickCollector(
    private val app: Application,
    private val config: WFEventConfig
) {
    private val TAG = "WFAppClick"
    /** 同控件去重：上次点击的 viewId + 时间戳 */
    private var lastClickId: String = ""
    private var lastClickTime: Long = 0L
    private val dedupWindow = 300L  // ms

    fun install() {
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                if (!config.autoTrack.appClick) return
                activity.window?.decorView?.let { decorView ->
                    decorView.accessibilityDelegate = object : View.AccessibilityDelegate() {
                        override fun sendAccessibilityEvent(host: View, eventType: Int) {
                            if (eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                                handleClick(host)
                            }
                            super.sendAccessibilityEvent(host, eventType)
                        }
                    }
                }
            }

            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }

    private fun handleClick(view: View) {
        // 去重：同控件 300ms 内重复点击仅上报一次
        val clickId = viewIdString(view)
        val now = System.currentTimeMillis()
        if (clickId == lastClickId && now - lastClickTime < dedupWindow) return
        lastClickId = clickId
        lastClickTime = now

        val pointId = config.appPoints.appClick
        if (pointId == 0) return

        try {
            val log = WFEventLog(
                config,
                pointId.toString(),
                mapOf(
                    "viewId"    to clickId,
                    "viewText"  to viewText(view),
                    "viewType"  to (view.javaClass.simpleName),
                    "pageTitle" to (view.context as? Activity)?.javaClass?.simpleName.orEmpty()
                ),
                eventType = "appClick",
                context = app
            )
            WFEventUploader.enqueue(log.toMap())
        } catch (e: Exception) {
            Log.e(TAG, "appClick 事件构建失败: ${e.message}")
        }
    }

    /** 获取 View 的 resource-id 名称 */
    private fun viewIdString(view: View): String {
        return try {
            val id = view.id
            if (id != View.NO_ID) {
                view.resources.getResourceEntryName(id)
            } else {
                view.javaClass.simpleName
            }
        } catch (e: Exception) {
            view.javaClass.simpleName
        }
    }

    /** 获取 View 的显示文本 */
    private fun viewText(view: View): String {
        return try {
            when (view) {
                is android.widget.TextView -> view.text?.toString()?.take(50) ?: ""
                else -> view.contentDescription?.toString()?.take(50) ?: ""
            }
        } catch (e: Exception) { "" }
    }
}
