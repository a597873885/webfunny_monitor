package com.webfunny.event.core

// ─── App 全埋点点位配置 ──────────────────────────────────────────────────────

/**
 * App 端全埋点点位 ID 配置（6 点位，对标 Firebase / 神策 / GrowingIO）
 *
 * 与 H5 的 initPoints 完全分离，各自定义独立的点位体系。
 */
data class WFAppPoints(
    val appStart: Int     = 0,   // App 启动
    val appEnd: Int       = 0,   // App 进入后台
    val appPageEnter: Int = 0,   // 页面进入
    val appPageLeave: Int = 0,   // 页面离开
    val appClick: Int     = 0,   // 控件点击
    val appHeartBeat: Int = 0    // 心跳
)

/**
 * 全埋点开关控制
 */
data class WFAutoTrack(
    val appStart: Boolean     = true,
    val appEnd: Boolean       = true,
    val appPageEnter: Boolean = true,
    val appPageLeave: Boolean = true,
    val appClick: Boolean     = true,
    val appHeartBeat: Boolean = true
)

// ─── 心跳子配置 ──────────────────────────────────────────────────────────────

/**
 * 心跳子配置
 */
data class WFHeartBeatSetting(
    /** 心跳开关，true=开，false=关 */
    val enable: Boolean = true,
    /** 心跳间隔，单位：秒；有效枚举值：5 / 15 / 30 / 60，其他值自动回退为 15 */
    val gap: Int = 15,
    /**
     * 单次连续停留最大心跳次数，超出后停止上报（默认 120）
     *
     * 以 gap=15s 为例：120 次 = 30 分钟，覆盖绝大多数正常使用场景。
     * 防止用户挂机或异常情况导致心跳数据无限累积。
     * 设为 0 表示不限制。
     */
    val limit: Int = 120
) {
    /** 规范化后的有效间隔（秒） */
    val validGap: Int get() = when (gap) {
        5, 15, 30, 60 -> gap
        else -> 15
    }
    /** 转为毫秒，供内部定时器使用 */
    internal val gapMs: Long get() = validGap * 1_000L
}

/**
 * SDK 行为设置
 */
data class WFSetting(
    val heartBeat: WFHeartBeatSetting = WFHeartBeatSetting(),
    /** 是否打印 SDK 调试日志 */
    val debugLog: Boolean = false,
    /** 是否启用 gzip 压缩上报（默认 true） */
    val gzip: Boolean = true
)

// ─── 主配置类 ──────────────────────────────────────────────────────────────────

/**
 * Webfunny 埋点 SDK v2.0 初始化配置
 *
 * 示例：
 *   WFEvent.initEvent(
 *       this,
 *       WFEventConfig(
 *           uploadDomain = "https://your-server.com",
 *           projectId      = "event_20250312_xxx",
 *           appPoints      = WFAppPoints(appStart=10, appPageEnter=11, appPageLeave=12, appClick=13, appHeartBeat=14, appEnd=15),
 *           autoTrack      = WFAutoTrack(appClick=false)
 *       )
 *   )
 */
data class WFEventConfig(

    /** 上报服务域名，末尾斜杠可选，如：https://monitor.example.com */
    val uploadDomain: String,

    /** 埋点项目 ID，在 Webfunny 事件分析控制台创建项目后获取 */
    val projectId: String,

    /** 当前环境标识，可选：dev / sit / stag / pro（默认 pro） */
    val env: String = "pro",

    /** 应用版本号（默认 1.0.0） */
    val projectVersion: String = "1.0.0",

    /** App 全埋点点位 ID */
    val appPoints: WFAppPoints = WFAppPoints(),

    /** 全埋点开关 */
    val autoTrack: WFAutoTrack = WFAutoTrack(),

    /** SDK 行为配置（心跳、调试日志等） */
    val setting: WFSetting = WFSetting()

) {
    private val domain get() = uploadDomain.trimEnd('/')

    /** 初始化配置接口完整地址 */
    internal val initCfUrl: String get() = "$domain/wfEvent/initCf"

    /** 埋点数据批量上报接口完整地址 */
    internal val uploadUrl: String get() = "$domain/wfEvent/upEvents"

    /** 内部：队列最大条数（固定 20） */
    internal val maxQueueSize: Int = 20

    /** 内部：定时刷新间隔（固定 8s） */
    internal val flushIntervalMs: Long = 8_000L
}
