package com.webfunny.event.core

import android.content.Context
import android.content.SharedPreferences

/**
 * 统一本地存储工具
 *
 * 对应 H5 SDK 的 localStorage.WEBFUNNY_COOKIE（模拟 Cookie 实现）。
 * Android 使用 SharedPreferences 替代，不需要模拟过期时间（用 key 区分即可）。
 */
object WFEventStorage {

    private const val PREF_NAME = "wf_event_storage"

    // ── Key 常量 ─────────────────────────────────────────
    const val KEY_CUSTOMER_KEY         = "wf_event_customer_key"
    const val KEY_DEVICE_KEY           = "wf_event_device_key"
    const val KEY_COMMON_INFO          = "wf_event_common_info"
    const val KEY_SIGNATURE            = "wf_event_signature"
    const val KEY_FIRST_INSTALL        = "wf_event_first_install_date"
    const val KEY_ACCESS_TIMES         = "wf_event_access_times"
    const val KEY_LAST_ACCESS_DATE     = "wf_event_last_access_date"
    const val KEY_USER_INFO            = "wf_event_user_info"
    const val KEY_INIT_POINTS          = "wf_event_init_points"
    const val KEY_SETTING              = "wf_event_setting"

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun getString(context: Context, key: String, default: String = ""): String =
        prefs(context).getString(key, default) ?: default

    fun putString(context: Context, key: String, value: String) =
        prefs(context).edit().putString(key, value).apply()

    fun getInt(context: Context, key: String, default: Int = 0): Int =
        prefs(context).getInt(key, default)

    fun putInt(context: Context, key: String, value: Int) =
        prefs(context).edit().putInt(key, value).apply()

    fun remove(context: Context, key: String) =
        prefs(context).edit().remove(key).apply()
}
