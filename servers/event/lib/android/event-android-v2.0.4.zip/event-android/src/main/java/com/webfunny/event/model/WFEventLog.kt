package com.webfunny.event.model

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Base64
import android.util.DisplayMetrics
import com.webfunny.event.core.WFEventConfig
import com.webfunny.event.core.WFEventSession
import org.json.JSONObject
import java.util.Locale
import java.util.TimeZone

/**
 * 埋点上报数据模型 v2.0
 *
 * 新增 eventType、10 个设备信息字段、weCommonInfo（全局参数）。
 */
class WFEventLog(
    config: WFEventConfig,
    val pointId: String,
    params: Map<String, Any>,
    /** 事件类型，SDK 自动事件设对应值，业务方 track() 默认 "custom" */
    val eventType: String = "custom",
    context: Context? = null
) {
    // ── 项目标识 ────────────────────────────────────────────
    val projectId: String = config.projectId

    // ── 事件类型 ────────────────────────────────────────────
    val weEventType: String = eventType

    // ── 时间 ────────────────────────────────────────────────
    val weHappenTime: Long = System.currentTimeMillis()

    // ── 设备指纹（内置 ID） ──────────────────────────────────
    val weCustomerKey: String = WFEventSession.customerKey
    // ── 设备 ID（神策方案，与 customerKey 不同规则） ──────────
    val weDeviceId: String = WFEventSession.deviceKey
    // ── 会话 ID（冷启动/热启动时生成） ──────────────────────
    val weSessionId: String = WFEventSession.sessionId

    // ── 用户信息（base64 编码） ──────────────────────────────
    val weUserId: String    = b64(WFEventSession.userId)
    val weNickname: String  = b64(WFEventSession.nickname)
    val weUserType: String  = b64(WFEventSession.userType)
    val weUserLabel: String = b64(WFEventSession.userTag)
    val weRemark: String    = b64(WFEventSession.userDes)

    // ── 页面路径 ─────────────────────────────────────────────
    val wePath: String = b64(WFEventSession.currentPage)

    // ── 设备信息 ─────────────────────────────────────────────
    val weDeviceName: String  = Build.MODEL
    val wePlatform: String    = "android"
    val weOs: String          = "android"
    val weSystem: String      = "android ${Build.VERSION.RELEASE}"
    val weBrowserName: String = ""
    val weBrowserInfo: String = b64("Android/${Build.VERSION.RELEASE} ${Build.MANUFACTURER}/${Build.MODEL}")

    // ── 新增设备信息（v2.0） ─────────────────────────────────
    val weScreenWidth: Int     = screenWidth(context)
    val weScreenHeight: Int    = screenHeight(context)
    val weDensity: Int         = density(context)
    val weNetworkType: String  = networkType(context)
    val weCarrier: String      = carrierName(context)
    val weManufacturer: String = Build.MANUFACTURER?.takeIf { it.isNotEmpty() } ?: "Simulator"
    val weDeviceBrand: String = Build.BRAND?.takeIf { it.isNotEmpty() } ?: "Simulator"
    val weAppVersion: String   = appVersion(context, config)
    val weSdkVersion: String   = SDK_VERSION
    val weLanguage: String     = Locale.getDefault().language
    val weTimezone: String     = TimeZone.getDefault().id

    // ── 全局参数（v2.0） ─────────────────────────────────────
    val weCommonInfo: String = WFEventSession.commonInfo

    // ── 用户状态 ─────────────────────────────────────────────
    /** 1=新用户（今日首次安装），2=老用户 */
    val weNewStatus: Int = WFEventSession.newStatus

    // ── 业务自定义字段（所有字符串值做 base64） ──────────────
    val extraParams: Map<String, Any> = params.mapValues { (_, v) ->
        if (v is String) b64(v) else v
    }

    /**
     * 转换为 Map，用于 JSON 序列化后上报
     */
    fun toMap(): Map<String, Any> = buildMap {
        put("projectId",        projectId)
        put("pointId",          pointId)
        put("eventType",        weEventType)
        put("weHappenTime",     weHappenTime)
        put("weCustomerKey",    weCustomerKey)
        put("weDeviceId",       weDeviceId)
        put("weSessionId",      weSessionId)
        put("weUserId",         weUserId)
        put("weNickname",       weNickname)
        put("weUserType",       weUserType)
        put("weUserLabel",      weUserLabel)
        put("weRemark",         weRemark)
        put("wePath",           wePath)
        put("weDeviceName",     weDeviceName)
        put("wePlatform",       wePlatform)
        put("weOs",             weOs)
        put("weSystem",         weSystem)
        put("weBrowserName",    weBrowserName)
        put("weBrowserInfo",    weBrowserInfo)
        // v2.0 新增
        put("weScreenWidth",    weScreenWidth)
        put("weScreenHeight",   weScreenHeight)
        put("weDensity",        weDensity)
        put("weNetworkType",    weNetworkType)
        put("weCarrier",        weCarrier)
        put("weManufacturer",   weManufacturer)
        put("weDeviceBrand",    weDeviceBrand)
        put("weAppVersion",     weAppVersion)
        put("weSdkVersion",     weSdkVersion)
        put("weLanguage",       weLanguage)
        put("weTimezone",       weTimezone)
        put("weCommonInfo",     weCommonInfo)
        put("weNewStatus",      weNewStatus)
        putAll(extraParams)
    }

    companion object {
        const val SDK_VERSION = "2.0.0"

        /** Base64 编码 */
        fun b64(str: String): String = try {
            Base64.encodeToString(str.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        } catch (e: Exception) {
            str
        }

        // ── 设备信息获取 ──────────────────────────────────────

        private fun screenWidth(ctx: Context?): Int {
            if (ctx == null) return 0
            return try {
                ctx.resources.displayMetrics.widthPixels
            } catch (e: Exception) { 0 }
        }

        private fun screenHeight(ctx: Context?): Int {
            if (ctx == null) return 0
            return try {
                ctx.resources.displayMetrics.heightPixels
            } catch (e: Exception) { 0 }
        }

        private fun density(ctx: Context?): Int {
            if (ctx == null) return 0
            return try {
                ctx.resources.displayMetrics.densityDpi
            } catch (e: Exception) { 0 }
        }

        private fun networkType(ctx: Context?): String {
            if (ctx == null) return "unknown"
            return try {
                val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return "unknown"
                val nc = cm.activeNetwork ?: return "unknown"
                val caps = cm.getNetworkCapabilities(nc) ?: return "unknown"
                when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                    else -> "unknown"
                }
            } catch (e: Exception) { "unknown" }
        }

        private fun carrierName(ctx: Context?): String {
            if (ctx == null) return ""
            return try {
                val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return ""
                tm.networkOperatorName ?: ""
            } catch (e: Exception) { "" }
        }

        private fun appVersion(ctx: Context?, config: WFEventConfig): String {
            // 优先使用 config 中显式配置的版本
            if (config.projectVersion.isNotBlank() && config.projectVersion != "1.0.0") {
                return config.projectVersion
            }
            // 否则从 PackageManager 自动读取
            if (ctx == null) return config.projectVersion
            return try {
                val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
                pi.versionName ?: config.projectVersion
            } catch (e: PackageManager.NameNotFoundException) {
                config.projectVersion
            }
        }
    }
}
