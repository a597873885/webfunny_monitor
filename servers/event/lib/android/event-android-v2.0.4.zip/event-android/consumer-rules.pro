# Webfunny Event SDK ProGuard consumer rules
# Keep all public SDK classes
-keep public class com.webfunny.event.WFEvent { *; }
-keep public class com.webfunny.event.core.WFEventConfig { *; }
-keep public class com.webfunny.event.core.WFEventSession { *; }
