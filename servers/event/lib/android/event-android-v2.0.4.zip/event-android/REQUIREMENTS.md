# Webfunny Event Android SDK 核心能力增强需求文档

> 版本：v1.0-draft  
> 状态：待评审  
> 基于客户反馈的 7 项核心问题，逐项给出需求定义与预期方案

---

## 1. 问题总览

| 编号 | 问题描述 | 严重程度 | 影响面 |
|:--:|------|:--:|------|
| 2 | 全埋点能力不完整（click/mouseStop 未实现） | 🔴 高 | 功能缺失 |
| 3 | 心跳间隔上报导致短时使用/退出时数据丢失 | 🔴 高 | 数据可靠性 |
| 4 | 上报失败无重试机制 + 失败落盘覆盖写 | 🔴 高 | 数据可靠性 |
| 5 | 数据上报无压缩 | 🟡 中 | 带宽/延迟 |
| 6 | 全局参数薄弱，设备信息少，不支持自定义扩展 | 🟡 中 | 数据分析深度 |
| 7 | 无自动采集能力，事件无类型区分 | 🔴 高 | 功能缺失 |
| 8 | 设备 ID 仅用 UUID + SharedPreferences，清数据即变更 | 🔴 高 | 统计准确性 |

---

## 2. 需求详述

### 2.1 全埋点能力补全

**设计决策**：H5 和 App 的全埋点点位**彻底分离**，不再强行兼容。H5 的 `mouseStop`（鼠标停留）在移动端无对应语义，App 的 `appStart`/`appEnd`（应用启动/退出）在 H5 中不存在。各自定义独立的点位体系。

#### 2.1.1 现状

当前 `WFInitPoints` 是 H5 视角的 4 个点位：

| 点位 | 来源 | 实际实现 |
|------|------|:--:|
| `heatBeat` | H5 心跳 | ✅ 已实现 |
| `browsing` | H5 浏览记录 | ✅ 已实现 |
| `click` | H5 点击采集 | ❌ 仅声明，未实现 |
| `mouseStop` | H5 鼠标停留 | ❌ 仅声明，移动端无意义 |

#### 2.1.2 App 端全埋点点位设计（6个）

对标 Firebase / 神策 / GrowingIO / 友盟+ 等业内主流方案，App 端定义独立的 6 个全埋点点位，统一加 `app` 前缀：

| 点位 | 说明 | 对标参考 | 采集时机 | 触发方式 |
|------|------|------|------|:--:|
| `appStart` | App 启动 | Firebase `session_start` / 神策 `$AppStart` | 冷启动（首次 Activity.onResume）或热启动（从后台回前台） | SDK 自动 |
| `appEnd` | App 进入后台 | 神策 `$AppEnd` / 友盟 AppEnd | 最后一个 Activity.onPause，App 进入后台 | SDK 自动 |
| `appPageEnter` | 页面进入 | 神策 `$AppViewScreen` / GrowingIO `page` | Activity.onResume | SDK 自动 |
| `appPageLeave` | 页面离开 | 神策 `$AppPageClose` | Activity.onPause，携带停留时长 | SDK 自动 |
| `appClick` | 控件点击 | 神策 `$AppClick` / GrowingIO `clck` | 用户点击控件 | SDK 自动 |
| `appHeartBeat` | 心跳/持续活跃 | Firebase `user_engagement` | 前台期间按固定间隔（15s/30s/60s）重复上报 | SDK 自动 |

#### 2.1.3 配置结构重构

**废弃**现有的 `WFInitPoints`（H5 兼容命名），替换为 App 原生配置类：

```kotlin
// 旧（H5 兼容，废弃）
data class WFInitPoints(
    val heatBeat: Int  = 0,
    val mouseStop: Int = 0,   // 移动端无意义
    val click: Int     = 0,
    val browsing: Int  = 0
)

// 新（App 原生）
data class WFAppPoints(
    val appStart: Int     = 0,   // App 启动
    val appEnd: Int       = 0,   // App 进入后台
    val appPageEnter: Int = 0,   // 页面进入
    val appPageLeave: Int = 0,   // 页面离开
    val appClick: Int     = 0,   // 控件点击
    val appHeartBeat: Int = 0    // 心跳
)
```

#### 2.1.4 各点位携带的默认参数

| 点位 | 自动携带字段 |
|------|------|
| `appStart` | `startType`（cold/hot）、`startDuration`（冷启动耗时 ms） |
| `appEnd` | `sessionDuration`（本次会话总时长 ms） |
| `appPageEnter` | `pageTitle`（页面名称）、`referPage`（来源页面） |
| `appPageLeave` | `pageTitle`、`stayDuration`（停留时长 ms） |
| `appClick` | `viewId`、`viewText`、`viewType`（控件类型）、`pageTitle`（所在页面） |
| `appHeartBeat` | `pageTitle`、`stayDuration`（本次停留累计秒数） |

#### 2.1.5 开关控制

全埋点不再通过"点位 ID = 0 表示关闭"来控制，而是新增独立的开关字段，语义更清晰：

```kotlin
WFAppConfig(
    // ... 其他配置 ...
    autoTrack = WFAutoTrack(
        appStart     = true,
        appEnd       = true,
        appPageEnter = true,
        appPageLeave = true,
        appClick     = true,
        appHeartBeat = true
    )
)
```

#### 2.1.7 appClick 最小代价采集方案

**方案**：`AccessibilityDelegate` 挂载到 DecorView，代码量 < 50 行，零运行时开销。

```
每个 Activity.onResume 时：
  activity.window.decorView.setAccessibilityDelegate(object : View.AccessibilityDelegate() {
      override fun onRequestSendAccessibilityEvent(child: View, event: AccessibilityEvent) {
          if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
              // child = 被点击的 View
              appClickTrack(
                  viewClass = child.javaClass.simpleName,    // Button / TextView / ...
                  viewId    = child.resourceIdName(),         // btn_pay / tv_title / ...
                  viewText  = child.accessibilityText(),      // getText() / contentDescription
                  pageTitle = activity.javaClass.simpleName
              )
          }
          super.onRequestSendAccessibilityEvent(child, event)  // 透传，不影响 App 原有逻辑
      }
  })
```

**Why 最小代价**：

- 每个 Activity 只挂 **1 个 Delegate**，不遍历 ViewTree
- 只有点击时才触发回调，无定时器、无轮询
- `super.onRequestSendAccessibilityEvent(...)` 透传，兼容 App 已有的无障碍逻辑

**能力边界**：

| ✅ 能拿到 | ❌ 拿不到 |
|------|------|
| `viewClass` — 控件类名 | 该控件"业务含义"（"购买" vs "收藏"） |
| `viewId` — resource-id 名称 | WebView 内部点击 |
| `viewText` — Button/TextView 文本或 contentDescription | 坐标 |
| `pageTitle` — 所在 Activity | 动态代码创建的 View 的 id |
| 点击时间戳 | — |

**去重处理**：同一控件连续点击在 300ms 内仅上报一次。

#### 2.1.8 兼容性

不保留向后兼容，`WFInitPoints` 直接替换为 `WFAppPoints`，老客户升级时同步修改配置即可。

**待讨论**：
- `appClick` 是否需要支持黑名单（指定某些 Activity / View id 不采集）？

---

### 2.2 数据丢失防护

**设计决策**：持久化采用 **文件 + 简单 JSON 追加**，不引入 SQLite（减少依赖和代码量）。

#### 2.2.1 现状

数据仅驻留在内存队列中，定时器（8s）或满 20 条才触发上报。`flush()` 方法先清空队列再网络上报，上报过程中 App 被 kill 则数据永久丢失。

#### 2.2.2 持久化方案

**核心流程**：

```
track() → 内存队列 → flush()触发
                        │
                        ├─ 1. 先写文件（批次 JSON，追加不覆盖）
                        ├─ 2. 再清空内存队列
                        ├─ 3. 最后网络上报
                        └─ 4. 上报成功 → 删除对应文件
                           上报失败 → 保留文件，由重试机制（2.3）处理
```

**文件组织**：一个批次一个 JSON 文件，命名 `wf_event_batch_{retry}_{timestamp}_{uuid}.json`，避免覆盖并追踪重试次数。

```
/data/data/{包名}/cache/wf_event/
├── wf_event_batch_0_1719600000_a1b2.json   ← 0 次重试，3 条事件待上报
├── wf_event_batch_1_1719600500_c3d4.json   ← 1 次重试，20 条事件待上报
└── wf_event_batch_2_1719601000_e5f6.json   ← 2 次重试，15 条事件待上报
```

- `{retry}` = 已重试次数，首次写入时为 0
- 每次重试前 `rename()` 将次数 +1，原子操作，无需额外状态文件
- 3 次后直接 `delete()`（详见 2.3）

**Why 文件而非 SQLite**：
- 数据量小（< 5MB），不需要复杂查询
- 批次文件上报成功后直接 `delete()`，无"部分删除"需求
- 零依赖，代码量少

#### 2.2.3 磁盘保护

防止离线/故障场景下文件无限增长：

| 策略 | 触发时机 | 阈值 | 行为 |
|------|------|------|------|
| **磁盘上限** | **每次写文件后** + App 初始化时 | 总大小 > **5 MB** | FIFO 淘汰最旧的文件，直至低于 5 MB |
| **过期清理** | App 初始化时 | 文件创建 > **7 天** | 自动删除（认为服务端已无法消费这批数据） |

> **Why 每次写文件后也检查**：极端离线场景下，单次会话可能持续写入大量批次文件，仅在启动时检查不足以防止运行时超限。每次 `saveToDisk()` 后追加一次 `enforceDiskLimit()` 检查，开销极小（只做 `listFiles() + sum(length)`）。

这些阈值硬编码，不对外暴露配置。

#### 2.2.4 生命周期兜底

退出/崩溃场景下确保数据不丢失：

| 触发时机 | 动作 |
|------|------|
| `onActivityPaused` | 触发 flush（已有） |
| `onTrimMemory(TRIM_MEMORY_UI_HIDDEN)` | 触发 flush（App 进入后台） |
| `ComponentCallbacks2.onLowMemory` | 触发 flush（低内存警告） |
| `track()` 每次调用 | 可选：超过一定时长（如 30s）未 flush，自动触发 |

#### 2.2.5 期望行为

- 任何时刻 App 退出/kill，已 `track()` 但未上报的数据不会丢失
- 下次启动时自动扫描并恢复上报（调用 2.3 重试机制）
- 极端离线用户本地占用 ≤ 5 MB

---

### 2.3 上报重试与落盘优化

**现状**：
- 上报失败后仅写入 `wf_event_retry.json` 落盘，**当前会话内不做重试**，只能等下次 App 初始化时由 `retryPendingLogs()` 恢复
- 落盘使用单文件 `writeText()` **全覆盖写**，多次失败 = 逐批覆盖，最终只剩最后一批
- `retryPendingLogs()` 失败又回调 `saveToDisk()`，形成覆盖死循环

**需求描述**：

#### 2.3.1 落盘：文件追加（已在 2.2 中解决）

2.2 节已确定一批次一文件方案（`wf_event_batch_{ts}_{uuid}.json`），天然消除覆盖问题。本节聚焦重试机制。

#### 2.3.2 会话内自动重试

上报失败后不等待下次启动，在当前会话内按以下策略自动重试：

| 重试次数 | 间隔 | 说明 |
|:--:|------|------|
| 第 1 次 | 4s | 立即重试，覆盖瞬时网络抖动 |
| 第 2 次 | 16s | 二次退避 |
| 第 3 次 | 32s | 最后一次 |

- 最大重试 **3 次**，总计约 52 秒（不到 1 分钟）
- 3 次均失败 → 删除该批次文件，**不再保留**（2.2 已保障批次入库时有冗余）
- 重试次数记录方式：文件名含 `{retry}` 计数（见 2.2.2），每次重试前 `rename()` 将次数 +1
- 重试期间新产生的 `track()` 事件正常进入内存队列，不受影响
- 重试仅针对落盘失败的批次，正常流程（flush → 上传）不经过重试通道

#### 2.3.3 启动恢复

App 初始化时扫描缓存目录，残留文件 = 上次未上报成功的批次，走相同重试流程：

```
init() → 扫描 /wf_event/ 目录
          ├─ 文件 A（创建 2 分钟前）→ 重试，间隔 4s
          ├─ 文件 B（创建 1 小时前）→ 重试，间隔 32s（已超过最大次数，直接最后一次尝试）
          └─ 文件 C（创建 8 天前）→ 过期清理删除，不重试
```

**期望行为**：
- 网络抖动（如切换 WiFi/4G）2 分钟内自愈
- 长期离线用户的重试不阻塞新事件上报
- 启动恢复 + 会话内重试覆盖全部补报场景

**待讨论**：
- 重试间隔和最大次数是否需要可配置？（当前硬编码，后续可扩展）

---

### 2.4 数据压缩

**设计决策**：使用 **gzip** 压缩，业内绝对主流标准（Firebase / 神策 / Amplitude 全部采用）。

#### 2.4.1 现状

上报的 JSON 数组以原始 UTF-8 字节发送，无任何压缩。批量 20 条约 30KB，在网络条件差时延迟显著。

#### 2.4.2 方案

**客户端（Android）**：

```
当前:  JSON.stringify(jsonArray) → toByteArray(UTF-8) → POST body
改造:  JSON.stringify(jsonArray) → toByteArray(UTF-8) → GZIPOutputStream → POST body
                                                         + header: Content-Encoding: gzip
```

- 使用 `java.util.zip.GZIPOutputStream`，Java 标准库，零额外依赖
- 仅在 `body > 1 KB` 时压缩，小数据量跳过（避免压了更小的开销）
- **数据结构完全不变**：只在外层包一层 gzip，JSON 字段、格式、编码保持原样

**服务端（Node.js）**：

Node.js 内置 `zlib` 模块，无需额外依赖：

```js
const zlib = require('zlib');
// Express 中间件
app.post('/wfEvent/upEvents', (req, res) => {
    const buffer = req.headers['content-encoding'] === 'gzip'
        ? zlib.gunzipSync(req.body)
        : req.body;
    const json = JSON.parse(buffer.toString());  // 与现在完全一样的结构
});
```

或更省事：`app.use(compression())` 一行搞定。

#### 2.4.3 压缩效果

| 数据量 | 原始大小 | gzip 后 | 压缩率 |
|------|------|------|:--:|
| 单条事件 | ~1.5 KB | ~0.5 KB | 67% |
| 20 条（一批） | ~30 KB | ~5 KB | 83% |
| 100 条（离线补报） | ~150 KB | ~20 KB | 87% |

#### 2.4.4 为什么选 gzip 而非 Brotli

| 维度 | gzip | Brotli |
|------|:--:|:--:|
| 压缩率 | 70~85% | 80~90%（略高） |
| Android 支持 | `java.util.zip` 标准库 | 需额外引入 `org.brotli:dec` |
| Node.js 支持 | `zlib` 内置 | `zlib` 内置（Node 11.7+） |
| 生态成熟度 | 1996 年至今，HTTP 标准 | 相对较新 |

**结论**：gzip 零成本接入，压缩率已经足够，Brotli 的边际收益不值得引入额外依赖。

---

### 2.5 全局参数增强

#### 2.5.1 现状

设备信息仅 6 个字段（`weDeviceName`、`wePlatform`、`weOs`、`weSystem`、`weBrowserName` 为空、`weBrowserInfo`），不支持客户自定义全局参数。

#### 2.5.2 补齐基础设备信息（10 个新字段）

对标 Firebase / 神策 / GrowingIO，全部字段均可零权限获取：

| 新字段 | 说明 | 数据来源 | 对标 |
|------|------|------|:--:|
| `weScreenWidth` / `weScreenHeight` | 屏幕分辨率（px） | `Resources.displayMetrics` | Firebase / 神策 / GrowingIO |
| `weDensity` | 屏幕密度（dpi） | `DisplayMetrics.densityDpi` | Firebase / 神策 / GrowingIO |
| `weNetworkType` | 网络类型 | `ConnectivityManager`（WiFi / 4G / 5G / unknown） | Firebase / 神策 / GrowingIO |
| `weCarrier` | 运营商 | `TelephonyManager.getNetworkOperatorName()`（移动/联通/电信） | Firebase / 神策 |
| `weManufacturer` | 设备厂商 | `Build.MANUFACTURER`（Xiaomi/Samsung/HUAWEI） | Firebase / 神策 / GrowingIO |
| `weBrand` | 设备品牌 | `Build.BRAND` | Firebase / 神策 / GrowingIO |
| `weAppVersion` | 应用版本号 | `PackageManager.getPackageInfo().versionName` | Firebase / 神策 / GrowingIO |
| `weSdkVersion` | SDK 版本号 | 硬编码常量 | Firebase / 神策 / GrowingIO |
| `weLanguage` | 系统语言 | `Locale.getDefault().language`（zh/en/ja...） | Firebase / 神策 |
| `weTimezone` | 时区 | `TimeZone.getDefault().id`（Asia/Shanghai...） | Firebase |

> `weNetworkType` 需 `ACCESS_NETWORK_STATE` 权限（App 基本都有，SDK 以 try-catch 兜底返回 `"unknown"`）。其余字段零权限、零风险。

#### 2.5.3 支持自定义全局参数

在 `WFEventConfig` 中新增 `globalParams: Map<String, Any>` 字段，客户以结构化 Map 传入。

```kotlin
WFEvent.initEvent(this, WFEventConfig(
    // ... 现有配置 ...
    globalParams = mapOf(
        "channel"    to "huawei_store",
        "customKey1" to "customValue1"
    )
))
```

**处理方式**：
- 客户侧：以 `Map<String, Any>` 结构化传入，方便编辑
- SDK 内部：`JSONObject(globalParams).toString()` 序列化为完整 JSON 字符串，以 `weCommonInfo` 字段附带到每条事件中
- 服务端：收到后 `JSON.parse()` 按需解析
- 值同样走 base64 编码

**上报数据结构**（`weCommonInfo` 与 `projectId`、`pointId` 等顶层字段平级）：

```json
{
  "projectId": "event_20250312_xxx",
  "pointId": "747",
  "weHappenTime": 1719600000000,
  "weCustomerKey": "abc-123-def",
  "weCommonInfo": "{\"channel\":\"huawei_store\",\"customKey1\":\"customValue1\"}",
  "weUserId": "xxx",
  "weDeviceName": "Mi 11",
  ...
}
```

**待讨论**：
- 全局参数是否需要支持初始化后动态修改？

---

### 2.6 事件体系完善

**设计决策**：与 2.1 全埋点点位体系对齐，事件类型统一使用 `app` 前缀命名。

#### 2.6.1 现状

- 无页面进入/离开自动事件
- 事件无类型字段，所有事件同质化，后端无法区分启动/页面/点击/心跳
- 无启动事件、无 App 进后台事件

#### 2.6.2 新增 eventType 字段

在 `WFEventLog` 数据模型中新增 `eventType` 字段，与 2.1 的 6 个全埋点点位一一对应：

| eventType | 对应点位 | 说明 | 触发方式 |
|------|------|------|:--:|
| `appStart` | `appStart` | App 冷启动/热启动 | SDK 自动 |
| `appEnd` | `appEnd` | App 进入后台 | SDK 自动 |
| `appPageEnter` | `appPageEnter` | 页面进入 | SDK 自动 |
| `appPageLeave` | `appPageLeave` | 页面离开 | SDK 自动 |
| `appClick` | `appClick` | 控件点击 | SDK 自动 |
| `appHeartBeat` | `appHeartBeat` | 心跳/持续活跃 | SDK 自动 |
| `custom` | 业务方指定的 pointId | 业务自定义事件 | 业务方手动 `track()` |

- SDK 自动事件：由全埋点采集器在触发时自动设置对应的 `eventType`
- 业务方 `track()`：`eventType` 默认 `"custom"`，也可由业务方在 `params` 中覆盖
- `eventType` 与 `pointId` 同时上报，后端可双重维度筛选

#### 2.6.3 各事件详情

已在 2.1.4 中定义各点位携带的默认参数，此处仅补充额外说明：

| eventType | 补充说明 |
|------|------|
| `appStart` | 冷启动耗时从 `Application.onCreate` 到首个 Activity 显示；热启动仅标记 `startType=hot` |
| `appEnd` | 通过 Activity 计数判断：最后一个 Activity.onPause 且无新 Activity.onResume 时触发 |
| `appPageEnter` | 携带 `referPage`（上一个页面名称），首次进入时 `referPage` 为空 |
| `appPageLeave` | 同一页面 `appPageEnter → appPageLeave` 之间计算 `stayDuration` |
| `appClick` | 通过 AccessibilityDelegate 实现（详见 2.1.7），300ms 去重 |
| `appHeartBeat` | 替代旧 `heatBeat`，心跳间隔和上限由 `WFHeartBeatSetting` 控制 |

#### 2.6.4 期望行为

- 自动事件与手动 `track()` 走同一上报通道，仅在 `eventType` 字段上区分
- 自动事件通过 `WFAutoTrack` 开关独立控制启用/禁用
- 后端可按 `eventType` 直接分类统计（如"今日启动次数"），不依赖每个客户配置的具体 pointId 数值

**待讨论**：
- 业务方 `track()` 时是否允许覆盖 `eventType`（如改为自定义类型名称）？
- 页面事件的 `pageTitle` 用 Activity 类名还是支持业务方自定义页面名称？

---

### 2.7 设备 ID 稳定性
### 2.7 设备 ID 稳定性

**设计决策**：采用神策方案 — `ANDROID_ID` 优先 + 硬件特征 Hash 兜底 + UUID 最终兜底。

#### 2.7.1 现状

`customerKey` = `UUID.randomUUID()` 存储在 `SharedPreferences`，清数据/重装即变更，导致用户数统计失真。

#### 2.7.2 业内对比

| SDK | 方案 | 稳定性 |
|------|------|:--:|
| Firebase | Firebase Installation ID（依赖 Google Play 服务） | 🔒 很稳 |
| **神策** | **`ANDROID_ID` → 硬件 Hash → UUID** | 🔒 稳 |
| GrowingIO | `ANDROID_ID` + MAC（旧版，Android 10+ 已不可用）→ UUID | 🟡 |
| 友盟+ | 多维硬件特征组合 Hash | 🔒 稳 |

> Android 10+ 隐私限制：IMEI 需 `READ_PHONE_STATE` 权限（非系统 App 拿不到），MAC 地址已固定返回 `02:00:00:00:00:00`，Google 广告 ID 用户可随时重置。`ANDROID_ID` 是唯一零权限且重装不变的稳定标识。

#### 2.7.3 分层兜底策略

```
优先级 1: Settings.Secure.ANDROID_ID
    ├─ Android 8+ 同签名下重装不变
    ├─ 过滤无效值：null / "9774d56d682e549c" 等已知无效常量
    └─ 获取失败或无效
          ↓
优先级 2: 硬件特征 Hash
    ├─ SHA-256(MANUFACTURER + MODEL + HARDWARE + BOARD + PRODUCT + 首次安装时间戳)
    ├─ 取前 16 位，极小碰撞概率
    └─ 同型号设备有理论碰撞可能（作为兜底可接受）
          ↓
优先级 3: UUID
    └─ 生成后持久化到 SharedPreferences，无法获取稳定 ID 时的最终方案
```

#### 2.7.4 期望行为

- 普通用户清数据/重装 → ID 不变（`ANDROID_ID` 覆盖 99%+ 场景）
- 恢复出厂设置 → ID 变更（符合预期）
- 不同 App 之间 ID 不同（Android 8+ `ANDROID_ID` 按签名隔离，隐私合规）

**待讨论**：
- 是否需要支持客户传入外部业务 ID 作为 `customerKey` 的补充？
- 是否需要 OAID（国内 Android 设备广告 ID）作为额外来源？

---

## 3. 优先级建议

| 优先级 | 需求编号 | 理由 |
|:--:|:--:|------|
| P0 | 4 - 重试与落盘 | 直接影响数据可靠性，且改造相对独立 |
| P0 | 3 - 数据丢失防护 | 同上，与 P0-4 可以一起做 |
| P1 | 8 - 设备 ID 稳定 | 影响全量统计数据准确性 |
| P1 | 7 - 事件体系 | 建立事件类型体系，是后续全埋点的基础 |
| P2 | 2 - 全埋点能力 | 依赖事件体系，在 P1-7 之后做 |
| P2 | 6 - 全局参数 | 相对独立，可与 P2-2 并行 |
| P3 | 5 - 数据压缩 | 依赖服务端配合，优先级可放最后 |

---

## 4. 待讨论确认事项

在进入开发计划前，需要你与客户/产品侧确认以下问题：

1. **点击全埋点的数据粒度**：上报 View 的 text/id/坐标中的哪些？是否需要黑名单机制？
2. **服务端 gzip 支持**：数据压缩需要服务端配合解压，服务端是否已支持？
3. **全局参数动态修改**：是否需要 `setGlobalParam(key, value)` 运行时动态修改？
4. **页面名称自定义**：自动页面事件用 Activity 类名还是需要业务方通过 API 设置自定义名称？
5. **设备 ID 额外来源**：是否需要接入 OAID？是否需要支持客户设置外部业务 ID？
