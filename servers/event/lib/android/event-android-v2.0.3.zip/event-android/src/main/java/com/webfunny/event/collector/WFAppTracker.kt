package com.webfunny.event.collector

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.webfunny.event.core.WFEventConfig
import com.webfunny.event.core.WFEventSession
import com.webfunny.event.core.WFEventUploader
import com.webfunny.event.model.WFEventLog

/**
 * App 全埋点采集器 v2.0
 *
 * 负责 5 个 SDK 自动事件：appStart / appEnd / appPageEnter / appPageLeave / appHeartBeat
 * （appClick 由 [WFAppClickCollector] 独立处理）
 */
class WFAppTracker(
    private val app: Application,
    private val config: WFEventConfig
) {
    private val TAG = "WFAppTracker"
    private val handler = Handler(Looper.getMainLooper())
    private var staySeconds = 0
    private var isRunning = false
    private var beatReportCount = 0
    private var activityCount = 0
    private var sessionStartMs = 0L
    private var previousPage: String = ""
    private var currentPageEnterMs = 0L
    private var isFirstResume = true

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            staySeconds++
            if (staySeconds * 1000L >= config.setting.heartBeat.gapMs) {
                onHeartBeat()
                staySeconds = 0
            }
            handler.postDelayed(this, 1_000L)
        }
    }

    fun install() {
        sessionStartMs = System.currentTimeMillis()
        app.registerActivityLifecycleCallbacks(lifecycleCallbacks)
        // 生命周期兜底
        app.registerComponentCallbacks(object : android.content.ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level == android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
                if (config.setting.debugLog) Log.d(TAG, "onTrimMemory UI_HIDDEN，触发 flush")
                    WFEventUploader.flushNow()
                }
            }
            override fun onLowMemory() {
            if (config.setting.debugLog) Log.d(TAG, "onLowMemory，触发 flush")
                WFEventUploader.flushNow()
            }
            override fun onConfigurationChanged(config: android.content.res.Configuration) {}
        })
    }

    // ─── 心跳 ────────────────────────────────────────────────

    private fun start() {
        if (isRunning) return
        isRunning = true
        handler.postDelayed(tickRunnable, 1_000L)
    }

    private fun stop() {
        isRunning = false
        handler.removeCallbacks(tickRunnable)
        staySeconds = 0
        beatReportCount = 0
    }

    private fun onHeartBeat() {
        if (!config.autoTrack.appHeartBeat) return
        val pointId = config.appPoints.appHeartBeat
        if (pointId == 0) return

        val limit = config.setting.heartBeat.limit
        if (limit > 0 && beatReportCount >= limit) {
                if (config.setting.debugLog) Log.d(TAG, "心跳已达上限 $limit 次，停止")
            return
        }
        beatReportCount++

        enqueueAutoEvent(
            pointId = pointId.toString(),
            eventType = "appHeartBeat",
            params = mapOf(
                "appPageTitle" to WFEventSession.currentPage,
                "appStayDuration" to staySeconds
            )
        )
    }

    // ─── 自动事件上报 ────────────────────────────────────────

    private fun enqueueAutoEvent(pointId: String, eventType: String, params: Map<String, Any>) {
        try {
            val log = WFEventLog(config, pointId, params, eventType, app)
            WFEventUploader.enqueue(log.toMap())
        } catch (e: Exception) {
            Log.e(TAG, "$eventType 事件构建失败: ${e.message}")
        }
    }

    // ─── Activity 生命周期 ────────────────────────────────────

    private val lifecycleCallbacks = object : Application.ActivityLifecycleCallbacks {

        override fun onActivityResumed(activity: Activity) {
            val pageTitle = activity.javaClass.simpleName

            // appStart: 首次 onResume（冷启动）或从后台回前台（热启动）
            if (activityCount == 0 && config.autoTrack.appStart) {
                val startPointId = config.appPoints.appStart
                if (startPointId != 0) {
                    val startType = if (isFirstResume) "cold" else "hot"
                    val startDuration = if (isFirstResume) System.currentTimeMillis() - sessionStartMs else 0L
                    enqueueAutoEvent(
                        pointId = startPointId.toString(),
                        eventType = "appStart",
                        params = mapOf(
                            "startType" to startType,
                            "startDuration" to startDuration
                        )
                    )
                    if (config.setting.debugLog) {
                        Log.d(TAG, "appStart: type=$startType duration=${startDuration}ms")
                    }
                }
                isFirstResume = false
            }

            // appPageEnter
            if (config.autoTrack.appPageEnter) {
                val enterPointId = config.appPoints.appPageEnter
                if (enterPointId != 0) {
                    enqueueAutoEvent(
                        pointId = enterPointId.toString(),
                        eventType = "appPageEnter",
                        params = mapOf(
                            "appPageTitle" to pageTitle,
                            "appPagePath" to pageTitle,
                            "appReferPage" to previousPage
                        )
                    )
                }
            }

            previousPage = pageTitle
            WFEventSession.currentPage = pageTitle
            currentPageEnterMs = System.currentTimeMillis()
            activityCount++
            start()
        }

        override fun onActivityPaused(activity: Activity) {
            activityCount--
            val pageTitle = activity.javaClass.simpleName

            // appPageLeave
            if (config.autoTrack.appPageLeave) {
                val leavePointId = config.appPoints.appPageLeave
                if (leavePointId != 0) {
                    val stayDuration = System.currentTimeMillis() - currentPageEnterMs
                    enqueueAutoEvent(
                        pointId = leavePointId.toString(),
                        eventType = "appPageLeave",
                        params = mapOf(
                            "appPageTitle" to pageTitle,
                            "appPagePath" to pageTitle,
                            "appStayDuration" to stayDuration
                        )
                    )
                }
            }

            // appEnd: 所有 Activity 暂停
            if (activityCount <= 0 && config.autoTrack.appEnd) {
                val endPointId = config.appPoints.appEnd
                if (endPointId != 0) {
                    val sessionDuration = System.currentTimeMillis() - sessionStartMs
                    enqueueAutoEvent(
                        pointId = endPointId.toString(),
                        eventType = "appEnd",
                        params = mapOf("sessionDuration" to sessionDuration)
                    )
                    sessionStartMs = System.currentTimeMillis() // 重置计时
                }
            }

            if (activityCount <= 0) {
                stop()
                WFEventUploader.flushNow()
            }
        }

        override fun onActivityCreated(a: Activity, b: Bundle?) {}
        override fun onActivityStarted(a: Activity) {}
        override fun onActivityStopped(a: Activity) {}
        override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
        override fun onActivityDestroyed(a: Activity) {}
    }
}
