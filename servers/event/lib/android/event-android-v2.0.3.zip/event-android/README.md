# Webfunny Event Android SDK v2.0

Webfunny 埋点 SDK Android 版，零第三方依赖。

---

## 1. 下载 SDK

下载 [webfunny-event-android-v2.0.zip]()（请联系技术支持获取最新下载地址），将 `webfunny-event-android` 文件夹解压到你的项目根目录下（与 `app/` 同级）。

> 目录结构示意：
> ```
> YourProject/
> ├── app/                       ← 你的 App 模块
> ├── webfunny-event-android/    ← 下载的 SDK 模块
> ├── settings.gradle.kts
> └── build.gradle.kts
> ```

### 添加模块引用

在以下两个文件中添加配置：

```kotlin
// settings.gradle.kts — 在最下方添加
include(":webfunny-event-android")
project(":webfunny-event-android").projectDir = File("webfunny-event-android")
```

```kotlin
// app/build.gradle.kts — 在 dependencies { ... } 中
implementation(project(":webfunny-event-android"))
```

改完后点一下 Android Studio 顶部的 **Sync Now**。

---

## 2. 初始化 SDK

在 `Application.onCreate()` 中初始化：

```kotlin
import android.app.Application
import com.webfunny.event.WFEvent
import com.webfunny.event.core.WFEventConfig
import com.webfunny.event.core.WFAppPoints
import com.webfunny.event.core.WFAutoTrack
import com.webfunny.event.core.WFSetting
import com.webfunny.event.core.WFHeartBeatSetting

class MyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        WFEvent.initEvent(
            this,
            WFEventConfig(
                uploadDomain = "https://your-server.com",
                projectId      = "your-project-id",
                env            = "pro",
                projectVersion = "1.0.0",
                appPoints = WFAppPoints(
                    appStart     = 10,
                    appEnd       = 11,
                    appPageEnter = 12,
                    appPageLeave = 13,
                    appClick     = 14,
                    appHeartBeat = 15
                ),
                autoTrack = WFAutoTrack(
                    appStart     = true,
                    appEnd       = true,
                    appPageEnter = true,
                    appPageLeave = true,
                    appClick     = true,
                    appHeartBeat = true
                ),
                setting = WFSetting(
                    heartBeat = WFHeartBeatSetting(
                        enable = true,
                        gap    = 15,
                        limit  = 20
                    ),
                    debugLog = true,   // 开发阶段开启，上线改为 false
                    gzip     = true    // 是否 gzip 压缩上报，默认 true
                )
            )
        )
    }
}
```

> **projectId / pointId 从哪来？** 登录 Webfunny 控制台 → 事件分析 → 创建项目 → 获取项目 ID 和各点位 ID。

### 验证

运行 App 后，在 Logcat 搜索 `WFEvent`，应能看到初始化日志和全埋点事件。

---

## 3. 设置通用属性（可选，随时可调）

```kotlin
// 设置
WFEvent.setCommonInfo(mapOf(
    "channel"  to "huawei_store",
    "vipLevel" to "gold"
))

// 清空
WFEvent.setCommonInfo(emptyMap())
```

通用属性会持久化到本地，上报时自动附加到 `weCommonInfo` 字段。

---

## 4. 设置用户信息（登录后调用）

```kotlin
WFEvent.setUser(userId = "user_001", nickname = "张三")
```

---

## 5. 上报埋点事件

### 方式一：指定当前环境的点位（推荐）

```kotlin
WFEvent.track(
    pointIds = mapOf("pro" to "747", "dev" to "xxx"),
    params   = mapOf("buttonName" to "立即购买"),
    upNow    = true
)
```

### 方式二：直接传点位 ID

```kotlin
WFEvent.track(
    pointId = "747",
    params  = mapOf("productId" to "12345"),
    upNow   = false
)
```

---

## 6. 手动页面采集

适用于全埋点无法覆盖的场景：Fragment、Tab 切换、Compose 等。

```kotlin
class ProductFragment : Fragment() {

    override fun onResume() {
        super.onResume()
        // 手动上报页面进入
        WFEvent.trackPageView(
            pageTitle = "商品详情页",
            pagePath = "/product/detail"
        )
    }

    override fun onPause() {
        super.onPause()
        // 手动上报页面离开（停留时长自动计算）
        WFEvent.trackPageLeave()
    }
}
```

### trackPageView

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `pageTitle` | String | **必填** | 页面名称 |
| `pagePath` | String | 同 `pageTitle` | 页面路径 |
| `params` | Map<String, Any> | `emptyMap()` | 附加业务参数 |

### trackPageLeave

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `pageTitle` | String | 上次 trackPageView 的值 | 页面名称 |
| `pagePath` | String | 上次 trackPageView 的值 | 页面路径 |
| `stayDuration` | Long | 自动计算 | 停留时长（毫秒），传 `>=0` 的值表示手动指定 |
| `params` | Map<String, Any> | `emptyMap()` | 附加业务参数 |

> 两个方法共用 `appPoints.appPageEnter` / `appPoints.appPageLeave` 点位 ID。

---

## 7. 全埋点（6 点位）

SDK 自动采集以下事件，无需业务方手动埋点：

| 点位 | 说明 | 携带参数 |
|------|------|------|
| `appStart` | App 启动（冷/热） | `startType`(cold/hot)、`startDuration`(ms) |
| `appEnd` | App 进入后台 | `sessionDuration`(ms) |
| `appPageEnter` | 页面进入 | `appPageTitle`、`appPagePath`、`appReferPage` |
| `appPageLeave` | 页面离开 | `appPageTitle`、`appPagePath`、`appStayDuration`(ms) |
| `appClick` | 控件点击 | `viewId`、`viewText`、`viewType`、`pageTitle` |
| `appHeartBeat` | 心跳 | `appPageTitle`、`appStayDuration`(s) |

通过 `WFAutoTrack` 开关独立控制每个点位的启用/禁用。

---

## 8. WFEventConfig 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `uploadDomain` | String | **必填** | 上报服务域名 |
| `projectId` | String | **必填** | 埋点项目 ID |
| `env` | String | `"pro"` | 当前环境：dev / sit / stag / pro |
| `projectVersion` | String | `"1.0.0"` | 应用版本号 |
| `appPoints` | WFAppPoints | 全 0 | App 全埋点点位 ID |
| `autoTrack` | WFAutoTrack | 全 true | 全埋点开关 |
| `setting` | WFSetting | 默认值 | SDK 行为配置（心跳、调试日志、gzip） |

### WFSetting

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `heartBeat` | WFHeartBeatSetting | 见下方 | 心跳子配置 |
| `debugLog` | Boolean | `false` | 是否打印 SDK 调试日志 |
| `gzip` | Boolean | `true` | 是否启用 gzip 压缩上报 |

### WFHeartBeatSetting

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enable` | Boolean | `true` | 心跳开关 |
| `gap` | Int | `15` | 心跳间隔（秒），可选：5 / 15 / 30 / 60 |
| `limit` | Int | `120` | 单次连续最大心跳次数（0=不限制） |

---

## 9. API 参考

| 方法 | 说明 |
|------|------|
| `WFEvent.initEvent(app, config)` | 初始化 SDK |
| `WFEvent.setCommonInfo(params)` | 设置通用属性（持久化） |
| `WFEvent.setUser(userId, nickname, ...)` | 设置当前用户信息 |
| `WFEvent.track(pointId, params, upNow)` | 上报埋点事件 |
| `WFEvent.track(pointIds, params, upNow)` | 按环境选点位上报 |
| `WFEvent.trackPageView(pageTitle, pagePath, params)` | 手动上报页面进入 |
| `WFEvent.trackPageLeave(pageTitle, pagePath, stayDuration, params)` | 手动上报页面离开 |
| `WFEvent.flush()` | 手动刷新上报队列 |

---

## 10. v2.0 更新日志

- **全埋点**：新增 6 个 App 端全埋点点位（appStart/appEnd/appPageEnter/appPageLeave/appClick/appHeartBeat）
- **手动页面采集**：`trackPageView` / `trackPageLeave` 支持 Fragment、Tab 等非 Activity 页面
- **数据可靠性**：持久化（文件+JSON 追加）、自动重试（4s/16s/32s）、gzip 压缩
- **全局参数**：`setCommonInfo()` 动态设置通用属性，持久化，10 个设备信息字段（屏幕/网络/运营商等）
- **设备 ID**：双 ID 设计（customerKey + deviceKey 神策方案），清数据重装大概率不变
- **事件体系**：新增 `eventType` 字段，区分自动/手动事件

---

## 11. 环境要求

- minSdk 21+
- Kotlin 1.9+
