# Webfunny Event HarmonyOS SDK v1.0

Webfunny 埋点 SDK 鸿蒙版，零第三方依赖，基于 ArkTS。

---

## 1. 下载 SDK

下载 [event-harmonyos-v1.0.0.zip]()（请联系技术支持获取最新下载地址），将 `event-harmonyos` 文件夹解压到与你的项目同级目录下。

> 目录结构示意：
> ```
> harmonyos/
> ├── YourProject/                ← 你的项目
> │   ├── entry/                   ← 你的 App 模块
> │   ├── build-profile.json5
> │   └── oh-package.json5
> └── event-harmonyos/            ← 下载的 SDK 模块（与项目同级）
> ```

### 添加模块引用

1. 在项目根目录的 `build-profile.json5` 中添加模块：

```json5
{
  "modules": [
    // ... 你的 entry 模块
    {
      "name": "webfunny_event",
      "srcPath": "../event-harmonyos",
      "targets": [{ "name": "default", "applyToProducts": ["default"] }]
    }
  ]
}
```

> `srcPath` 相对于项目根目录，`../event-harmonyos` 表示 SDK 与项目同级。

2. 在 App 模块（entry）的 `oh-package.json5` 中添加依赖：

```json5
{
  "dependencies": {
    "event-harmonyos": "file:../../event-harmonyos"
  }
}
```

> `file:` 路径相对于 `oh-package.json5` 所在的 entry 目录，`../../event-harmonyos` 表示从 entry 上一层到项目根目录，再上一层到 SDK 所在位置。

3. 点击 DevEco Studio 顶部的 **Sync Now**。

---

## 2. 初始化 SDK

在 `EntryAbility.ets` 的 `onCreate` 中初始化：

```typescript
import { WFEvent, WFEventConfig, WFAppPoints, WFAutoTrack } from 'event-harmonyos';
import { AbilityConstant, UIAbility, Want } from '@kit.AbilityKit';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    // 初始化埋点 SDK（尽早调用）
    WFEvent.getInstance().initEvent(this.context, new WFEventConfig({
      uploadDomain: 'https://your-server.com',    // 服务器域名
      projectId: 'your-project-id',                  // 埋点项目 ID
      env: 'pro',                                    // 环境：dev/sit/stag/pro
      projectVersion: '1.0.0',                       // 应用版本号
      appPoints: new WFAppPoints({
        appStart: 10,
        appEnd: 15,
        appPageEnter: 11,
        appPageLeave: 12,
        appHeartBeat: 14
      }),
      autoTrack: new WFAutoTrack({
        appStart: true,
        appEnd: true,
        appPageEnter: true,
        appPageLeave: true,
        appHeartBeat: true
      })
    }));
  }

  onForeground(): void {
    WFEvent.getInstance().onAppForeground();
  }

  onBackground(): void {
    WFEvent.getInstance().onAppBackground();
  }
}
```

> **projectId / pointId 从哪来？** 登录 Webfunny 控制台 → 事件分析 → 创建项目 → 获取项目 ID 和各点位 ID。

### 验证

运行 App 后，在 Log 中搜索 `WFEvent`，`debugLog: true` 时可见初始化日志和全埋点事件。

### 开启调试日志

初始化时在 `WFEventConfig` 中设置 `setting`：

```typescript
import { WFEventConfig, WFAppPoints, WFAutoTrack, WFSetting, WFHeartBeatSetting } from 'event-harmonyos';

WFEvent.getInstance().initEvent(this.context, new WFEventConfig({
  uploadDomain: 'https://your-server.com',
  projectId: 'your-project-id',
  env: 'pro',
  projectVersion: '1.0.0',
  appPoints: new WFAppPoints({
    appStart: 10,
    appEnd: 15,
    appPageEnter: 11,
    appPageLeave: 12,
    appHeartBeat: 14
  }),
  autoTrack: new WFAutoTrack(),
  setting: new WFSetting({
    heartBeat: new WFHeartBeatSetting({ enable: true, gap: 15, limit: 120 }),
    debugLog: true
  })
}));
```

---

## 3. 设置通用属性（可选，随时可调）

```typescript
import { WFEvent } from 'event-harmonyos';

// 设置
let commonInfo: Record<string, Object> = {
  'channel': 'huawei_store',
  'vipLevel': 'gold'
};
WFEvent.getInstance().setCommonInfo(commonInfo);

// 清空
let emptyInfo: Record<string, Object> = {};
WFEvent.getInstance().setCommonInfo(emptyInfo);
```

> **ArkTS 注意**：`setCommonInfo` 的参数类型为 `Record<string, Object>`，ArkTS 不支持内联对象字面量直接传入，需先用 `let` 声明带类型标注的变量。`setUser` 不受此限制（`WFUserMap` 是显式声明的 interface）。

---

## 4. 设置用户信息（登录后调用）

```typescript
WFEvent.getInstance().setUser({
  userId: 'user_001',
  nickname: '张三',
  userType: 'vip',
  userTag: 'tag_001',
  des: '用户描述'
});
```

---

## 5. 上报埋点事件

### 方式一：指定当前环境的点位（推荐）

```typescript
let pointIds: Record<string, string> = {
  'pro': '747',
  'dev': 'xxx'
};
let params: Record<string, Object> = {
  'buttonName': '立即购买'
};
WFEvent.getInstance().trackByEnv({
  pointIds: pointIds,       // 各环境点位 ID
  params: params,           // 业务参数
  eventType: 'custom',      // 事件类型（可选，默认 custom）
  upNow: true               // 是否立即上报（可选，默认 false）
});
```

### 方式二：直接传点位 ID

```typescript
let trackParams: Record<string, Object> = {
  'productId': '12345'
};
WFEvent.getInstance().track({
  pointId: '747',           // 点位 ID
  params: trackParams,      // 业务参数
  eventType: 'custom',      // 事件类型（可选，默认 custom）
  upNow: false              // 是否立即上报（可选，默认 false）
});
```

### 手动页面采集（trackPageView / trackPageLeave）

适用于全埋点无法覆盖的场景：Tab 切换、自定义组件等。

```typescript
import { WFEvent } from 'event-harmonyos';

// 页面进入（基础用法，无需 let 声明）
WFEvent.getInstance().trackPageView({
  pageTitle: '商品详情页',
  pagePath: '/product/detail'
});

// 页面进入（带附加参数，params 需用 let 声明）
let pageParams: Record<string, Object> = {
  'categoryId': '100'
};
WFEvent.getInstance().trackPageView({
  pageTitle: '商品详情页',
  pagePath: '/product/detail',
  params: pageParams
});

// 页面离开（停留时长自动计算）
WFEvent.getInstance().trackPageLeave();

// 页面离开（手动指定停留时长）
WFEvent.getInstance().trackPageLeave({ stayDuration: 5000 });
```

### trackPageView(map: WFPageViewMap)

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `pageTitle` | string | 是 | 页面名称 |
| `pagePath` | string | 否 | 页面路径，默认同 `pageTitle` |
| `params` | Record<string, Object> | 否 | 附加业务参数 |

### trackPageLeave(map?: WFPageLeaveMap)

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `pageTitle` | string | 否 | 页面名称，默认取上次 trackPageView 的值 |
| `pagePath` | string | 否 | 页面路径，默认取上次 trackPageView 的值 |
| `stayDuration` | number | 否 | 停留时长（毫秒），默认自动计算 |
| `params` | Record<string, Object> | 否 | 附加业务参数 |

> 两个方法共用 `appPoints.appPageEnter` / `appPoints.appPageLeave` 点位 ID。

---

## 6. 全埋点（5 点位）

SDK 自动采集以下事件，无需业务方手动埋点：

| 点位 | 说明 | 携带参数 |
|------|------|------|
| `appStart` | App 启动（冷/热） | `startType`(cold/hot) |
| `appEnd` | App 进入后台 | `sessionDuration`(s) |
| `appPageEnter` | 页面进入 | `appPageTitle`、`appPagePath`、`appReferPage` |
| `appPageLeave` | 页面离开 | `appPageTitle`、`appPagePath`、`appStayDuration`(ms) |
| `appHeartBeat` | 心跳 | `appPageTitle`、`appStayDuration`(s) |

通过 `WFAutoTrack` 开关独立控制每个点位的启用/禁用。

### appPageEnter/appPageLeave 自动采集

SDK 通过 `@ohos.arkui.observer.on('routerPageUpdate')` 全局监听路由变化，自动采集页面进入/离开。
- `pageTitle`：优先取路由配置中的 `name` 字段，降级到路由 path
- `referPage`：自动记录上一个页面
- `stayDuration`：自动计算页面停留时长

---

## 7. WFEventConfig 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `uploadDomain` | string | **必填** | 上报服务域名 |
| `projectId` | string | **必填** | 埋点项目 ID |
| `env` | string | `'pro'` | 当前环境：dev / sit / stag / pro |
| `projectVersion` | string | `'1.0.0'` | 应用版本号 |
| `appPoints` | WFAppPoints | 全 0 | App 点位 ID（含全埋点 + 手动页面采集） |
| `autoTrack` | WFAutoTrack | 全 true | 全埋点开关 |
| `setting` | WFSetting | 默认值 | SDK 行为配置 |

### WFHeartBeatSetting

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enable` | boolean | `true` | 心跳开关 |
| `gap` | number | `15` | 心跳间隔（秒），可选：5 / 15 / 30 / 60 |
| `limit` | number | `120` | 单次连续最大心跳次数（0=不限制） |

### WFSetting

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `heartBeat` | WFHeartBeatSetting | 默认值 | 心跳子配置 |
| `debugLog` | boolean | `false` | 是否打印 SDK 调试日志 |

---

## 8. API 参考

| 方法 | 说明 |
|------|------|
| `WFEvent.getInstance().initEvent(context, config)` | 初始化 SDK |
| `WFEvent.getInstance().onAppForeground(pageInfo?)` | 通知 SDK App 进入前台 |
| `WFEvent.getInstance().onAppBackground()` | 通知 SDK App 进入后台 |
| `WFEvent.getInstance().setCommonInfo(params)` | 设置通用属性（持久化） |
| `WFEvent.getInstance().setUser(map)` | 设置当前用户信息 |
| `WFEvent.getInstance().track(map)` | 上报埋点事件 |
| `WFEvent.getInstance().trackByEnv(map)` | 按环境选点位上报 |
| `WFEvent.getInstance().trackPageView(map)` | 手动上报页面进入 |
| `WFEvent.getInstance().trackPageLeave(map?)` | 手动上报页面离开 |
| `WFEvent.getInstance().flush()` | 手动刷新上报队列 |

---

## 9. v1.0 功能

- **全埋点**：5 个 App 端全埋点点位（appStart/appEnd/appPageEnter/appPageLeave/appHeartBeat），全部 SDK 自动采集
- **手动页面采集**：`trackPageView` / `trackPageLeave` 支持 Tab 切换等非路由页面，停留时长自动计算
- **双 ID**：customerKey（UUID+时间戳）+ deviceKey（硬件 Hash），卸载重装大概率不变
- **数据可靠性**：文件批次持久化、4s/16s/32s 指数退避重试
- **全局参数**：10 个设备信息字段 + `setCommonInfo()` 动态设置通用属性
- **事件体系**：`eventType` 字段区分自动/手动事件
- **页面监听**：通过 `@ohos.arkui.observer` 全局监听路由，无需业务方手动调用

---

## 10. 环境要求

- HarmonyOS API 9+
- Stage 模型
- DevEco Studio 4.0+
