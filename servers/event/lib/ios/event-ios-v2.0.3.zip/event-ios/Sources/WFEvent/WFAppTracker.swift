import Foundation
#if canImport(UIKit)
import UIKit
#endif

/// App 全埋点采集器 v2.0（对标 Android WFAppTracker）
///
/// 采集 3 个 SDK 自动点位：
/// - appStart：App 启动 / 从后台回前台
/// - appEnd：App 进入后台
/// - appHeartBeat：前台心跳
///
/// 不涉及 Method Swizzling，仅使用系统通知。
final class WFAppTracker {

    private let config: WFEventConfig
    private var timer: Timer?
    private var staySeconds: Int = 0
    private var beatReportCount: Int = 0
    private var isRunning: Bool = false
    private var isColdStart: Bool = true

    init(config: WFEventConfig) {
        self.config = config
    }

    // MARK: - 安装

    func install() {
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(appDidBecomeActive),
                       name: UIApplication.didBecomeActiveNotification, object: nil)
        nc.addObserver(self, selector: #selector(appWillResignActive),
                       name: UIApplication.willResignActiveNotification, object: nil)
        nc.addObserver(self, selector: #selector(appDidEnterBackground),
                       name: UIApplication.didEnterBackgroundNotification, object: nil)

        // 冷启动立即发送 appStart
        reportAppStart(startType: "cold")
    }

    // MARK: - 前台 / 后台

    @objc private func appDidBecomeActive() {
        let pageName = currentTopViewControllerName()
        WFEventSession.shared.currentPage = pageName

        if config.setting.debugLog {
            print("[WFAppTracker] 进入前台：\(pageName)")
        }

        // 热启动（从后台回前台）
        if !isColdStart {
            reportAppStart(startType: "hot")
        }
        isColdStart = false

        startHeartBeat()
    }

    @objc private func appWillResignActive() {
        if config.setting.debugLog {
            print("[WFAppTracker] 即将进入后台，已停留 \(staySeconds)s")
        }
        stopHeartBeat()
    }

    @objc private func appDidEnterBackground() {
        reportAppEnd()
        WFEventUploader.shared.flushNow()
    }

    // MARK: - appStart 上报

    private func reportAppStart(startType: String) {
        guard config.autoTrack.appStart else { return }
        let pointId = config.appPoints.appStart
        guard pointId != 0 else { return }

        let log = WFEventLog(
            config: config,
            pointId: String(pointId),
            params: ["startType": startType],
            eventType: "appStart"
        )
        WFEventUploader.shared.enqueue(log.toMap())
        if config.setting.debugLog {
            print("[WFAppTracker] appStart 上报 pointId=\(pointId) type=\(startType)")
        }
    }

    // MARK: - appEnd 上报

    private func reportAppEnd() {
        guard config.autoTrack.appEnd else { return }
        let pointId = config.appPoints.appEnd
        guard pointId != 0 else { return }

        let log = WFEventLog(
            config: config,
            pointId: String(pointId),
            params: ["sessionDuration": staySeconds],
            eventType: "appEnd"
        )
        WFEventUploader.shared.enqueue(log.toMap())
        if config.setting.debugLog {
            print("[WFAppTracker] appEnd 上报 pointId=\(pointId) duration=\(staySeconds)s")
        }
    }

    // MARK: - 心跳

    private func startHeartBeat() {
        guard config.autoTrack.appHeartBeat, config.setting.heartBeat.enable else { return }
        guard !isRunning else { return }
        isRunning = true
        staySeconds = 0
        beatReportCount = 0

        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
                self?.tick()
            }
        }
    }

    private func stopHeartBeat() {
        isRunning = false
        DispatchQueue.main.async { [weak self] in
            self?.timer?.invalidate()
            self?.timer = nil
        }
        staySeconds = 0
        beatReportCount = 0
    }

    private func tick() {
        guard isRunning else { return }
        staySeconds += 1
        if staySeconds >= config.setting.heartBeat.validGap {
            reportHeartBeat()
            staySeconds = 0
        }
    }

    private func reportHeartBeat() {
        let pointId = config.appPoints.appHeartBeat
        guard pointId != 0 else { return }

        let limit = config.setting.heartBeat.limit
        if limit > 0 && beatReportCount >= limit {
            if config.setting.debugLog {
                print("[WFAppTracker] 心跳次数已达上限 \(limit) 次，停止上报")
            }
            return
        }
        beatReportCount += 1

        let log = WFEventLog(
            config: config,
            pointId: String(pointId),
            params: [
                "appPageTitle": WFEventSession.shared.currentPage,
                "appStayDuration": config.setting.heartBeat.validGap
            ],
            eventType: "appHeartBeat"
        )
        WFEventUploader.shared.enqueue(log.toMap())
        if config.setting.debugLog {
            print("[WFAppTracker] 心跳上报 pointId=\(pointId) page=\(WFEventSession.shared.currentPage)")
        }
    }

    // MARK: - 工具

    private func currentTopViewControllerName() -> String {
        guard let root = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first?.windows.first(where: { $0.isKeyWindow })?.rootViewController
        else { return "UnknownPage" }
        return topViewController(from: root).map { String(describing: type(of: $0)) } ?? "UnknownPage"
    }

    private func topViewController(from vc: UIViewController) -> UIViewController? {
        if let nav = vc as? UINavigationController {
            return topViewController(from: nav.visibleViewController ?? nav)
        }
        if let tab = vc as? UITabBarController {
            return topViewController(from: tab.selectedViewController ?? tab)
        }
        if let presented = vc.presentedViewController {
            return topViewController(from: presented)
        }
        return vc
    }
}
