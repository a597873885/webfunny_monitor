import Foundation

/// 统一本地存储工具（对应 Android WFEventStorage / H5 Cookie 模拟层）
///
/// 使用 UserDefaults 持久化 SDK 状态，所有 key 统一前缀 wf_event_
enum WFEventStorage {

    // MARK: - Key 常量

    static let keyCustomerKey    = "wf_event_customer_key"
    static let keyDeviceKey      = "wf_event_device_key"
    static let keyCommonInfo     = "wf_event_common_info"
    static let keyFirstInstall   = "wf_event_first_install_date"
    static let keyAccessTimes    = "wf_event_access_times"
    static let keyLastAccessDate = "wf_event_last_access_date"
    static let keyUserInfo       = "wf_event_user_info"
    static let keyInitPoints     = "wf_event_init_points"
    static let keySignature      = "wf_event_signature"
    static let keySetting        = "wf_event_setting"

    // MARK: - 读写

    static func string(for key: String, default defaultValue: String = "") -> String {
        UserDefaults.standard.string(forKey: key) ?? defaultValue
    }

    static func set(_ value: String, for key: String) {
        UserDefaults.standard.set(value, forKey: key)
    }

    static func int(for key: String, default defaultValue: Int = 0) -> Int {
        let v = UserDefaults.standard.integer(forKey: key)
        // integer(forKey:) 返回 0 当 key 不存在，与 default 一致
        return v == 0 && UserDefaults.standard.object(forKey: key) == nil ? defaultValue : v
    }

    static func set(_ value: Int, for key: String) {
        UserDefaults.standard.set(value, forKey: key)
    }

    static func remove(_ key: String) {
        UserDefaults.standard.removeObject(forKey: key)
    }
}
