import Foundation

/// 请求签名工具（完整对标 H5 signature.js / Android WFSignature）
///
/// 1. decrypt：对服务端下发的 signature 做字符位置置换，还原密钥
/// 2. simpleHash：对 "{secret}:{projectId}" 做简单哈希，生成请求头 wf-signature 的值
enum WFSignature {

    /// 生成请求签名
    /// - Parameters:
    ///   - storedSignature: 从 initCf 接口获取并本地存储的原始 signature
    ///   - projectId: 当前项目 ID
    /// - Returns: 最终签名字符串，填入请求头 wf-signature；若签名为空则返回空字符串
    static func generate(storedSignature: String, projectId: String) -> String {
        guard !storedSignature.isEmpty else { return "" }
        let secret = decrypt(storedSignature)
        guard !secret.isEmpty else { return "" }
        let raw = "\(secret):\(projectId)"
        return String(simpleHash(raw), radix: 16)
    }

    // MARK: - Private

    /// 字符位置置换，对应 H5 decryptSignature()
    private static func decrypt(_ origin: String) -> String {
        guard origin.count >= 32 else { return "" }
        var arr = Array(origin)
        func swap(_ i: Int, _ j: Int) { arr.swapAt(i, j) }
        swap(2, 21); swap(5, 18); swap(9, 15)
        swap(12, 31); swap(16, 28); swap(20, 25)
        return String(arr.reversed())
    }

    /// 简单哈希，对应 H5 simpleHash()
    private static func simpleHash(_ str: String) -> Int32 {
        var hash: Int32 = 0
        for ch in str.unicodeScalars {
            hash = (hash << 5) &- hash &+ Int32(bitPattern: ch.value)
            hash = hash | 0
        }
        return hash
    }
}
