import Foundation

// MARK: - App 全埋点点位 ID 配置

/// App 端全埋点点位 ID 配置
/// 与 Android WFAppPoints 协议对齐
public struct WFAppPoints {
    public var appStart:     Int
    public var appEnd:       Int
    public var appHeartBeat: Int
    /// 页面进入（手动采集）
    public var appPageEnter: Int
    /// 页面离开（手动采集）
    public var appPageLeave: Int

    public init(
        appStart:     Int = 0,
        appEnd:       Int = 0,
        appHeartBeat: Int = 0,
        appPageEnter: Int = 0,
        appPageLeave: Int = 0
    ) {
        self.appStart     = appStart
        self.appEnd       = appEnd
        self.appHeartBeat = appHeartBeat
        self.appPageEnter = appPageEnter
        self.appPageLeave = appPageLeave
    }
}

// MARK: - 全埋点开关控制

/// 对应 Android WFAutoTrack
public struct WFAutoTrack {
    public var appStart:     Bool
    public var appEnd:       Bool
    public var appHeartBeat: Bool

    public init(appStart: Bool = true, appEnd: Bool = true, appHeartBeat: Bool = true) {
        self.appStart     = appStart
        self.appEnd       = appEnd
        self.appHeartBeat = appHeartBeat
    }
}

// MARK: - 心跳子配置

/// 对应 Android WFHeartBeatSetting
public struct WFHeartBeatSetting {
    /// 心跳开关
    public var enable: Bool
    /// 心跳间隔（秒）；有效枚举：5 / 15 / 30 / 60，其他值自动回退为 15
    public var gap:    Int
    /// 单次连续最多上报次数，0 = 不限制
    public var limit:  Int

    public init(enable: Bool = true, gap: Int = 15, limit: Int = 120) {
        self.enable = enable
        self.gap    = gap
        self.limit  = limit
    }

    /// 规范化后的有效间隔（秒）
    var validGap: Int {
        [5, 15, 30, 60].contains(gap) ? gap : 15
    }

    /// 转为 TimeInterval，供 Timer 使用
    var gapInterval: TimeInterval {
        TimeInterval(validGap)
    }
}

// MARK: - SDK 行为配置

/// 对应 Android WFSetting
public struct WFSetting {
    public var heartBeat: WFHeartBeatSetting
    /// 是否打印 SDK 调试日志
    public var debugLog:  Bool
    /// 是否启用 gzip 压缩上报（默认 true）
    public var gzip:      Bool

    public init(heartBeat: WFHeartBeatSetting = WFHeartBeatSetting(), debugLog: Bool = false, gzip: Bool = true) {
        self.heartBeat = heartBeat
        self.debugLog  = debugLog
        self.gzip      = gzip
    }
}

// MARK: - 主配置

/// Webfunny iOS 埋点 SDK v2.0 初始化配置
///
/// ```swift
/// WFEvent.initEvent(
///     WFEventConfig(
///         uploadDomain:  "https://your-server.com/",
///         projectId:      "event_20250312_153829902",
///         env:            "pro",
///         projectVersion: "1.0.0",
///         appPoints:      WFAppPoints(appStart: 10, appEnd: 15, appHeartBeat: 14, appPageEnter: 12, appPageLeave: 13),
///         autoTrack:      WFAutoTrack(appHeartBeat: true),
///         setting:        WFSetting(heartBeat: WFHeartBeatSetting(enable: true, gap: 15))
///     )
/// )
/// ```
public struct WFEventConfig {
    /// 上报服务域名，末尾斜杠可选
    public var uploadDomain:  String
    /// 埋点项目 ID
    public var projectId:      String
    /// 当前环境：dev / sit / stag / pro（默认 pro）
    public var env:            String
    /// 应用版本号
    public var projectVersion: String
    /// App 全埋点点位 ID
    public var appPoints:      WFAppPoints
    /// 全埋点开关
    public var autoTrack:      WFAutoTrack
    /// SDK 行为配置
    public var setting:        WFSetting

    public init(
        uploadDomain:  String,
        projectId:      String,
        env:            String = "pro",
        projectVersion: String = "1.0.0",
        appPoints:      WFAppPoints = WFAppPoints(),
        autoTrack:      WFAutoTrack = WFAutoTrack(),
        setting:        WFSetting   = WFSetting()
    ) {
        self.uploadDomain  = uploadDomain
        self.projectId      = projectId
        self.env            = env
        self.projectVersion = projectVersion
        self.appPoints      = appPoints
        self.autoTrack      = autoTrack
        self.setting        = setting
    }

    var domain: String { uploadDomain.hasSuffix("/") ? String(uploadDomain.dropLast()) : uploadDomain }

    var initCfURL:  URL? { URL(string: "\(domain)/wfEvent/initCf") }
    var uploadURL:  URL? { URL(string: "\(domain)/wfEvent/upEvents") }

    /// 内部：队列满多少条触发批量上报
    var maxQueueSize:     Int          = 20
    /// 内部：定时刷新间隔
    var flushInterval:    TimeInterval = 8.0
}
