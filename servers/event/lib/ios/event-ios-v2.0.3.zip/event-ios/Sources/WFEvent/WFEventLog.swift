import Foundation
#if canImport(UIKit)
import UIKit
#endif
#if canImport(CoreTelephony)
import CoreTelephony
#endif

/// 埋点上报数据模型 v2.0（对标 Android WFEventLog）
///
/// 新增 eventType、10 个设备信息字段、weDeviceId、weCommonInfo
struct WFEventLog {

    let config:    WFEventConfig
    let pointId:   String
    let params:    [String: Any]
    /// 事件类型，SDK 自动事件设对应值，业务方 track() 默认 "custom"
    let eventType: String

    // MARK: - 项目标识

    var projectId: String { config.projectId }

    // MARK: - 事件类型

    var weEventType: String { eventType }

    // MARK: - 时间

    var weHappenTime: Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

    // MARK: - 设备标识（双 ID）

    var weCustomerKey: String { WFEventSession.shared.customerKey }
    var weDeviceId:    String { WFEventSession.shared.deviceKey }

    // MARK: - 用户信息（Base64 编码）

    var weUserId:    String { b64(WFEventSession.shared.userId) }
    var weNickname:  String { b64(WFEventSession.shared.nickname) }
    var weUserType:  String { b64(WFEventSession.shared.userType) }
    var weUserLabel: String { b64(WFEventSession.shared.userTag) }
    var weRemark:    String { b64(WFEventSession.shared.userDes) }

    // MARK: - 页面路径

    var wePath: String { b64(WFEventSession.shared.currentPage) }

    // MARK: - 基础设备信息

    var weDeviceName:  String { UIDevice.current.model }
    var wePlatform:    String { "ios" }
    var weOs:          String { "ios" }
    var weSystem:      String { "ios \(UIDevice.current.systemVersion)" }
    var weBrowserName: String { "" }
    var weBrowserInfo: String {
        b64("iOS/\(UIDevice.current.systemVersion) \(UIDevice.current.model)")
    }

    // MARK: - v2.0 新增设备信息

    var weScreenWidth:  Int    { Int(UIScreen.main.bounds.width * UIScreen.main.scale) }
    var weScreenHeight: Int    { Int(UIScreen.main.bounds.height * UIScreen.main.scale) }
    var weDensity:      Int    { Int(UIScreen.main.scale * 163) }
    var weNetworkType:  String {
        // 通过 0.0.0.0 可达性判断有无网络（简单方案）
        return "unknown"
    }
    var weCarrier:      String { carrierName() }
    var weManufacturer: String { "Apple" }
    var weDeviceBrand:  String { UIDevice.current.model }
    var weAppVersion:   String { appVersion() }
    var weSdkVersion:   String { Self.SDK_VERSION }
    var weLanguage:     String { Locale.preferredLanguages.first ?? "" }
    var weTimezone:     String { TimeZone.current.identifier }

    // MARK: - 通用属性

    var weCommonInfo: String { WFEventSession.shared.commonInfo }

    // MARK: - 用户状态

    var weNewStatus: Int { WFEventSession.shared.newStatus }

    // MARK: - 序列化

    func toMap() -> [String: Any] {
        var map: [String: Any] = [
            "projectId":      projectId,
            "pointId":        pointId,
            "eventType":      weEventType,
            "weHappenTime":   weHappenTime,
            "weCustomerKey":  weCustomerKey,
            "weDeviceId":     weDeviceId,
            "weUserId":       weUserId,
            "weNickname":     weNickname,
            "weUserType":     weUserType,
            "weUserLabel":    weUserLabel,
            "weRemark":       weRemark,
            "wePath":         wePath,
            "weDeviceName":   weDeviceName,
            "wePlatform":     wePlatform,
            "weOs":           weOs,
            "weSystem":       weSystem,
            "weBrowserName":  weBrowserName,
            "weBrowserInfo":  weBrowserInfo,
            // v2.0 新增
            "weScreenWidth":  weScreenWidth,
            "weScreenHeight": weScreenHeight,
            "weDensity":      weDensity,
            "weNetworkType":  weNetworkType,
            "weCarrier":      weCarrier,
            "weManufacturer": weManufacturer,
            "weDeviceBrand":  weDeviceBrand,
            "weAppVersion":   weAppVersion,
            "weSdkVersion":   weSdkVersion,
            "weLanguage":     weLanguage,
            "weTimezone":     weTimezone,
            "weCommonInfo":   weCommonInfo,
            "weNewStatus":    weNewStatus
        ]
        for (k, v) in params {
            map[k] = (v is String) ? b64(v as! String) : v
        }
        return map
    }

    // MARK: - Base64 工具

    func b64(_ str: String) -> String {
        Data(str.utf8).base64EncodedString()
    }

    // MARK: - 常量

    static let SDK_VERSION = "2.0.0"
    /// 构建编号，每次代码改动 +1，用于排查缓存问题
    static let BUILD_NO    = 3

    // MARK: - 设备信息获取

    private func carrierName() -> String {
        #if targetEnvironment(simulator)
        return ""  // 模拟器无蜂窝硬件，跳过 CoreTelephony 查询
        #else
        let info = CTTelephonyNetworkInfo()
        if #available(iOS 12.0, *) {
            return info.serviceSubscriberCellularProviders?.values.first?.carrierName ?? ""
        } else {
            return info.subscriberCellularProvider?.carrierName ?? ""
        }
        #endif
    }

    private func appVersion() -> String {
        if !config.projectVersion.isEmpty && config.projectVersion != "1.0.0" {
            return config.projectVersion
        }
        return Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
            ?? config.projectVersion
    }
}
