# Webfunny Event iOS SDK v2.0

Webfunny 埋点 SDK iOS 版，零第三方依赖，纯系统 API 实现。

---

## 1. 下载 SDK

下载 webfunny-event-ios.zip（请联系技术支持获取最新下载地址），将 `webfunny-event-ios` 文件夹解压到你的项目目录下。

在 Xcode 中添加本地 Package：

1. **File** → **Add Package Dependencies**
2. 点击左下角 **Add Local...**
3. 选择解压后的 `webfunny-event-ios` 文件夹
4. 点击 **Add Package**

---

## 2. 初始化 SDK

在 `AppDelegate.application(_:didFinishLaunchingWithOptions:)` 或 SwiftUI App 入口的 `init()` 中初始化，**越早越好**：

```swift
import WFEvent

WFEvent.initEvent(
    WFEventConfig(
        uploadDomain:  "https://your-server.com",   // 上报域名
        projectId:      "your-project-id",            // 埋点项目 ID
        env:            "pro",                        // dev / sit / stag / pro
        projectVersion: "1.0.0",
        appPoints: WFAppPoints(
            appStart:     10,   // App 启动
            appEnd:       11,   // App 进入后台
            appHeartBeat: 12,   // 前台心跳
            appPageEnter: 13,   // 页面进入（手动采集）
            appPageLeave: 14    // 页面离开（手动采集）
        ),
        autoTrack: WFAutoTrack(
            appStart:     true,
            appEnd:       true,
            appHeartBeat: true
        ),
        setting: WFSetting(
            heartBeat: WFHeartBeatSetting(
                enable: true,
                gap:    15,
                limit:  20
            ),
            debugLog: true,   // 开发阶段开启，上线改为 false
            gzip:     true    // 是否 gzip 压缩上报，默认 true
        )
    )
)
```

> **projectId / 点位 ID 从哪来？** 登录 Webfunny 控制台 → 事件分析 → 创建项目 → 获取项目 ID 和各点位 ID。

### 验证

运行 App 后，在 Xcode Console 搜索 `WFEvent`，应能看到初始化日志和全埋点事件。

---

## 3. 设置通用属性（可选，随时可调）

```swift
// 设置
WFEvent.setCommonInfo([
    "channel":  "app_store",
    "vipLevel": "gold"
])

// 清空
WFEvent.setCommonInfo([:])
```

通用属性会持久化到本地，上报时自动附加到 `weCommonInfo` 字段。

---

## 4. 设置用户信息（登录后调用）

```swift
WFEvent.setUser(
    userId:   "user_001",
    nickname: "张三",
    userType: "user",
    userTag:  "ios_test",
    des:      "iOS 测试账号"
)
```

退出登录时清除：

```swift
WFEvent.setUser()  // 全部置为空
```

---

## 5. 上报埋点事件

### 方式一：按环境选点位（推荐）

```swift
WFEvent.track(
    pointIds: ["pro": "747", "dev": "xxx"],
    params:   ["buttonName": "立即购买"],
    upNow:    true
)
```

### 方式二：直接传点位 ID

```swift
WFEvent.track(
    pointId: "747",
    params:  ["productId": "12345"],
    upNow:   false
)
```

---

## 6. 全埋点（3 点位）

SDK 自动采集以下事件，无需业务方手动埋点：

| 点位 | 说明 | 携带参数 |
|------|------|------|
| `appStart` | App 启动（冷/热） | `startType`(cold/hot) |
| `appEnd` | App 进入后台 | `sessionDuration`(s) |
| `appHeartBeat` | 前台心跳 | `appPageTitle`、`appStayDuration`(s) |

通过 `WFAutoTrack` 开关独立控制每个点位的启用/禁用。

> **注意**：iOS 没有全局页面生命周期回调，无法自动采集页面进入/离开。请使用下方的 `trackPageView` / `trackPageLeave` 手动采集。

---

## 7. 手动页面采集

适用于所有页面切换场景：UIKit ViewController、SwiftUI View、Tab 切换等。

### UIKit

```swift
class ProductViewController: UIViewController {

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        WFEvent.trackPageView(pageTitle: "商品详情页", pagePath: "/product/detail")
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        WFEvent.trackPageLeave()  // 停留时长自动计算
    }
}
```

### SwiftUI

```swift
struct ProductListView: View {
    var body: some View {
        List { ... }
            .onAppear {
                WFEvent.trackPageView(pageTitle: "商品列表", pagePath: "/product/list")
            }
            .onDisappear {
                WFEvent.trackPageLeave()
            }
    }
}
```

### trackPageView

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `pageTitle` | String | **必填** | 页面名称 |
| `pagePath` | String | 同 `pageTitle` | 页面路径 |
| `params` | [String: Any] | `[:]` | 附加业务参数 |

### trackPageLeave

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `pageTitle` | String | 上次 trackPageView 的值 | 页面名称 |
| `pagePath` | String | 上次 trackPageView 的值 | 页面路径 |
| `stayDuration` | TimeInterval | 自动计算 | 停留时长（毫秒），传 `>=0` 的值表示手动指定 |
| `params` | [String: Any] | `[:]` | 附加业务参数 |

> 两个方法共用 `appPoints.appPageEnter` / `appPoints.appPageLeave` 点位 ID。

---

## 8. WFEventConfig 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `uploadDomain` | String | **必填** | 上报服务域名 |
| `projectId` | String | **必填** | 埋点项目 ID |
| `env` | String | `"pro"` | 当前环境：dev / sit / stag / pro |
| `projectVersion` | String | `"1.0.0"` | 应用版本号 |
| `appPoints` | WFAppPoints | 全 0 | App 全埋点点位 ID |
| `autoTrack` | WFAutoTrack | 全 true | 全埋点开关 |
| `setting` | WFSetting | 默认值 | SDK 行为配置（心跳、调试日志、gzip） |

### WFSetting

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `heartBeat` | WFHeartBeatSetting | 见下方 | 心跳子配置 |
| `debugLog` | Bool | `false` | 是否打印 SDK 调试日志 |
| `gzip` | Bool | `true` | 是否启用 gzip 压缩上报 |

### WFHeartBeatSetting

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enable` | Bool | `true` | 心跳开关 |
| `gap` | Int | `15` | 心跳间隔（秒），可选：5 / 15 / 30 / 60 |
| `limit` | Int | `120` | 单次连续最大心跳次数（0=不限制） |

---

## 9. API 参考

| 方法 | 说明 |
|------|------|
| `WFEvent.initEvent(_ config:)` | 初始化 SDK |
| `WFEvent.setCommonInfo(_ params:)` | 设置通用属性（持久化） |
| `WFEvent.setUser(userId:nickname:...)` | 设置当前用户信息 |
| `WFEvent.track(pointId:params:upNow:)` | 直接指定点位上报 |
| `WFEvent.track(pointIds:params:upNow:)` | 按环境选点位上报 |
| `WFEvent.trackPageView(pageTitle:pagePath:params:)` | 手动上报页面进入 |
| `WFEvent.trackPageLeave(pageTitle:pagePath:stayDuration:params:)` | 手动上报页面离开 |
| `WFEvent.flush()` | 手动刷新上报队列 |

---

## 10. v2.0 更新日志

- **全埋点**：新增 3 个 App 端全埋点点位（appStart / appEnd / appHeartBeat），基于系统通知，无 Method Swizzling
- **手动页面采集**：`trackPageView` / `trackPageLeave` 支持 UIKit & SwiftUI，停留时长自动计算
- **数据可靠性**：文件持久化、自动重试（4s/16s/32s）、gzip 压缩
- **通用属性**：`setCommonInfo()` 动态设置，持久化到本地，上报自动携带
- **设备 ID**：双 ID 设计（customerKey + deviceKey 神策方案），卸载重装大概率不变
- **事件体系**：新增 `eventType` 字段，区分自动/手动事件

---

## 11. 环境要求

- iOS 14+
- Swift 5.9+
- Xcode 15+
