# Webfunny Event iOS SDK — Objective-C 接入指南

Webfunny 埋点 SDK iOS 版的 Objective-C 接入文档。

> SDK 核心使用 Swift 编写（enum + struct），ObjC 无法直接调用。
> SDK 内置 `WFEventBridge` 桥接层，将全部 API 包装为 `@objc` 类和方法，ObjC 项目直接使用即可，无需自己写桥接文件。

---

## 1. 集成 SDK

### CocoaPods

SDK 内置 `WFEvent.podspec`，在 Podfile 中添加：

```ruby
pod 'WFEvent', :path => 'path/to/event-ios'
```

> 如果 SDK 已发布到远程仓库，可改为 `pod 'WFEvent', '~> 2.0.0'`。

然后执行：

```bash
pod install
```

### 注意事项

1. **必须通过 `.xcworkspace` 打开项目**，不能直接打开 `.xcodeproj`，否则会报 `No such module 'WFEvent'`
2. Podfile 中需要 `use_frameworks!`（动态框架模式）
3. 如遇 Xcode 15+ 的 rsync 权限错误，在 Podfile 的 `post_install` 中添加：
   ```ruby
   post_install do |installer|
     installer.pods_project.targets.each do |target|
       target.build_configurations.each do |config|
         target.build_settings(config.name)['ENABLE_USER_SCRIPT_SANDBOXING'] = 'NO'
       end
     end
   end
   ```

---

## 2. 导入头文件

在需要调用埋点的 `.m` 文件中导入：

```objc
#import <WFEvent/WFEvent-Swift.h>
```

> 这一个头文件包含 `WFEventBridge` 和所有配置类。
>
> **说明**：`WFEvent-Swift.h` 不是 SDK 源码中的物理文件，而是 Xcode 编译时自动生成的 ObjC 头文件。
> 只要项目通过 CocoaPods 集成了 WFEvent 并完成一次编译，该文件就会自动生成，`#import` 即可正常使用，无需手动查找。
> 如果 Xcode 编辑器中该行显示红色，通常是因为没有用 `.xcworkspace` 打开项目，或尚未编译过一次。

---

## 3. 初始化 SDK

在 `AppDelegate` 的 `application:didFinishLaunchingWithOptions:` 中初始化，**越早越好**。

SDK 采用分类配置对象，按 5 个类别分组：

```objc
#import <WFEvent/WFEvent-Swift.h>

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    // 1. 服务器配置
    WFEventServerConfig *server = [WFEventServerConfig new];
    server.uploadDomain   = @"https://your-server.com";   // 上报域名
    server.projectId      = @"your-project-id";            // 埋点项目 ID
    server.env            = @"pro";                        // dev / sit / stag / pro
    server.projectVersion = @"1.0.0";                      // 应用版本号

    // 2. 全埋点点位
    WFEventAppPointsConfig *appPoints = [WFEventAppPointsConfig new];
    appPoints.appStart     = 19;   // App 启动
    appPoints.appEnd       = 20;   // App 进入后台
    appPoints.appHeartBeat = 24;   // 前台心跳
    appPoints.appPageEnter = 21;   // 页面进入（手动采集）
    appPoints.appPageLeave = 22;   // 页面离开（手动采集）

    // 3. 自动采集开关
    WFEventAutoTrackConfig *autoTrack = [WFEventAutoTrackConfig new];
    autoTrack.appStart     = YES;
    autoTrack.appEnd       = YES;
    autoTrack.appHeartBeat = YES;

    // 4. 心跳配置
    WFEventHeartBeatConfig *heartBeat = [WFEventHeartBeatConfig new];
    heartBeat.enable = YES;
    heartBeat.gap    = 15;     // 心跳间隔（秒），可选 5 / 15 / 30 / 60
    heartBeat.limit  = 20;     // 单次连续最大心跳次数

    // 5. 其他设置
    WFEventSettingConfig *setting = [WFEventSettingConfig new];
    setting.debugLog = YES;    // 开发阶段开启，上线改为 NO
    setting.gzip     = YES;    // 是否 gzip 压缩上报

    // 初始化
    [WFEventBridge initEventWithServer:server
                             appPoints:appPoints
                             autoTrack:autoTrack
                             heartBeat:heartBeat
                               setting:setting];

    return YES;
}
```

> **projectId / 点位 ID 从哪来？** 登录 Webfunny 控制台 → 事件分析 → 创建项目 → 获取项目 ID 和各点位 ID。

### 验证

运行 App 后，在 Xcode Console 搜索 `WFEvent`，应能看到初始化日志和全埋点事件。

---

## 4. 设置通用属性（可选，随时可调）

通用属性会持久化到本地，上报时自动附加到 `weCommonInfo` 字段。

```objc
// 设置
[WFEventBridge setCommonInfo:@{
    @"channel":  @"app_store",
    @"vipLevel": @"gold"
}];

// 清空
[WFEventBridge setCommonInfo:@{}];
```

---

## 5. 设置用户信息（登录后调用）

```objc
[WFEventBridge setUserWithUserId:@"user_001"
                        nickname:@"张三"
                       userType:@"user"
                        userTag:@"ios_test"
                            des:@"iOS 测试账号"];

// 退出登录时清除（全部传空字符串）
[WFEventBridge setUserWithUserId:@""
                        nickname:@""
                       userType:@""
                        userTag:@""
                            des:@""];
```

---

## 6. 上报埋点事件

### 按环境选点位（推荐）

根据初始化时设置的 `env` 自动选择对应点位的 ID。

```objc
[WFEventBridge trackByEnvWithPointIds:@{@"pro": @"747", @"dev": @"xxx"}
                                params:@{@"buttonName": @"立即购买"}];
```

### 直接指定点位 ID

```objc
// 加入队列，等待批量上报
[WFEventBridge trackWithPointId:@"747"
                          params:@{@"productId": @"12345"}];

// 立即上报（不等待队列）
[WFEventBridge trackImmediateWithPointId:@"747"
                                   params:@{@"productId": @"12345"}];
```

### 手动刷新上报队列

```objc
[WFEventBridge flush];
```

---

## 7. 全埋点（3 点位）

SDK 自动采集以下事件，无需业务方手动埋点：

| 点位 | 说明 | 携带参数 |
|------|------|------|
| `appStart` | App 启动（冷/热） | `startType`(cold/hot) |
| `appEnd` | App 进入后台 | `sessionDuration`(s) |
| `appHeartBeat` | 前台心跳 | `appPageTitle`、`appStayDuration`(s) |

通过 `WFEventAutoTrackConfig` 独立控制每个点位的启用/禁用。

> **注意**：iOS 没有全局页面生命周期回调，无法自动采集页面进入/离开。请使用下方的 `trackPageView` / `trackPageLeave` 手动采集。

---

## 8. 手动页面采集

在 `viewDidAppear` 和 `viewWillDisappear` 中配对调用：

```objc
#import <WFEvent/WFEvent-Swift.h>

@interface ProductDetailViewController : UIViewController
@end

@implementation ProductDetailViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [WFEventBridge trackPageViewWithPageTitle:@"商品详情页" pagePath:@"/product/detail"];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [WFEventBridge trackPageLeave];  // 停留时长自动计算
}

@end
```

> 两个方法共用初始化时配置的 `appPageEnter` / `appPageLeave` 点位 ID。

---

## 9. 配置类参考

### WFEventServerConfig

| 属性 | 类型 | 说明 |
|------|------|------|
| `uploadDomain` | NSString * | 上报服务域名 |
| `projectId` | NSString * | 埋点项目 ID |
| `env` | NSString * | 环境：dev / sit / stag / pro |
| `projectVersion` | NSString * | 应用版本号 |

### WFEventAppPointsConfig

| 属性 | 类型 | 说明 |
|------|------|------|
| `appStart` | Int | App 启动点位 |
| `appEnd` | Int | App 进入后台点位 |
| `appHeartBeat` | Int | 心跳点位 |
| `appPageEnter` | Int | 页面进入点位（手动采集） |
| `appPageLeave` | Int | 页面离开点位（手动采集） |

### WFEventAutoTrackConfig

| 属性 | 类型 | 说明 |
|------|------|------|
| `appStart` | BOOL | 是否自动采集 App 启动 |
| `appEnd` | BOOL | 是否自动采集 App 进入后台 |
| `appHeartBeat` | BOOL | 是否自动采集心跳 |

### WFEventHeartBeatConfig

| 属性 | 类型 | 说明 |
|------|------|------|
| `enable` | BOOL | 心跳开关 |
| `gap` | Int | 心跳间隔（秒），可选 5 / 15 / 30 / 60 |
| `limit` | Int | 单次连续最大心跳次数，0 = 不限制 |

### WFEventSettingConfig

| 属性 | 类型 | 说明 |
|------|------|------|
| `debugLog` | BOOL | 是否打印 SDK 调试日志 |
| `gzip` | BOOL | 是否启用 gzip 压缩上报 |

---

## 10. API 参考

| 方法 | 说明 |
|------|------|
| `[WFEventBridge initEventWithServer:appPoints:autoTrack:heartBeat:setting:]` | 初始化 SDK |
| `[WFEventBridge setCommonInfo:]` | 设置通用属性（持久化） |
| `[WFEventBridge setUserWithUserId:nickname:userType:userTag:des:]` | 设置当前用户信息 |
| `[WFEventBridge trackWithPointId:params:]` | 上报事件（加入队列） |
| `[WFEventBridge trackImmediateWithPointId:params:]` | 上报事件并立即上报 |
| `[WFEventBridge trackByEnvWithPointIds:params:]` | 按环境选点位上报 |
| `[WFEventBridge trackPageViewWithPageTitle:pagePath:]` | 手动上报页面进入 |
| `[WFEventBridge trackPageLeave]` | 手动上报页面离开 |
| `[WFEventBridge flush]` | 手动刷新上报队列 |

---

## 11. 环境要求

- iOS 14+
- Xcode 15+
- CocoaPods 1.10+
