Pod::Spec.new do |s|
  s.name             = 'WFEvent'
  s.version          = '2.0.4'
  s.summary          = 'Webfunny 埋点 iOS SDK'
  s.description      = <<-DESC
    对接 Webfunny 埋点平台的 iOS 原生 SDK，支持事件埋点、页面浏览采集、
    心跳上报、gzip 压缩，数据上报到 /wfEvent/upEvents 接口。
  DESC
  s.homepage         = 'https://github.com/webfunny/event-ios'
  s.license          = { :type => 'MIT' }
  s.author           = { 'Webfunny' => 'dev@webfunny.com' }
  s.source           = { :git => 'https://github.com/webfunny/event-ios.git', :tag => s.version.to_s }

  s.ios.deployment_target = '14.0'
  s.swift_version         = '5.9'

  s.source_files = 'Sources/WFEvent/**/*.swift'

  s.frameworks = 'UIKit', 'Foundation', 'CoreTelephony'
  s.libraries  = 'z', 'compression'
end
