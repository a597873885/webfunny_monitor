import Foundation

/// Webfunny iOS 埋点 SDK v2.0 唯一对外入口
///
/// ── 接入步骤 ──────────────────────────────────────────────────────
///
/// 1. AppDelegate / App struct 的启动入口中初始化（越早越好）：
///    ```swift
///    WFEvent.initEvent(
///        WFEventConfig(
///            uploadDomain:  "https://your-server.com/",
///            projectId:      "event_20250312_153829902",
///            env:            "pro",
///            projectVersion: "1.0.0",
///            appPoints:      WFAppPoints(appStart: 10, appEnd: 15, appHeartBeat: 14, appPageEnter: 12, appPageLeave: 13),
///            autoTrack:      WFAutoTrack(appHeartBeat: true),
///            setting:        WFSetting(heartBeat: WFHeartBeatSetting(enable: true, gap: 15))
///        )
///    )
///    ```
///
/// 2. 设置通用属性（可选，随时可调）：
///    ```swift
///    WFEvent.setCommonInfo(["channel": "app_store", "vipLevel": "gold"])
///    ```
///
/// 3. 用户登录后设置用户信息：
///    ```swift
///    WFEvent.setUser(userId: "user_123", nickname: "张三")
///    ```
///
/// 4. 上报埋点事件：
///    ```swift
///    WFEvent.track(
///        pointId: "456",
///        params:  ["buttonName": "立即购买"],
///        eventType: "custom"
///    )
///    ```
public enum WFEvent {

    private static var config: WFEventConfig?
    private static var appTracker: WFAppTracker?
    private static let initQueue = DispatchQueue(label: "com.webfunny.event.init", qos: .utility)

    // MARK: - 手动页面采集状态

    private static var manualPageTitle: String = ""
    private static var manualPagePath: String = ""
    private static var manualReferPage: String = ""
    private static var manualPageEnterTime: TimeInterval = 0

    // MARK: - 初始化

    /// 初始化 SDK v2.0
    public static func initEvent(_ config: WFEventConfig) {
        self.config = config

        if config.setting.debugLog {
            print("[WFEvent] ┌─────────── SDK Info ───────────────────")
            print("[WFEvent] │ Version : v\(WFEventLog.SDK_VERSION)")
            print("[WFEvent] │ Build   : #\(WFEventLog.BUILD_NO)")
            print("[WFEvent] │ Config  : gzip=\(config.setting.gzip)")
            print("[WFEvent] └────────────────────────────────────────")
        }

        WFEventSession.shared.setup()
        WFEventUploader.shared.setup(config: config)

        // 全埋点采集器
        if config.autoTrack.appStart || config.autoTrack.appEnd || config.autoTrack.appHeartBeat {
            let tracker = WFAppTracker(config: config)
            appTracker = tracker
            tracker.install()
        }

        initQueue.async { fetchInitCf(config) }
    }

    // MARK: - 通用属性

    /// 设置通用属性（持久化到本地，上报时自动附加到 weCommonInfo）
    /// - Parameter params: 键值对，传空字典清空通用属性
    public static func setCommonInfo(_ params: [String: Any]) {
        WFEventSession.shared.setCommonInfo(params)
    }

    // MARK: - 设置用户信息

    /// 登录后调用（对应 H5 WebfunnyEvents.initUser / Android WFEvent.setUser）
    public static func setUser(
        userId:   String = "",
        nickname: String = "",
        userType: String = "",
        userTag:  String = "",
        des:      String = ""
    ) {
        WFEventSession.shared.setUser(
            userId:   userId,
            nickname: nickname,
            userType: userType,
            userTag:  userTag,
            des:      des
        )
    }

    // MARK: - 埋点上报

    /// 按点位 ID 上报（直接指定 pointId）
    /// - Parameters:
    ///   - pointId: 埋点点位 ID
    ///   - params: 业务参数，字符串值自动 base64 编码
    ///   - eventType: 事件类型，默认 "custom"
    ///   - upNow: 是否立即上报
    public static func track(
        pointId:   String,
        params:    [String: Any] = [:],
        eventType: String = "custom",
        upNow:     Bool = false
    ) {
        guard let config else {
            print("[WFEvent] initEvent() 尚未调用，track() 被忽略")
            return
        }
        let log = WFEventLog(config: config, pointId: pointId, params: params, eventType: eventType)
        WFEventUploader.shared.enqueue(log.toMap())
        if upNow { WFEventUploader.shared.flushNow() }
    }

    /// 按环境选点位 ID 上报（对应 H5 webfunnyEvent({pro: 747, dev: "xxx"}).trackEvent(...)）
    public static func track(
        pointIds:  [String: Any],
        params:    [String: Any] = [:],
        eventType: String = "custom",
        upNow:     Bool = false
    ) {
        guard let config else {
            print("[WFEvent] initEvent() 尚未调用，track() 被忽略")
            return
        }
        let resolved = pointIds[config.env]
            ?? pointIds["pro"]
            ?? pointIds.values.first
        guard let pointId = resolved.map({ "\($0)" }), !pointId.isEmpty else {
            print("[WFEvent] pointIds 中找不到匹配环境 '\(config.env)' 的点位 ID，已跳过")
            return
        }
        track(pointId: pointId, params: params, eventType: eventType, upNow: upNow)
    }

    /// 立即刷新上报队列
    public static func flush() {
        WFEventUploader.shared.flushNow()
    }

    // MARK: - 手动页面采集

    /// 手动上报页面浏览事件（进入）
    ///
    /// iOS 没有全局页面生命周期回调，需在 `viewDidAppear` 中手动调用。
    /// 配合 `trackPageLeave` 自动计算停留时长。
    ///
    /// ```swift
    /// override func viewDidAppear(_ animated: Bool) {
    ///     super.viewDidAppear(animated)
    ///     WFEvent.trackPageView(pageTitle: "商品详情页", pagePath: "/product/detail")
    /// }
    /// ```
    public static func trackPageView(
        pageTitle: String,
        pagePath:  String = "",
        params:    [String: Any] = [:]
    ) {
        guard let config else {
            print("[WFEvent] initEvent() 尚未调用，trackPageView() 被忽略")
            return
        }
        let pointId = config.appPoints.appPageEnter
        guard pointId != 0 else {
            print("[WFEvent] appPageEnter 点位 ID 未配置，trackPageView() 被忽略")
            return
        }

        let path = pagePath.isEmpty ? pageTitle : pagePath
        var allParams: [String: Any] = [
            "appPageTitle": pageTitle,
            "appPagePath":  path,
            "appReferPage": manualReferPage
        ]
        params.forEach { allParams[$0.key] = $0.value }

        let log = WFEventLog(config: config, pointId: String(pointId), params: allParams, eventType: "appPageEnter")
        WFEventUploader.shared.enqueue(log.toMap())

        manualReferPage = pageTitle
        manualPageTitle = pageTitle
        manualPagePath = path
        manualPageEnterTime = Date().timeIntervalSince1970 * 1000
        WFEventSession.shared.currentPage = pageTitle

        if config.setting.debugLog {
            print("[WFEvent] trackPageView: title=\(pageTitle) path=\(path) refer=\(manualReferPage)")
        }
    }

    /// 手动上报页面浏览事件（离开）
    ///
    /// 与 `trackPageView` 配对使用，在 `viewWillDisappear` 中调用。
    /// 不传 `stayDuration` 时自动计算（基于上次 `trackPageView` 的时间）。
    ///
    /// ```swift
    /// override func viewWillDisappear(_ animated: Bool) {
    ///     super.viewWillDisappear(animated)
    ///     WFEvent.trackPageLeave()
    /// }
    /// ```
    public static func trackPageLeave(
        pageTitle:    String = "",
        pagePath:     String = "",
        stayDuration: TimeInterval = -1,
        params:       [String: Any] = [:]
    ) {
        guard let config else {
            print("[WFEvent] initEvent() 尚未调用，trackPageLeave() 被忽略")
            return
        }
        let pointId = config.appPoints.appPageLeave
        guard pointId != 0 else {
            print("[WFEvent] appPageLeave 点位 ID 未配置，trackPageLeave() 被忽略")
            return
        }

        // 不传时自动取上次 trackPageView 的值
        let title = pageTitle.isEmpty ? manualPageTitle : pageTitle
        let path  = pagePath.isEmpty  ? manualPagePath  : pagePath

        let duration: TimeInterval
        if stayDuration >= 0 {
            duration = stayDuration
        } else if manualPageEnterTime > 0 {
            duration = Date().timeIntervalSince1970 * 1000 - manualPageEnterTime
        } else {
            duration = 0
        }

        var allParams: [String: Any] = [
            "appPageTitle":    title,
            "appPagePath":     path,
            "appStayDuration": Int(duration)
        ]
        params.forEach { allParams[$0.key] = $0.value }

        let log = WFEventLog(config: config, pointId: String(pointId), params: allParams, eventType: "appPageLeave")
        WFEventUploader.shared.enqueue(log.toMap())

        if config.setting.debugLog {
            print("[WFEvent] trackPageLeave: title=\(title) path=\(path) duration=\(Int(duration))ms")
        }
    }

    // MARK: - 内部：initCf

    private static func fetchInitCf(_ cfg: WFEventConfig) {
        guard let url = cfg.initCfURL else { return }

        let bodyObj: [String: Any] = [
            "projectId": cfg.projectId,
            "userId":    WFEventSession.shared.userId,
            "nickname":  WFEventSession.shared.nickname
        ]
        guard let body = try? JSONSerialization.data(withJSONObject: bodyObj) else { return }

        if cfg.setting.debugLog {
            print("[WFEvent] ┌─────────── initCf 请求 ────────────────")
            print("[WFEvent] │ URL  : \(url)")
            print("[WFEvent] │ Body : \(String(data: body, encoding: .utf8) ?? "")")
            print("[WFEvent] └────────────────────────────────────────")
        }

        var request = URLRequest(url: url, timeoutInterval: 10)
        request.httpMethod = "POST"
        request.setValue("application/json;charset=UTF-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error {
                print("[WFEvent] initCf 请求失败：\(error.localizedDescription)")
                return
            }
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard let data, (200...299).contains(code) else { return }

            if cfg.setting.debugLog {
                print("[WFEvent] ◆ initCf 响应：状态码=\(code)  body=\(String(data: data, encoding: .utf8) ?? "")")
            }
            parseInitCfResponse(data)
        }.resume()
    }

    private static func parseInitCfResponse(_ data: Data) {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let dataObj = root["data"] as? [String: Any]
        else { return }

        if let signature = dataObj["signature"] as? String, !signature.isEmpty {
            WFEventStorage.set(signature, for: WFEventStorage.keySignature)
            if config?.setting.debugLog == true { print("[WFEvent] initCf 成功，signature 已更新") }
        }
        if let points = dataObj["initPoints"] as? [String: Any],
           let pointsData = try? JSONSerialization.data(withJSONObject: points),
           let pointsStr = String(data: pointsData, encoding: .utf8) {
            WFEventStorage.set(pointsStr, for: WFEventStorage.keyInitPoints)
        }
    }
}
