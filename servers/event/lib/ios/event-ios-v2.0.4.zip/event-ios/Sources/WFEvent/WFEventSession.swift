import Foundation
#if canImport(UIKit)
import UIKit
#endif

/// 会话状态管理 v2.0（对标 Android WFEventSession）
///
/// 双 ID 设计：
/// - customerKey：UUID v4 + 时间戳，UserDefaults 持久化，卸载重装会变化
/// - deviceKey（weDeviceId）：identifierForVendor → Keychain → UUID 三级兜底，卸载重装大概率不变
final class WFEventSession {

    static let shared = WFEventSession()
    private init() {}

    // MARK: - 设备标识（双 ID）

    /// customerKey：UUID v4 + 时间戳，持久化于 UserDefaults
    private(set) var customerKey: String = ""

    /// deviceKey：神策方案三级兜底，持久化于 Keychain，用于 weDeviceId
    private(set) var deviceKey: String = ""

    // MARK: - 会话 ID

    /// sessionId：纯内存，冷启动/热启动时生成
    private(set) var sessionId: String = ""

    // MARK: - 通用属性

    /// 通用属性（base64 编码后的 JSON 字符串），持久化于 UserDefaults
    private(set) var commonInfo: String = ""

    // MARK: - 用户信息

    var userId:   String = ""
    var nickname: String = ""
    var userType: String = ""
    var userTag:  String = ""
    var userDes:  String = ""

    // MARK: - 当前页面

    var currentPage: String = ""

    // MARK: - 新老用户

    /// 1=今日新用户，2=老用户
    private(set) var newStatus: Int = 1

    // MARK: - 初始化

    func setup() {
        initCustomerKey()
        // 必须在 initDeviceKey() 之前执行，因为 deviceKey 的 Keychain 可能依赖首次安装日期
        initAccessInfo()
        initDeviceKey()
        initCommonInfo()
        restoreUser()
        renewSessionId()
    }

    // MARK: - 会话 ID

    /// 生成新 sessionId（冷启动时由 setup() 调用，热启动时由 WFAppTracker 调用）
    func renewSessionId() {
        sessionId = UUID().uuidString
    }

    // MARK: - 用户信息

    func setUser(userId: String, nickname: String, userType: String, userTag: String, des: String) {
        self.userId   = userId
        self.nickname = nickname
        self.userType = userType
        self.userTag  = userTag
        self.userDes  = des

        let dict: [String: String] = [
            "userId": userId, "nickname": nickname,
            "userType": userType, "userTag": userTag, "des": des
        ]
        if let data = try? JSONSerialization.data(withJSONObject: dict),
           let str  = String(data: data, encoding: .utf8) {
            WFEventStorage.set(str, for: WFEventStorage.keyUserInfo)
        }
    }

    private func restoreUser() {
        let str = WFEventStorage.string(for: WFEventStorage.keyUserInfo)
        guard !str.isEmpty,
              let data = str.data(using: .utf8),
              let dict = try? JSONSerialization.jsonObject(with: data) as? [String: String]
        else { return }
        userId   = dict["userId"]   ?? ""
        nickname = dict["nickname"] ?? ""
        userType = dict["userType"] ?? ""
        userTag  = dict["userTag"]  ?? ""
        userDes  = dict["des"]      ?? ""
    }

    // MARK: - 通用属性

    /// 设置通用属性（持久化到 UserDefaults）
    func setCommonInfo(_ params: [String: Any]) {
        if params.isEmpty {
            commonInfo = ""
            WFEventStorage.remove(WFEventStorage.keyCommonInfo)
            return
        }
        guard let data = try? JSONSerialization.data(withJSONObject: params),
              let jsonStr = String(data: data, encoding: .utf8)
        else { return }
        commonInfo = Data(jsonStr.utf8).base64EncodedString()
        WFEventStorage.set(commonInfo, for: WFEventStorage.keyCommonInfo)
    }

    private func initCommonInfo() {
        commonInfo = WFEventStorage.string(for: WFEventStorage.keyCommonInfo)
    }

    // MARK: - customerKey 初始化

    /// customerKey：UUID v4 + 时间戳，UserDefaults 持久化
    private func initCustomerKey() {
        let saved = WFEventStorage.string(for: WFEventStorage.keyCustomerKey)
        if !saved.isEmpty {
            customerKey = saved
            return
        }
        let key = generateUuidWithTimestamp()
        customerKey = key
        WFEventStorage.set(key, for: WFEventStorage.keyCustomerKey)
    }

    /// 生成 UUID v4 + 时间戳后缀，对标 H5 getUuid() / Android generateUuidWithTimestamp()
    private func generateUuidWithTimestamp() -> String {
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMddHHmmssSSS"
        let ts = fmt.string(from: Date())

        let chars = "0123456789abcdef"
        let sections = [8, 4, 4, 4, 12]
        var sb = ""
        for (i, len) in sections.enumerated() {
            for j in 0..<len {
                if i == 2 && j == 0 {
                    sb.append("4")
                } else if i == 3 && j == 0 {
                    let r = Int(arc4random_uniform(4))
                    let opts = ["8", "9", "a", "b"]
                    sb.append(opts[r])
                } else {
                    sb.append(chars[chars.index(chars.startIndex, offsetBy: Int(arc4random_uniform(16)))])
                }
            }
            if i < sections.count - 1 { sb.append("-") }
        }
        sb.append("-")
        sb.append(ts)
        return sb
    }

    // MARK: - deviceKey 初始化（神策方案：identifierForVendor → Keychain → UUID）

    private func initDeviceKey() {
        // 先从 Keychain 读取已持久化的 deviceKey
        if let saved = keychainGet(key: "deviceKey"), !saved.isEmpty {
            deviceKey = saved
            return
        }

        // 优先级 1: identifierForVendor
        if let idfv = UIDevice.current.identifierForVendor?.uuidString, !idfv.isEmpty {
            deviceKey = "idfv_\(idfv)"
            _ = keychainSet(key: "deviceKey", value: deviceKey)
            return
        }

        // 优先级 2: 生成 UUID 存入 Keychain 持久化
        let uuid = UUID().uuidString
        deviceKey = "keychain_\(uuid)"
        if keychainSet(key: "deviceKey", value: deviceKey) {
            return
        }

        // 优先级 3: UUID + UserDefaults 兜底
        let fallbackUuid = generateUuidWithTimestamp()
        deviceKey = "uuid_\(fallbackUuid)"
        WFEventStorage.set(deviceKey, for: WFEventStorage.keyDeviceKey)
    }

    // MARK: - Keychain 操作

    /// 读取 Keychain
    private func keychainGet(key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.webfunny.event",
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    /// 写入 Keychain
    private func keychainSet(key: String, value: String) -> Bool {
        // 先删除旧值
        let deleteQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.webfunny.event",
            kSecAttrAccount as String: key
        ]
        SecItemDelete(deleteQuery as CFDictionary)

        // 写入新值
        guard let data = value.data(using: .utf8) else { return false }
        let addQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.webfunny.event",
            kSecAttrAccount as String: key,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock
        ]
        let status = SecItemAdd(addQuery as CFDictionary, nil)
        return status == errSecSuccess
    }

    // MARK: - 新老用户

    private func initAccessInfo() {
        let today = todayString()

        let firstInstall = WFEventStorage.string(for: WFEventStorage.keyFirstInstall)
        if firstInstall.isEmpty {
            WFEventStorage.set(today, for: WFEventStorage.keyFirstInstall)
        }
        let installDate = WFEventStorage.string(for: WFEventStorage.keyFirstInstall)
        newStatus = (installDate == today) ? 1 : 2

        let lastAccess = WFEventStorage.string(for: WFEventStorage.keyLastAccessDate)
        if lastAccess != today {
            let times = WFEventStorage.int(for: WFEventStorage.keyAccessTimes, default: 0)
            WFEventStorage.set(times + 1, for: WFEventStorage.keyAccessTimes)
            WFEventStorage.set(today, for: WFEventStorage.keyLastAccessDate)
        }
    }

    private func todayString() -> String {
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMdd"
        return fmt.string(from: Date())
    }
}
