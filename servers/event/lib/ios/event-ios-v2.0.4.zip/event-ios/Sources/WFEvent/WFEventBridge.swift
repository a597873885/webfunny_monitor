import Foundation

// MARK: - ObjC 配置对象（按类别划分）

/// 服务器配置
@objc public class WFEventServerConfig: NSObject {
    /// 上报域名，例如 https://your-server.com
    @objc public var uploadDomain: String = ""
    /// 项目 ID
    @objc public var projectId: String = ""
    /// 环境：pro / dev / sit / stag
    @objc public var env: String = ""
    /// 应用版本号
    @objc public var projectVersion: String = ""
}

/// 全埋点点位配置
@objc public class WFEventAppPointsConfig: NSObject {
    /// App 启动点位
    @objc public var appStart: Int = 0
    /// App 进入后台点位
    @objc public var appEnd: Int = 0
    /// 心跳点位
    @objc public var appHeartBeat: Int = 0
    /// 页面进入点位（手动采集）
    @objc public var appPageEnter: Int = 0
    /// 页面离开点位（手动采集）
    @objc public var appPageLeave: Int = 0
}

/// 自动采集开关
@objc public class WFEventAutoTrackConfig: NSObject {
    /// 是否自动采集 App 启动
    @objc public var appStart: Bool = false
    /// 是否自动采集 App 进入后台
    @objc public var appEnd: Bool = false
    /// 是否自动采集心跳
    @objc public var appHeartBeat: Bool = false
}

/// 心跳配置
@objc public class WFEventHeartBeatConfig: NSObject {
    /// 是否启用心跳
    @objc public var enable: Bool = false
    /// 心跳间隔（秒），可选 5 / 15 / 30 / 60
    @objc public var gap: Int = 0
    /// 单次连续最大心跳次数，0 = 不限制
    @objc public var limit: Int = 0
}

/// SDK 行为配置
@objc public class WFEventSettingConfig: NSObject {
    /// 是否打印调试日志
    @objc public var debugLog: Bool = false
    /// 是否启用 gzip 压缩上报
    @objc public var gzip: Bool = false
}

// MARK: - ObjC 桥接层

/// Objective-C 桥接层
///
/// WFEvent 是 Swift enum，WFEventConfig 等是 Swift struct，
/// Objective-C 无法直接调用。本类将全部 API 包装为 @objc class 方法，
/// ObjC 项目通过 `#import <WFEvent/WFEvent-Swift.h>` 即可使用。
@objc public class WFEventBridge: NSObject {

    // MARK: - 初始化

    /// 使用分类配置对象初始化 SDK
    @objc public static func initEvent(
        server: WFEventServerConfig,
        appPoints: WFEventAppPointsConfig,
        autoTrack: WFEventAutoTrackConfig,
        heartBeat: WFEventHeartBeatConfig,
        setting: WFEventSettingConfig
    ) {
        let config = WFEventConfig(
            uploadDomain:  server.uploadDomain,
            projectId:      server.projectId,
            env:            server.env,
            projectVersion: server.projectVersion,
            appPoints: WFAppPoints(
                appStart:     appPoints.appStart,
                appEnd:       appPoints.appEnd,
                appHeartBeat: appPoints.appHeartBeat,
                appPageEnter: appPoints.appPageEnter,
                appPageLeave: appPoints.appPageLeave
            ),
            autoTrack: WFAutoTrack(
                appStart:     autoTrack.appStart,
                appEnd:       autoTrack.appEnd,
                appHeartBeat: autoTrack.appHeartBeat
            ),
            setting: WFSetting(
                heartBeat: WFHeartBeatSetting(enable: heartBeat.enable, gap: heartBeat.gap, limit: heartBeat.limit),
                debugLog:  setting.debugLog,
                gzip:      setting.gzip
            )
        )
        WFEvent.initEvent(config)
    }

    // MARK: - 通用属性

    /// 设置通用属性（持久化到本地，上报时自动附加到 weCommonInfo）
    @objc public static func setCommonInfo(_ params: [String: Any]) {
        WFEvent.setCommonInfo(params)
    }

    // MARK: - 用户信息

    /// 设置当前用户信息（登录后调用）
    @objc public static func setUser(
        userId: String,
        nickname: String,
        userType: String,
        userTag: String,
        des: String
    ) {
        WFEvent.setUser(
            userId:   userId,
            nickname: nickname,
            userType: userType,
            userTag:  userTag,
            des:      des
        )
    }

    // MARK: - 埋点上报

    /// 上报埋点事件（加入队列，等待批量上报）
    @objc public static func track(pointId: String, params: [String: Any]) {
        WFEvent.track(pointId: pointId, params: params)
    }

    /// 上报埋点事件并立即上报
    @objc public static func trackImmediate(pointId: String, params: [String: Any]) {
        WFEvent.track(pointId: pointId, params: params, upNow: true)
    }

    /// 按环境选点位 ID 上报
    @objc public static func trackByEnv(pointIds: [String: Any], params: [String: Any]) {
        WFEvent.track(pointIds: pointIds, params: params)
    }

    /// 立即刷新上报队列
    @objc public static func flush() {
        WFEvent.flush()
    }

    // MARK: - 页面采集

    /// 手动上报页面浏览（进入）
    @objc public static func trackPageView(pageTitle: String, pagePath: String) {
        WFEvent.trackPageView(pageTitle: pageTitle, pagePath: pagePath)
    }

    /// 手动上报页面浏览（离开，停留时长自动计算）
    @objc public static func trackPageLeave() {
        WFEvent.trackPageLeave()
    }
}
