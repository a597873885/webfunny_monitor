import Foundation
import Compression

// MARK: - Data+gzip 扩展（使用 Compression.framework，零额外依赖）

private extension Data {

    /// 使用 COMPRESSION_ZLIB 压缩并包装为 gzip 格式
    func gzipCompressed() -> Data? {
        guard !isEmpty else { return nil }

        // 1. 压缩（COMPRESSION_ZLIB 产出 raw deflate）
        guard let deflateBody = self.compress() else { return nil }

        // 2. 组装 gzip 帧
        var gzip = Data()
        gzip.append(contentsOf: [0x1f, 0x8b, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff])
        gzip.append(deflateBody)
        var crc = self.crc32Value()
        Swift.withUnsafeBytes(of: &crc) { gzip.append(contentsOf: $0) }
        var isize = UInt32(count & 0xffffffff)
        Swift.withUnsafeBytes(of: &isize) { gzip.append(contentsOf: $0) }
        return gzip
    }

    /// 压缩为 raw deflate（不包装 zlib/gzip 帧）
    private func compress() -> Data? {
        let dstCapacity = count + 512
        let dst = UnsafeMutablePointer<UInt8>.allocate(capacity: dstCapacity)
        defer { dst.deallocate() }

        let written = withUnsafeBytes { src -> Int in
            guard let srcBase = src.baseAddress else { return 0 }
            return compression_encode_buffer(
                dst, dstCapacity,
                srcBase.assumingMemoryBound(to: UInt8.self), count,
                nil, COMPRESSION_ZLIB
            )
        }
        guard written > 0 else { return nil }
        return Data(bytes: dst, count: written)
    }

    /// 标准 CRC32（多项式 0xEDB88320）
    private func crc32Value() -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in self {
            let idx = Int((crc ^ UInt32(byte)) & 0xff)
            crc = (crc >> 8) ^ Self.crc32Table[idx]
        }
        return crc ^ 0xffffffff
    }

    private static let crc32Table: [UInt32] = {
        var table = [UInt32](repeating: 0, count: 256)
        for i in 0..<256 {
            var c = UInt32(i)
            for _ in 0..<8 {
                c = (c >> 1) ^ ((c & 1) * 0xedb88320)
            }
            table[i] = c
        }
        return table
    }()
}

/// 埋点数据批量上报核心 v2.0（对标 Android WFEventUploader）
///
/// - flush：先持久化再清空内存队列，最后网络上报
/// - body > 1KB 时 gzip 压缩
/// - 上报失败进入重试（4s → 16s → 32s，最多 3 次）
/// - 启动时扫描残留文件并恢复重试
final class WFEventUploader {

    static let shared = WFEventUploader()
    private init() {}

    private let maxRetry = 3
    private let gzipThreshold = 1024

    private var config: WFEventConfig!
    private var queue: [[String: Any]] = []
    private let lock = NSLock()
    private var flushTimer: Timer?
    private let uploadQueue = DispatchQueue(label: "com.webfunny.event.uploader", qos: .utility)
    private let retryQueue = DispatchQueue(label: "com.webfunny.event.retry", qos: .utility)

    // MARK: - 初始化

    func setup(config: WFEventConfig) {
        self.config = config
        startTimer()
        uploadQueue.async { self.recoverPendingBatches() }
        uploadQueue.async { WFEventDiskManager.cleanExpired() }
        uploadQueue.async { WFEventDiskManager.enforceDiskLimit() }
    }

    // MARK: - 入队

    func enqueue(_ log: [String: Any]) {
        lock.lock()
        queue.append(log)
        let shouldFlush = queue.count >= config.maxQueueSize
        lock.unlock()
        if shouldFlush { flushNow() }
    }

    func flushNow() {
        uploadQueue.async { self.flush() }
    }

    // MARK: - 内部

    private func startTimer() {
        DispatchQueue.main.async {
            self.flushTimer?.invalidate()
            self.flushTimer = Timer.scheduledTimer(
                withTimeInterval: self.config.flushInterval,
                repeats: true
            ) { [weak self] _ in
                self?.flushNow()
            }
        }
    }

    @objc private func flush() {
        lock.lock()
        guard !queue.isEmpty else { lock.unlock(); return }
        let batch = queue
        queue.removeAll()
        lock.unlock()

        // 1. 先持久化到磁盘
        let fileURL = WFEventDiskManager.saveBatch(batch)

        // 2. 网络上报
        upload(batch, fileURL: fileURL)
    }

    private func upload(_ logs: [[String: Any]], fileURL: URL?, retryCount: Int = 0) {
        guard let url = config.uploadURL else { return }

        guard let jsonData = try? JSONSerialization.data(withJSONObject: logs) else { return }
        var body = jsonData
        var useGzip = false

        // gzip 压缩（> 1KB 且 config.setting.gzip 为 true 时启用）
        if config.setting.gzip, body.count > gzipThreshold, let compressed = body.gzipCompressed() {
            body = compressed
            useGzip = true
        }

        let signature = WFSignature.generate(
            storedSignature: WFEventStorage.string(for: WFEventStorage.keySignature),
            projectId: config.projectId
        )

        if config.setting.debugLog {
            print("[WFEvent] ┌─────────── 上报请求 ───────────────────")
            print("[WFEvent] │ URL    : \(url)")
            print("[WFEvent] │ 条数   : \(logs.count)")
            print("[WFEvent] │ gzip   : \(useGzip)")
            print("[WFEvent] │ 大小   : \(body.count) bytes")
            print("[WFEvent] │ Body   : \(String(data: jsonData, encoding: .utf8) ?? "")")
            print("[WFEvent] └────────────────────────────────────────")
        }

        var request = URLRequest(url: url, timeoutInterval: 10)
        request.httpMethod = "POST"
        request.setValue("application/json;charset=UTF-8", forHTTPHeaderField: "Content-Type")
        if useGzip {
            request.setValue("gzip", forHTTPHeaderField: "Content-Encoding")
        }
        if !signature.isEmpty {
            request.setValue(signature, forHTTPHeaderField: "wf-signature")
        }
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            if let error {
                print("[WFEvent] 上报异常：\(error.localizedDescription)")
                if let fileURL { self.scheduleRetry(fileURL, currentRetry: retryCount) }
                return
            }
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            let respStr = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
            if self.config.setting.debugLog {
                print("[WFEvent] ◆ 上报响应：状态码=\(code)")
            }
            if (200...299).contains(code) {
                if let fileURL { WFEventDiskManager.deleteBatch(fileURL) }
            } else {
                print("[WFEvent] 上报失败（状态码=\(code)），进入重试: \(respStr)")
                // 打印失败请求的原始 JSON（便于排查服务端报错原因）
                if let rawJson = String(data: jsonData, encoding: .utf8) {
                    let preview = String(rawJson.prefix(2000))
                    print("[WFEvent] ◇ 失败请求体（前2000字符）: \(preview)")
                }
                if let fileURL { self.scheduleRetry(fileURL, currentRetry: retryCount) }
            }
        }.resume()
    }

    // MARK: - 重试机制

    /// 调度重试：4s → 16s → 32s，最多 3 次
    private func scheduleRetry(_ fileURL: URL, currentRetry: Int) {
        guard currentRetry < maxRetry else {
            print("[WFEvent] 重试已达上限 \(maxRetry) 次，删除文件: \(fileURL.lastPathComponent)")
            WFEventDiskManager.deleteBatch(fileURL)
            return
        }

        let delay: TimeInterval = switch currentRetry {
            case 0: 4
            case 1: 16
            default: 32
        }

        print("[WFEvent] 计划第 \(currentRetry + 1) 次重试（\(Int(delay))s 后）: \(fileURL.lastPathComponent)")

        retryQueue.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self else { return }
            guard let newURL = WFEventDiskManager.renameForRetry(fileURL) else {
                print("[WFEvent] rename 失败，删除文件: \(fileURL.lastPathComponent)")
                WFEventDiskManager.deleteBatch(fileURL)
                return
            }
            self.retryUpload(newURL, retryCount: currentRetry + 1)
        }
    }

    private func retryUpload(_ fileURL: URL, retryCount: Int) {
        guard let data = try? Data(contentsOf: fileURL),
              let logs = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]]
        else {
            scheduleRetry(fileURL, currentRetry: retryCount)
            return
        }
        print("[WFEvent] 第 \(retryCount) 次重试上传: \(fileURL.lastPathComponent)（\(logs.count) 条）")
        upload(logs, fileURL: fileURL, retryCount: retryCount)
    }

    // MARK: - 启动恢复

    private func recoverPendingBatches() {
        let files = WFEventDiskManager.loadAllBatches()
        guard !files.isEmpty else { return }
        print("[WFEvent] 发现 \(files.count) 个待恢复批次文件")

        for file in files {
            let retry = WFEventDiskManager.parseRetry(file)
            if retry >= maxRetry {
                print("[WFEvent] 文件已超最大重试次数，删除: \(file.lastPathComponent)")
                WFEventDiskManager.deleteBatch(file)
                continue
            }
            // 老文件跳过前面几次等待，直接用最大间隔
            let fileAge = Date().timeIntervalSince1970 - (file.lastModifiedDate?.timeIntervalSince1970 ?? 0)
            if fileAge > 120 {
                print("[WFEvent] 老文件（\(Int(fileAge))s），跳过等待直接重试: \(file.lastPathComponent)")
                retryUpload(file, retryCount: retry)
            } else {
                scheduleRetry(file, currentRetry: retry)
            }
        }
    }
}

private extension URL {
    var lastModifiedDate: Date? {
        (try? resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
    }
}
